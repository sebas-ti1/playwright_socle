"use strict";(self.webpackChunkcareer_site_ui=self.webpackChunkcareer_site_ui||[]).push([[34],{306:(e,t,n)=>{n.d(t,{$r:()=>s,I2:()=>o,Nf:()=>r,T$:()=>p,W5:()=>i,W6:()=>A,YO:()=>l,l4:()=>c,mN:()=>d,xD:()=>m});var a=n(58408);const r=e=>({type:a.CL,payload:{isSending:!0,offerId:e}}),i=()=>({type:a.Ip,payload:{isSending:!0}}),l=e=>({type:a.r3,payload:{offersId:e}}),o=e=>({type:a.P,payload:{isSending:!1,offerId:e,success:!0}}),s=()=>({type:a.lO,payload:{isSending:!1,success:!0}}),A=(e,t)=>({type:a.lt,payload:{isSending:!1,offerId:e,success:!1,err:{name:t.name,message:t.message,errorCode:t.errorCode,statusCode:t.statusCode}}}),c=e=>({type:a.PJ,payload:{isSending:!1,success:!1,err:{name:e.name,message:e.message,errorCode:e.errorCode,statusCode:e.statusCode}}}),d=e=>({type:a.mV,payload:{offerId:e}}),p=()=>({type:a.I7,payload:{}}),m=e=>({type:a.D$,payload:{isFileUploaded:e}})},3548:(e,t,n)=>{n.d(t,{w:()=>A});var a=n(14041),r=n(2345),i=n(61631),l=n(39067),o=n.n(l);const s=r.Ay.section`
  display: block;
  padding: 0 0 64px 0;
  width: 100%;

  ${e=>{let{theme:t,bgColorName:n}=e;return`\n    background-color: ${(0,i.h1)(n)?n:(0,i.x6)(t.palette,n,"light")};\n  `}}
`,A=e=>{let{children:t,bgColorName:n=i.QZ,className:r}=e;return a.createElement(s,{"data-print-hidden":!0,bgColorName:n,className:r},t)};A.propTypes={bgColorName:o().oneOf([i.Fl,i.ll,i.QZ,i.CF,i.o1,null]),className:o().string}},6989:(e,t,n)=>{n.d(t,{h:()=>k});var a=n(89575),r=n(14041),i=n(2345),l=n(74798),o=n(97434),s=n(34766),A=n(19996),c=n(89618),d=n(75992),p=n(68153),m=n(65563),u=n(90835),g=n(32673),C=n(22466);const f=(0,i.Ay)(g.A)`
  margin-bottom: 16px;
`,h=e=>{let{coverLetter:t,isTalentsoft:n,onChange:a,onFocus:i}=e;const l=n?r.createElement(C.A,{justifyContent:"space-between"},r.createElement("span",{"data-testid":"cvc-cover-letter-error"},t.error),r.createElement("span",{"data-testid":"cvc-cover-letter-counter"},t.value?.length??0,"/",3e3)):r.createElement("span",{"data-testid":"cvc-cover-letter-error"},t.error),o=n?{maxLength:3e3}:void 0;return r.createElement(f,{label:t.placeholder,name:t.name,error:!!t.error,helperText:l,defaultValue:t.value,variant:"outlined",fullWidth:!0,onChange:a,onFocus:i,multiline:!0,rows:3,inputProps:{...o,"data-testid":"cvc-cover-letter-textarea"},"data-testid":"cvc-cover-letter-field"})};var y=n(23099),E=n(87448),M=n(85423),x=n(97519),w=n(45728),D=n(31048);const b=i.Ay.div`
  display: block;
  margin: 32px 0;
  flex: 1;
`,L=(0,i.Ay)(l.A)`
  margin: 0;
  font-size: 1rem;
  white-space: pre-line;
`,_=i.Ay.form`
  position: relative;
  margin: 32px auto;
`,I=i.Ay.div`
  margin: 16px auto;
`,v=(0,i.Ay)(l.A)`
  display: block;
  font-size: 1rem;
  font-weight: 600;

  span {
    display: inline-block;
    margin-left: 8px;
  }
`,N=i.Ay.div`
  margin: 16px auto;
  font-size: 1rem;
`,k=e=>{let{coverLetterField:t,entityField:n,formFields:i,isSpontaneousForm:l,inputChange:g,inputFocus:C,formSubmit:f,isSending:k}=e;const{t:j}=(0,o.Bd)(),{config:z}=(0,p._r)(),T=(0,M.GV)(D.To),O=(0,M.GV)(D.rX),Q=(0,r.useRef)(null);(0,r.useEffect)(()=>{let e;return!l&&Q.current&&(e=(0,y.dM)("product.add_to_cart",{product_data:[(0,y.h6)(O)],method:"cv"},Q.current)),()=>{e&&e()}},[l,O]);const S=z.features.spontaneousApplication?.partnerName,P=!(!S||z.application_workflow_per_partner[S]?.ats!==w.up.TALENTSOFT),B=l&&(n?.entity?.options?.length??0)>1&&!P,V=[...Array.isArray(i)?i:Object.values(i??{}),...B?[n.entity]:[]],$=t.cover_letter;return r.createElement(s.A,{in:!0},r.createElement(b,{ref:Q},r.createElement(L,{dangerouslySetInnerHTML:{__html:x.A.sanitize(j("application.check_fields_information_application"),{USE_PROFILES:{html:!0}})}}),r.createElement(_,{onSubmit:f,"data-testid":"cvc-application-form"},!(0,d.A)(i)&&r.createElement(A.Ay,{container:!0,spacing:2},V.map((e,t)=>r.createElement(u.x,(0,a.A)({key:t,field:e},B&&e===n.entity&&"is_required"in n.entity?{isRequired:n.entity.is_required}:{},{inputChange:g,inputFocus:C})))),z.features.display_application_form_terms_of_service&&r.createElement(I,null,r.createElement(E.A,{i18nKey:"application.terms_of_use_text"})),r.createElement(v,null,j("application.attachment_file_label")," :",r.createElement("span",{"data-testid":"cvc-attachment-file-name"},T.attachment_file_name)),l&&r.createElement(h,{coverLetter:$,isTalentsoft:P,onChange:g,onFocus:C}),k?r.createElement(N,null,r.createElement(c.A,{severity:"info"},j("application.application_is_sending"))):r.createElement(m.$n,{type:"submit",fullWidth:!0,disabled:k,"data-testid":"cvc-form-application-submit-button"},j("application.submit")))))}},8667:(e,t,n)=>{n.d(t,{I:()=>a});const a=n(2345).Ay.p`
  ${e=>{let{theme:t}=e;return`\n    font-size: 0.875rem;\n    color: ${t.palette.error.main} !important;\n    font-weight: 500;\n    line-height: 24px;\n  `}}
`},8877:(e,t,n)=>{n.d(t,{X8:()=>A,rb:()=>c,ad:()=>s,jp:()=>d});var a=n(89575),r=n(14041),i=n(2345),l=n(39067),o=n.n(l);const s=e=>{let{children:t,stateful:n=!0,minWidth:a=0,maxWidth:i=1/0,up:l=!1,down:o=!1}=e;const[s,A]=(0,r.useState)(window?window.innerWidth:0),c=()=>{A(window.innerWidth)};if((0,r.useEffect)(()=>{if(window&&n)return window.addEventListener("resize",c),()=>window.removeEventListener("resize",c)},[n]),l&&o)throw new Error("ResponsiveComponent: it makes no sense to have up and down! You cannot have both ;)");if(a>i)throw new Error("ResponsiveComponent: minWidth provided is superior to maxWidth.");return o?s<=i?t:null:l?s>=a?t:null:s>=a&&s<=i?t:null};s.propTypes={down:o().bool,maxWidth:o().number,minWidth:o().number,stateful:o().bool,up:o().bool};const A=e=>{const{breakpoints:t={}}=(0,i.DP)();return r.createElement(s,(0,a.A)({minWidth:t.values.laptop},e))},c=e=>{const{breakpoints:t={}}=(0,i.DP)();return r.createElement(s,(0,a.A)({minWidth:t.values.tablet,maxWidth:t.values.laptop-1},e))},d=e=>{const{breakpoints:t={}}=(0,i.DP)();return r.createElement(s,(0,a.A)({minWidth:t.values.mobile,maxWidth:t.values.tablet-1},e))}},12396:(e,t,n)=>{n.d(t,{A:()=>C});var a=n(14041),r=n(97519),i=n(97434),l=n(2345),o=n(66341),s=n(36080),A=n(58797);const c=l.Ay.div`
  display: flex;
  align-items: start;
  margin-top: 16px;
  gap: 8px;
`,d=l.Ay.div`
  position: relative;
  display: flex;
  align-items: center;
`,p=l.Ay.input`
  position: absolute;
  opacity: 0;
  cursor: pointer;
  z-index: 1;

  &:checked + label svg path {
    stroke-dashoffset: 0;
  }

  &:focus + label {
    transform: scale(1.03);
  }
`,m=l.Ay.label`
  position: relative;
  display: inline-block;
  margin-top: 2px;
  border: 1px solid ${s.c3[900]};
  width: 13px;
  height: 13px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s ease;

  &:active {
    transform: scale(1.05);
  }

  svg {
    pointer-events: none;
  }

  svg path {
    fill: none;
    stroke: ${s.c3[900]};
    stroke-width: 1.8px;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-dasharray: 100;
    stroke-dashoffset: 101;
    transition: all 200ms cubic-bezier(1, 0, 0.37, 0.91);
  }
`,u=(0,l.Ay)(A.h_)`
  position: relative;
  bottom: 7px;
  left: -2px;
`,g=(0,l.Ay)(A.o5)`
  color: ${s.c3[600]};
  cursor: pointer;
  font-size: 12px;
  line-height: 1.5;
  margin: 0;
`;const C=function(e){const{t}=(0,i.Bd)(),n={__html:r.A.sanitize(t(e.label),{USE_PROFILES:{html:!0}})};return a.createElement(c,null,a.createElement(d,null,a.createElement(p,{type:"checkbox",id:"emailAlertCheckbox",name:"emailAlertCheckbox",checked:e.isChecked,onChange:t=>{e.toggleChecked(t.target.checked)}}),a.createElement(m,{htmlFor:"emailAlertCheckbox"},a.createElement(u,{View:o.iW,size:20}))),a.createElement(g,{id:"cvc-email-subscribe-caption",dangerouslySetInnerHTML:n,onClick:()=>{document.getElementById("emailAlertCheckbox").click()}}))}},13532:(e,t,n)=>{n.d(t,{e:()=>i});var a=n(14041);const r=n(2345).Ay.svg`
  padding: 3px 7px;
  enable-background: new 0 0 254 75;
`,i=e=>{let{isWhite:t=!1,width:n=150,height:i=40}=e;const l="#8A8A8A",o=e=>t?"white":e;return a.createElement(r,{fill:o("black"),version:"1.1",xmlns:"http://www.w3.org/2000/svg",width:n,height:i,viewBox:"0 0 254 75"},a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.1055 32.6273V41.8875C15.1055 50.4364 22.1802 57.3666 30.9073 57.3666C39.6344 57.3666 46.7091 50.4364 46.7091 41.8875V32.6273H61.8147V41.8875C61.8147 58.6086 47.977 72.1637 30.9073 72.1637C13.8377 72.1637 0 58.6086 0 41.8875V32.6273H15.1055Z"}),a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.1055 18.2333V27.2074H0V18.2333H15.1055ZM46.7091 27.2074V18.2333H61.8147V27.2074H46.7091Z"}),a.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M15.1055 3.98572V12.9598H0V3.98572H15.1055ZM46.7091 12.9598V3.98572H61.8147V12.9598H46.7091Z",fill:o("#E90A5D")}),a.createElement("path",{d:"M241.673 28.1059V18.2217H238.624V13.5566H241.811V6.76697H247.539V13.5566H252.896V18.2217H247.539V27.3669C247.539 31.2467 250.587 31.801 252.204 31.801C252.85 31.801 253.266 31.7086 253.266 31.7086V36.8355C253.266 36.8355 252.573 36.9741 251.465 36.9741C248.185 36.9741 241.673 36.0041 241.673 28.1059Z"}),a.createElement("path",{d:"M214.328 24.9656C214.328 17.714 219.27 12.6333 226.29 12.6333C233.08 12.6333 236.729 17.5754 236.729 23.8109C236.729 24.5037 236.59 26.0741 236.59 26.0741H220.332C220.702 30.1848 223.889 32.3095 227.399 32.3095C231.186 32.3095 234.189 29.723 234.189 29.723L236.452 33.9261C236.452 33.9261 232.849 37.2978 226.983 37.2978C219.177 37.2978 214.328 31.6629 214.328 24.9656ZM220.517 22.0557H230.817C230.725 18.8687 228.738 17.1597 226.152 17.1597C223.15 17.1597 221.071 19.0073 220.517 22.0557Z"}),a.createElement("path",{d:"M188.588 36.7436V13.1876H194.223V15.9127C194.223 16.7902 194.131 17.5293 194.131 17.5293H194.223C195.239 15.5432 197.826 12.6333 202.583 12.6333C207.803 12.6333 210.759 15.3584 210.759 21.5938V36.7436H204.939V22.7947C204.939 19.931 204.2 17.9911 201.198 17.9911C198.057 17.9911 195.747 19.9772 194.87 22.7947C194.547 23.7647 194.454 24.827 194.454 25.9355V36.7436H188.588Z"}),a.createElement("path",{d:"M164.053 39.9306C164.053 39.9306 167.01 41.4548 170.566 41.4548C174.169 41.4548 177.217 39.9306 177.217 35.7274V34.3418C177.217 33.7875 177.31 33.0947 177.31 33.0947H177.217C175.831 35.1732 173.799 36.2817 170.658 36.2817C163.915 36.2817 160.081 30.8315 160.081 24.3651C160.081 17.8988 163.73 12.6333 170.52 12.6333C175.647 12.6333 177.494 15.6355 177.494 15.6355H177.633C177.633 15.6355 177.587 15.3584 177.587 14.9889V13.1876H183.083V35.3117C183.083 43.3947 176.801 46.4431 170.658 46.4431C167.702 46.4431 164.562 45.6117 162.298 44.4108L164.053 39.9306ZM171.905 31.3395C174.723 31.3395 177.356 29.723 177.356 24.4113C177.356 19.0535 174.723 17.6216 171.536 17.6216C167.979 17.6216 165.993 20.2082 165.993 24.1804C165.993 28.2911 168.118 31.3395 171.905 31.3395Z"}),a.createElement("path",{d:"M135.915 29.9539C135.915 22.4714 146.03 21.9633 149.864 21.9633H150.649V21.64C150.649 18.5454 148.709 17.4831 146.123 17.4831C142.751 17.4831 139.656 19.7463 139.656 19.7463L137.439 15.5432C137.439 15.5432 141.088 12.6333 146.677 12.6333C152.866 12.6333 156.469 16.0512 156.469 22.0095V36.7436H151.065V34.8037C151.065 33.8799 151.157 33.1409 151.157 33.1409H151.065C151.111 33.1409 149.264 37.2978 143.906 37.2978C139.703 37.2978 135.915 34.6651 135.915 29.9539ZM141.827 29.6768C141.827 31.2472 142.982 32.7252 145.384 32.7252C148.478 32.7252 150.695 29.3996 150.695 26.536V25.9817H149.679C146.677 25.9817 141.827 26.3974 141.827 29.6768Z"}),a.createElement("path",{d:"M98.1761 36.7417L100.855 3.948H107.229L113.649 20.1601C114.388 22.1 115.312 24.9636 115.312 24.9636H115.404C115.404 24.9636 116.282 22.1 117.021 20.1601L123.441 3.948H129.815L132.448 36.7417H126.536L125.15 18.4049C125.012 16.2341 125.104 13.3242 125.104 13.3242H125.012C125.012 13.3242 124.042 16.5112 123.256 18.4049L117.945 31.1067H112.725L107.46 18.4049C106.675 16.5112 105.659 13.278 105.659 13.278H105.566C105.566 13.278 105.659 16.2341 105.52 18.4049L104.134 36.7417H98.1761Z"}),a.createElement("path",{d:"M226.735 67.3599V50.9883H229.663V59.7506H231.116L233.952 55.6H237.203L233.491 60.8574V60.9035L237.665 67.3599H234.298L231.185 62.2178H229.663V67.3599H226.735Z",fill:o(l)}),a.createElement("path",{d:"M217.682 67.36V55.6001H220.495V57.6293C220.495 58.0674 220.449 58.4594 220.449 58.4594H220.495C221.026 56.7761 222.432 55.4387 224.231 55.4387C224.508 55.4387 224.761 55.4848 224.761 55.4848V58.3672C224.761 58.3672 224.461 58.321 224.069 58.321C222.824 58.321 221.418 59.0359 220.864 60.7883C220.68 61.3648 220.611 62.0104 220.611 62.7022V67.36H217.682Z",fill:o(l)}),a.createElement("path",{d:"M202.389 61.4797C202.389 57.8825 205.272 55.323 208.846 55.323C212.443 55.323 215.325 57.8825 215.325 61.4797C215.325 65.0999 212.443 67.6363 208.869 67.6363C205.272 67.6363 202.389 65.0999 202.389 61.4797ZM205.364 61.4797C205.364 63.6702 206.955 65.146 208.869 65.146C210.76 65.146 212.351 63.6702 212.351 61.4797C212.351 59.3121 210.76 57.8133 208.869 57.8133C206.955 57.8133 205.364 59.3121 205.364 61.4797Z",fill:o(l)}),a.createElement("path",{d:"M186.642 67.359L183.045 55.5991H186.135L188.187 63.3238C188.348 63.9463 188.418 64.5689 188.418 64.5689H188.464C188.464 64.5689 188.579 63.9463 188.74 63.3238L190.908 55.6222H193.514L195.681 63.3238C195.842 63.9463 195.935 64.5689 195.935 64.5689H195.981C195.981 64.5689 196.073 63.9463 196.234 63.3238L198.287 55.5991H201.33L197.756 67.359H194.505L192.522 60.649C192.338 60.0264 192.222 59.3807 192.222 59.3807H192.176C192.176 59.3807 192.084 60.0264 191.899 60.649L189.916 67.359H186.642Z",fill:o(l)}),a.createElement("path",{d:"M169.044 61.4797C169.044 57.8825 171.927 55.323 175.501 55.323C179.098 55.323 181.98 57.8825 181.98 61.4797C181.98 65.0999 179.098 67.6363 175.524 67.6363C171.927 67.6363 169.044 65.0999 169.044 61.4797ZM172.019 61.4797C172.019 63.6702 173.61 65.146 175.524 65.146C177.414 65.146 179.006 63.6702 179.006 61.4797C179.006 59.3121 177.414 57.8133 175.524 57.8133C173.61 57.8133 172.019 59.3121 172.019 61.4797Z",fill:o(l)}),a.createElement("path",{d:"M163.207 63.6936V50.9883H166.113V63.2555C166.113 64.5468 166.551 64.8696 167.312 64.8696C167.542 64.8696 167.75 64.8465 167.75 64.8465V67.406C167.75 67.406 167.312 67.4752 166.828 67.4752C165.214 67.4752 163.207 67.0601 163.207 63.6936Z",fill:o(l)}),a.createElement("path",{d:"M156.649 63.6936V50.9883H159.555V63.2555C159.555 64.5468 159.993 64.8696 160.754 64.8696C160.984 64.8696 161.192 64.8465 161.192 64.8465V67.406C161.192 67.406 160.754 67.4752 160.269 67.4752C158.655 67.4752 156.649 67.0601 156.649 63.6936Z",fill:o(l)}),a.createElement("path",{d:"M143.215 61.4797C143.215 57.8594 145.682 55.323 149.187 55.323C152.577 55.323 154.398 57.7903 154.398 60.9032C154.398 61.2491 154.329 62.0331 154.329 62.0331H146.213C146.397 64.0853 147.988 65.146 149.741 65.146C151.631 65.146 153.13 63.8547 153.13 63.8547L154.26 65.953C154.26 65.953 152.462 67.6363 149.533 67.6363C145.636 67.6363 143.215 64.8232 143.215 61.4797ZM146.305 60.027H151.447C151.401 58.4359 150.409 57.5827 149.118 57.5827C147.619 57.5827 146.582 58.5051 146.305 60.027Z",fill:o(l)}),a.createElement("path",{d:"M129.899 67.3599V50.9883H132.827V56.6607C132.827 57.2372 132.781 57.6522 132.781 57.6522H132.827C133.404 56.5224 134.834 55.3233 136.886 55.3233C139.491 55.3233 140.967 56.6838 140.967 59.7967V67.3599H138.062V60.3962C138.062 58.9666 137.693 57.9981 136.194 57.9981C134.649 57.9981 133.45 59.0127 133.012 60.4423C132.874 60.9035 132.827 61.4108 132.827 61.9642V67.3599H129.899Z",fill:o(l)}),a.createElement("path",{d:"M110.685 71.4404L111.653 69.2498C111.653 69.2498 112.299 69.7341 112.968 69.7341C113.775 69.7341 114.559 69.2498 114.997 68.2122L115.435 67.1746L110.477 55.5991H113.775L116.242 62.3784C116.472 63.0009 116.68 63.9694 116.68 63.9694H116.726C116.726 63.9694 116.911 63.0471 117.118 62.4245L119.424 55.5991H122.629L117.372 69.1345C116.542 71.279 114.904 72.2013 113.129 72.2013C111.722 72.2013 110.685 71.4404 110.685 71.4404Z",fill:o(l)}),a.createElement("path",{d:"M98.1761 67.3599V50.9883H101.105V56.0381C101.105 56.6146 101.058 57.0296 101.058 57.0296H101.105C101.105 57.0296 102.142 55.3233 104.633 55.3233C107.815 55.3233 109.844 57.8367 109.844 61.48C109.844 65.2155 107.561 67.6366 104.448 67.6366C102.004 67.6366 100.943 65.8842 100.943 65.8842H100.897C100.897 65.8842 100.943 66.23 100.943 66.6912V67.3599H98.1761ZM101.012 61.5491C101.012 63.3708 101.981 65.1693 103.941 65.1693C105.555 65.1693 106.892 63.855 106.892 61.5261C106.892 59.2894 105.693 57.8367 103.964 57.8367C102.442 57.8367 101.012 58.9435 101.012 61.5491Z",fill:o(l)}))}},13568:(e,t,n)=>{n.d(t,{g:()=>h});var a=n(89575),r=n(14041),i=n(58797),l=n(33664),o=n(2345),s=n(39067),A=n.n(s),c=n(61631),d=n(33131),p=n(8049);const m=o.AH`
  display: inline-block;
  font-size: 1rem;
  font-weight: 600;
  text-decoration: none;
`,u=(0,o.Ay)(l.N_)`
  ${m};
`,g=o.Ay.a`
  ${m};
`,C=(0,o.Ay)(i.o5)`
  display: inline-flex;
  align-items: center;
  padding: 0.25rem;
  border-radius: 5px 5px 0 0;
  border-bottom: 2px solid;

  ${e=>{let{theme:t,hoverColor:n}=e;const a=(0,c.x6)(t.palette,c.ll,c.Xs),r=n||a;return`\n      transition: all ${t.transitions.duration.standard}ms ease;\n\n      &:hover,\n      &:focus,\n      &:active {\n        fill: ${r} !important;\n        color: ${r} !important;\n      }\n    `}}
`,f=o.Ay.span`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: 4px;
`,h=e=>{let{children:t,icon:n,to:i,external:l,hoverColor:o,...s}=e;return l?r.createElement(g,(0,a.A)({href:i,target:"_blank",rel:"noopener noreferrer"},s),r.createElement(C,{variant:"span",hoverColor:o,autoContrast:!0},t,n&&r.createElement(f,null,r.createElement(d.A,{View:n,size:16})))):r.createElement(u,(0,a.A)({},s,{to:(0,p.KF)(i)}),r.createElement(C,{variant:"span",hoverColor:o,autoContrast:!0},t))};h.propTypes={to:A().string.isRequired,external:A().bool,hoverColor:A().string}},15195:(e,t,n)=>{n.d(t,{ss:()=>i.A,nX:()=>a,Em:()=>r});let a=function(e){return e.AUTOCOMPLETE="autocomplete",e.FREE="free",e}({}),r=function(e){return e.ENTER_KEY="enter_key",e.UI_BUTTON="ui_button",e.CLICK_ON_SUGGESTIONS="click_on_suggestions",e}({});var i=n(45311)},17143:(e,t,n)=>{n.d(t,{e:()=>o});var a=n(14041),r=n(85426),i=n.n(r),l=n(68153);const o=e=>{let{view:t,isSpontaneousForm:n}=e;const{config:r}=(0,l._r)();return(0,a.useEffect)(()=>{r.analytics?.google_tag_manager?.active&&i().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Bloc",EventAction:"Visible",EventLibelle:"[DO] - Candidature reussie"}})},[r]),a.createElement(t,{isSpontaneousForm:n})}},19555:(e,t,n)=>{n.d(t,{Bd:()=>r,kM:()=>a,we:()=>i});const a=4e3,r={HOME:"home",RESULTS:"results",JOB_OFFER_DETAILS:"job_offer_details"},i=2097152},20800:(e,t,n)=>{n.d(t,{l:()=>H});var a=n(14041),r=n(30534),i=n(99142),l=n(59044),o=n(47603),s=n(61631),A=n(33664),c=n(8049),d=n(13568),p=n(3548),m=n(2345),u=n(58797),g=n(97434),C=n(80379),f=n(59437),h=n(8877),y=n(39067),E=n.n(y),M=n(45311),x=n(65563),w=n(75273),D=n(68382),b=n(63511),L=n(38544),_=n(93444),I=n(52519),v=n(33131),N=n(66341),k=n(23099),j=n(42853);const z=(0,m.Ay)(f.m)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding-right: 0;
  }
`,T=(0,m.Ay)(r.h)`
  font-size: 30px;
  font-weight: ${e=>{let{fontWeight:t}=e;return t}};
  line-height: 2.5rem;
  margin: 0 0 36px;
  text-align: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1.5rem;
    line-height: 2rem;
  }
`,O=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[];return e?.map(e=>e.id)},Q=m.Ay.div`
  --swiper-navigation-color: #ffffff;
  --swiper-navigation-size: 1rem;

  position: relative;

  .swiper-button-disabled {
    display: none;
  }

  .swiper-button-prev,
  .swiper-button-next {
    border: 1px solid #f5f5f5;
    background-color: black;
    padding: 1rem;
    border-radius: 50%;
  }

  .swiper-button-prev {
    left: 0;
    transform: translate(-50%, 0);
  }

  .swiper-button-next {
    right: 0;
    transform: translate(50%, 0);
  }
`,S=(0,m.Ay)(l.RC)`
  .swiper-slide {
    height: auto;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    .swiper-slide {
      max-width: 70%;
    }

    .swiper-slide:last-child {
      padding-right: 16px;
    }
  }
`,P=(0,m.Ay)(I.X)`
  margin-bottom: 8px;
  object-fit: contain;
`,B=(0,m.Ay)(u.o5)`
  margin: 0 0 1rem 0;
  font-size: 1rem;
  font-weight: 600;

  a {
    color: inherit;
  }
`,V=m.Ay.div`
  text-align: center;
  margin: 2.25rem 0 0 0;
`,$=m.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: auto 0 0 0;
`,F=(0,m.Ay)(u.vw)`
  p {
    margin: 0;
    word-wrap: anywhere;
  }
`,Z=e=>{let{text:t,children:n}=e;return a.createElement(F,{mode:"secondary"},n,a.createElement("p",null,t))},G=e=>a.createElement(Z,e,a.createElement(v.A,{View:N.nR,size:16})),R=e=>a.createElement(Z,e,a.createElement(v.A,{View:N.ft,size:16})),H=(0,a.memo)(e=>{let{className:t,dataTestId:n,slug:r,largeButtonLink:u,bgColorName:f=s.ll,title:y,jobOffers:E,jobOffersCount:M,isFetching:I}=e;const v=(0,L.wA)(),{t:N}=(0,g.Bd)(),{breakpoints:F={}}=(0,m.DP)(),Z=(0,a.useRef)();return(0,a.useEffect)(()=>{E.length&&!(0,j.A)(O(Z.current),O(E))&&((0,k.oU)("product.display",{product_data:E.map((e,t)=>(0,k.h6)(e,t+1))}),Z.current=E)},[E]),a.createElement(p.w,{bgColorName:f,className:t},a.createElement(z,null,0!==M&&a.createElement(a.Fragment,null,a.createElement(T,{autoContrast:!0,fontWeight:u?400:600,variant:"h2"},y),I?a.createElement(w.q,null):a.createElement(Q,null,a.createElement(S,{onUpdate:e=>{e.navigation.destroy(),e.navigation.init(),e.navigation.update()},slidesPerView:"auto",spaceBetween:16,breakpoints:{[F.tablet]:{slidesPerView:2},[F.laptop]:{slidesPerView:4}},navigation:{prevEl:`#${r}-prev`,nextEl:`#${r}-next`,clickable:!0},keyboard:!0,modules:[i.Vx,i.s3]},E&&E.map((e,t)=>a.createElement(l.qr,{key:t},a.createElement(A.N_,{to:(0,c.X2)(window.location,e.id),onClick:()=>{var n;n=e.id,v((0,D.Iy)(D.M$.SEE_JOB_OFFER_DETAILS_PAGE,n,(0,b.BN)(r))),(0,k.oU)("product.click",{product_data:[(0,k.h6)(e,t+1)]})}},a.createElement(o.A,{"data-testid":n,hasHover:!0},e.company_logo_url&&a.createElement(P,{src:e.company_logo_url,alt:"logo"}),a.createElement(B,{"data-testid":`${n}-title`,variant:"h3",autoContrast:!0},e.title),a.createElement($,null,a.createElement(_.Pz,{view:G,contractTypes:e.contract_type}),a.createElement(_.sK,{offer:e,showDistance:!1,view:R}))))))),a.createElement(h.rb,{up:!0},a.createElement("div",{id:`${r}-prev`,className:"swiper-button-prev"}),a.createElement("div",{id:`${r}-next`,className:"swiper-button-next"})))),a.createElement(V,null,u?a.createElement(x.$n,{to:C.J.SEARCH},N("career_website_landing.last_job_offers_section.see_all_2022")):a.createElement(d.g,{bgColor:f,to:C.J.SEARCH},N("career_website_landing.last_job_offers_section.see_all_2022")))))});H.propTypes={...p.w.propTypes,slug:E().string.isRequired,title:E().string,jobOffers:E().arrayOf(M.A),largeButtonLink:E().bool},H.displayName="JobOffersSwiper"},23158:(e,t,n)=>{n.d(t,{V:()=>_});var a=n(14041),r=n(39067),i=n.n(r),l=n(2345),o=n(38544),s=n(89618),A=n(34766),c=n(65706),d=n(13568),p=n(97434),m=n(58797),u=n(61631);const g=l.Ay.button`
  display: inline-block;
  font-size: 1rem;
  font-weight: 600;
  text-decoration: none;
  cursor: pointer;
`,C=(0,l.Ay)(m.o5).attrs(e=>{let{theme:t}=e;return{hoverColor:(0,u.x6)(t.palette,u.ll,u.Xs)}})`
  display: inline-flex;
  padding: 0.25rem;
  border-radius: 5px 5px 0 0;
  border-bottom: 2px solid;

  ${e=>{let{theme:t,hoverColor:n}=e;return`\n    transition: all ${t.transitions.duration.standard}ms ease;\n\n    &:hover,\n    &:focus,\n    &:active {\n      fill: ${n} !important;\n      color: ${n} !important;\n    }\n  `}}
`,f=(0,l.Ay)(e=>{let{children:t,...n}=e;return a.createElement(g,n,a.createElement(C,{variant:"span",autoContrast:!0},t))})``;var h=n(33131),y=n(66341),E=n(31048),M=n(85423);const x=l.Ay.div`
  display: block;
  margin: 32px auto 0 auto;
  width: 100%;
  max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}};
  text-align: center;
`,w=(0,l.Ay)(s.A)`
  flex-direction: column;
  align-items: center;
  justify-content: center;

  .MuiAlert-icon {
    margin: 0;
  }
`,D=(0,l.Ay)(d.g)`
  display: block;
  margin-top: 16px;
`,b=l.Ay.strong`
  display: block;
`,L=l.Ay.div`
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-top: 16px;
`,_=e=>{let{showDirectLink:t,retry:n,isSpontaneousForm:r}=e;const{t:i}=(0,p.Bd)(),l=(0,o.d4)(E.rX),s=(0,M.GV)(E.Ht),m=(0,M.GV)(E.aD),u=s?.errorCode,g=s?.message,C=m?.errorCode;return a.createElement(A.A,{in:!0},a.createElement(x,{"data-testid":"cvc-application-error-content"},"application_requires_extra_steps"===u?a.createElement(w,{severity:"warning"},a.createElement(c.A,null,i("application.application_failed")),a.createElement("span",null,i(`error_code.${u}`)),a.createElement(D,{to:g,external:!0},i("application.complete_application"))):r?a.createElement(w,{severity:"error",iconMapping:{error:a.createElement(h.A,{View:y.cZ,fill:"#ff2a52"})}},a.createElement(c.A,null,i("application.spontaneous_application_failed")),a.createElement("span",null,i(u?`error_code.${C}`:"application.application_could_not_be_sent")),a.createElement(f,{onClick:n},i("application.retry"))):a.createElement(w,{severity:"error",iconMapping:{error:a.createElement(h.A,{View:y.cZ,fill:"#ff2a52"})}},a.createElement(c.A,null,i("application.application_failed")),a.createElement("span",null,i(u?`error_code.${u}`:"application.application_could_not_be_sent")),t&&a.createElement(b,null,i("application.retry_with_direct_access")),a.createElement(L,null,t&&a.createElement(d.g,{to:l.link,external:!0},i("application.redirect_button")),a.createElement(f,{onClick:n},i("application.retry"))))))};_.propTypes={showDirectLink:i().bool,retry:i().func}},28598:(e,t,n)=>{n.d(t,{TR:()=>s,AE:()=>o,pW:()=>d});var a=n(59123),r=n(7398),i=n(50405),l=n(23700);const o=(e,t,n)=>async(a,r)=>{const o=r();if(o.emailAlerts[e.resume_id]&&o.emailAlerts[e.resume_id].isSending)return;var s,c;a((s=e.email,c=e.resume_id,{type:l.r3,payload:{isSending:!0,email:s,resumeId:c}}));const d=await A(e),{status:p,value:m,reason:u}=d[0];"fulfilled"===p?(a(function(e,t,n){let a=!(arguments.length>3&&void 0!==arguments[3])||arguments[3];return{type:l._1,payload:{isSending:!1,email:e,resumeId:t,success:!0,status:n,emailSubscribeIsChecked:a}}}(e.email,e.resume_id,m,e.emailSubscribeIsChecked)),t&&(0,i.A)(t)&&t(m)):(a(((e,t,n)=>({type:l.m_,payload:{isSending:!1,email:e,resumeId:t,success:!1,err:{name:n.name,message:n.message,errorCode:n.errorCode,statusCode:n.statusCode}}}))(e.email,e.resume_id,u)),n&&(0,i.A)(n)&&n(u))},s=(e,t,n)=>async(a,r)=>{const o=r();if(o.emailAlerts[e.resumeId]&&o.emailAlerts[e.resumeId].isSending)return;a({type:l.pN,payload:{isSending:!0}});const s=await c(e),{status:A,reason:d}=s[0];var p;"fulfilled"===A?(a({type:l.zl,payload:{isSending:!1,success:!0}}),t&&(0,i.A)(t)&&t()):(a((p=d,{type:l.$j,payload:{isSending:!1,success:!1,err:p}})),n&&(0,i.A)(n)&&n(d))},A=async e=>Promise.allSettled([(0,a.ne)(e),(0,r.BK)(2e3)]),c=async e=>Promise.allSettled([(0,a.qC)(e),(0,r.BK)(2e3)]),d=e=>async t=>{try{t((e=>{let{email:t,details:n,status:a}=e;return{type:l.A9,payload:{isSending:!1,email:t,resumeId:n.resume_id,success:!0,status:a}}})(await(0,a.V_)(e)))}catch(n){t(((e,t)=>({type:l.Kb,payload:{isSending:!1,email:"",resumeId:e,success:!1,err:{name:t.name,message:t.message,errorCode:t.errorCode,statusCode:t.statusCode}}}))(e,n))}}},29298:(e,t,n)=>{n.d(t,{A:()=>_});var a=n(14041),r=n(50390),i=n(85426),l=n.n(i),o=n(85423),s=n(18307),A=n(50446),c=n(51902),d=n(68382),p=n(5369),m=n(80379),u=n(19555),g=n(84595),C=n(79015),f=n(33011),h=n(71804),y=n(95628),E=n(8877),M=n(97434),x=n(31048);const w={WIDGET_FILE_INPUT:"/",WIDGET_TOS:"/tos",WIDGET_ANALYSIS:"/analysis"},D=e=>{let{children:t,displayAnalysisInModal:n,open:r}=e;return n?a.createElement(g.aF,{open:r},t):r?t:null},b=e=>{let{route:t,MobileUploadZoneView:n,displayAnalysisInModal:r,submitFile:i,acceptTos:l,refuseTos:o,toggleEmailChecked:s,emailSubscribeIsChecked:A,startAnalysis:c}=e;const{t:d}=(0,M.Bd)();return a.createElement(f.R_,{id:n?"cv_upload":void 0},n&&t===w.WIDGET_FILE_INPUT&&a.createElement(n,{onFileChange:i}),a.createElement(D,{displayAnalysisInModal:r,open:t===w.WIDGET_TOS},a.createElement(f.D6,{displayAnalysisInModal:r},a.createElement(y.A,{acceptTos:l,refuseTos:o,toggleEmailChecked:s,emailSubscribeIsChecked:A,displayAnalysisInModal:r,i18nKey:"upload_zone.terms_of_use_text",acceptanceText:d("upload_zone.accept_terms_of_use")}))),a.createElement(D,{displayAnalysisInModal:r,open:t===w.WIDGET_ANALYSIS},a.createElement(C.A,{startAnalysis:c})))},L=e=>{let{displayAnalysisInModal:t,route:n,areEmailAlertsEnabled:r,submitFile:i,acceptTos:l,refuseTos:s,toggleEmailChecked:A,emailSubscribeIsChecked:c,startAnalysis:d}=e;const{t:p}=(0,M.Bd)(),m=(0,o.GV)(x.Vs);return a.createElement(f.uM,{currentPage:m,route:w.WIDGET_FILE_INPUT,emailAlerts:r},(n===w.WIDGET_FILE_INPUT||t)&&a.createElement(h.Ay,{onFileChange:i}),a.createElement(D,{displayAnalysisInModal:t,open:n===w.WIDGET_TOS},a.createElement(f.d4,{route:n,displayAnalysisInModal:t},a.createElement(y.A,{acceptTos:l,refuseTos:s,toggleEmailChecked:A,emailSubscribeIsChecked:c,displayAnalysisInModal:t,i18nKey:"upload_zone.terms_of_use_text",acceptanceText:p("upload_zone.accept_terms_of_use")}))),a.createElement(D,{displayAnalysisInModal:t,open:n===w.WIDGET_ANALYSIS},a.createElement(C.A,{startAnalysis:d})))};function _(e){let{postAnalysisCallback:t,mobileUploadZoneView:n,displayMobileAnalysisInModal:i=!1,displayAnalysisInModal:g=!1}=e;const C=(0,o.jL)(),{config:f}=(0,a.useContext)(p.Qj),h=(0,s.Gb)(),[y,M]=(0,a.useState)(null),[x,D]=(0,a.useState)(w.WIDGET_FILE_INPUT),[_,I]=(0,a.useState)(!1),v=e=>{I(e)},N=()=>{const e={file:y,filename:y?.name,consent_given:!0,email_alerts_subscribe:_};D(w.WIDGET_ANALYSIS);const t=d.M$.UPLOAD_RESUME,n={page:u.Bd.HOME,subscribed_to_email_alerts:h?_:null};C((0,d.Wf)(t,n)),k(e)},k=async e=>{C((0,A.sm)()),await C((0,c.Cv)(e,e=>{if(t)t();else{setTimeout(()=>{const e=new URLSearchParams(window.location.search),t=m.J.SEARCH+"?"+e.toString();C((0,r.VC)(t))},e?8e3:3e3)}}))},j=()=>{M(null),D(w.WIDGET_FILE_INPUT)},z=e=>{const t=0!==e?.length,n=e[0];t?(f?.widget?.display_tos?(M(n),D(w.WIDGET_TOS)):(M(n),N()),f?.analytics?.google_tag_manager?.active&&l().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Upload Zone",EventAction:"Depot CV",EventLibelle:"[LP] - Depot CV"}})):M(null)},T=()=>{D(w.WIDGET_FILE_INPUT)};return n?a.createElement(a.Fragment,null,a.createElement(E.rb,{down:!0},a.createElement(b,{acceptTos:N,displayAnalysisInModal:i,emailSubscribeIsChecked:_,MobileUploadZoneView:n,refuseTos:j,route:x,startAnalysis:T,submitFile:z,toggleEmailChecked:v})),a.createElement(E.X8,{up:!0},a.createElement(L,{acceptTos:N,displayAnalysisInModal:g,emailSubscribeIsChecked:_,refuseTos:j,route:x,areEmailAlertsEnabled:h,startAnalysis:T,submitFile:z,toggleEmailChecked:v}))):a.createElement(L,{acceptTos:N,displayAnalysisInModal:g,emailSubscribeIsChecked:_,refuseTos:j,route:x,areEmailAlertsEnabled:h,startAnalysis:T,submitFile:z,toggleEmailChecked:v})}},33011:(e,t,n)=>{n.d(t,{D6:()=>p,Kq:()=>s,R_:()=>d,d4:()=>c,uM:()=>A});var a=n(2345),r=n(45728),i=n(38036);const l="/tos",o="/analysis",s=a.AH`
  position: fixed;
  z-index: 11;
  bottom: 32px;
  right: 32px;
  max-width: min-content;
  min-width: min(100%, 320px);
  background-color: white;
  border-radius: 10px;
  box-shadow: rgba(0, 0, 0, 0.4) 0 1px 6px;
`,A=a.Ay.div`
  transition: all 300ms ease;
  width: 100%;

  ${e=>{let{theme:t,currentPage:n}=e;return(t.template!==r.tC.BENTO_2024&&t.template!==r.tC.PIPE_2025||n!==i.m.HOME)&&`\n    ${s};\n  `}}

  ${e=>{if(e.route===l)return"\n      min-height: 240px;\n      width: 320px;\n      background-color: white;\n      border-radius: 10px;\n    "}}

  ${e=>{if(e.route===l&&e.emailAlerts)return"\n      height: auto;\n      max-height: 310px;\n      min-height: 240px;\n      width: 360px;\n      padding: 25px 0;\n    "}}
  
  ${e=>{if(e.route===o)return"\n      height: 360px;\n      width: 360px;\n    "}}
`,c=a.Ay.div`
  position: relative;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  z-index: 1;
  transition: all 300ms ease;
  background-color: white;
  padding: ${e=>{let{displayAnalysisInModal:t}=e;return t?"0":"24px"}};

  ${e=>{let{displayAnalysisInModal:t,route:n}=e;return!0===t?"\n      max-width: 532px\n      ":n===o?"\n      align-items: flex-start;\n      overflow: hidden;\n    ":void 0}}
`,d=a.Ay.div`
  display: block;
  padding: ${e=>{let{theme:t}=e;return t.template!==r.tC.BENTO_2024&&"20px 20px 0px 20px"}};

  ${e=>{if(e.route===o)return"\n    height: 360px;\n    width: 360px;\n    "}}
`,p=a.Ay.div`
  border: ${e=>{let{theme:t}=e;return`solid 1px ${t.palette.secondary.main}`}};
  border-radius: 10px;
  background-color: white;
  padding: ${e=>{let{displayAnalysisInModal:t}=e;return t?"0":"24px"}};
`},33515:(e,t,n)=>{function a(e){return"string"==typeof e?parseInt(e,10)/1024:e/1024}n.d(t,{M:()=>a})},35560:(e,t,n)=>{n.d(t,{K:()=>ne});var a=n(14041),r=n(2345),i=n(39067),l=n.n(i),o=n(97434),s=n(38544),A=n(95628),c=n(61631),d=n(74798),p=n(24586),m=n(47566),u=n(66576),g=n(17710),C=n(80503),f=n(87961),h=n(69421),y=n(86090),E=n(82202),M=n(33131),x=n(66341),w=n(36080);const D=r.Ay.div`
  background-color: var(--landing-analyse-background-color);
  border-radius: 5px;
  min-height: 300px;
  padding: 20px;
  font-family: var(--regular-text-font);

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    padding: 30px;
  }
`,b=r.Ay.div`
  display: flex;
  justify-self: center;
  flex-direction: row;
  flex-wrap: wrap;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    display: block;
  }
`,L=r.Ay.div`
  width: 100px;
  margin: 0 auto;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    max-width: 160px;
    float: left;
    margin-right: 40px;

    ${e=>{let{isTiny:t}=e;return t&&"\n    margin: 0;\n    align-self: center;\n    float: none;\n  "}}
  }

  svg {
    fill: ${e=>{let{theme:t}=e;return(0,c.x6)(t.palette,"secondary","light")}};
  }
`,_=r.Ay.div`
  align-self: center;
  font-family: var(--regular-text-font);
  font-size: 20px;
  font-weight: 300;
  margin: 0 auto 25px;
  min-width: 120px;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    ${e=>{let{isTiny:t}=e;return t&&"\n      display: flex;\n      align-self: center;\n      margin: 0 0 0 20px;\n  "}}
  }
  ${e=>{let{err:t}=e;return t&&"display: none;"}}
`,I=r.Ay.div`
  color: #1f3038;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    display: inline-block;
    width: 55%;
    margin-left: 5px;
    ${e=>{let{isTiny:t}=e;return t&&"\n      width: 100%;\n    "}}
  }
`,v=r.Ay.div`
  margin-bottom: 15px;
`,N=r.Ay.div`
  display: flex;
  align-items: center;
`,k=r.Ay.div`
  svg {
    display: flex;
    width: 20px;
  }
`,j=r.Ay.p`
  padding-left: 10px;
  font-size: 14px;
`,z=r.Ay.div`
  font-size: 14px;
  ${e=>{let{err:t}=e;return t&&"\n    display: none;\n  "}}
`,T=r.Ay.div`
  position: relative;
  top: 5px;
  left: 8px;
  padding: 10px 15px;
  border-left: 3px solid rgba(59, 134, 255, 0.1);
`,O=r.Ay.p`
  margin: 0;
  font-size: 12px;
  color: #7d8397;
  & > strong {
    font-family: var(--regular-text-font);
    font-size: 14px;
    font-weight: bold;
  }
`,Q=r.Ay.span`
  font-family: var(--regular-text-font);
  font-size: 16px;
  font-weight: bold;
`,S=r.Ay.div`
  padding-left: 30px;
  font-family: var(--regular-text-font);
`,P=r.Ay.p`
  margin: 0 0 20px 0;
  font-style: italic;
  font-size: 12px;
  ${e=>{let{color:t}=e;return`\n    color: ${t}\n  `}}
`,B=r.Ay.button`
  background-color: var(--button-background-color);
  color: #ffffff;
  font-size: 14px;
  font-weight: 600;
  padding: 13px 19px;
  border-radius: 2px;
  cursor: pointer;
  transition: background-color 0.4s;
  &:hover {
    filter: var(--button-background-color-on-hover);
  }
`,V=(0,r.Ay)(m.A)`
  color: ${w.wV[500]};
`,$=()=>{const e=(0,s.d4)(e=>e.search.isFetching);return(0,s.d4)(e=>e.applications[e.currentJobOffer?.id]?.err)?a.createElement(M.A,{View:x.cZ,fill:w.$D[500],style:{height:"fit-content"}}):e?a.createElement(V,{size:20}):a.createElement(M.A,{View:x.KD,fill:w.wV[500],style:{height:"fit-content"}})};class F extends a.Component{constructor(e){super(e),(0,p.A)(this,"onEndTransition",(e,t)=>{this.nextStep(t)}),(0,p.A)(this,"nextStep",e=>{const{profile:t}=this.props;t&&setTimeout(()=>{this.setState({nextStep:!0}),e()},1e3)}),(0,p.A)(this,"renderRetryAfterError",()=>{const{t:e}=this.props;return this.props.profileError&&400===this.props.profileError.statusCode?a.createElement(S,null,a.createElement(P,null,e("profile_analysis.error_file")),a.createElement(B,{onClick:()=>this.props.tryAgainAnalyse()},e("profile_analysis.retry"))):a.createElement(S,null,a.createElement(P,null,e("profile_analysis.error_analyse")),a.createElement(B,{onClick:()=>this.props.tryAgainAnalyse()},e("profile_analysis.retry")))}),(0,p.A)(this,"renderProfileCheckmark",()=>this.props.profileError?a.createElement(M.A,{View:x.cZ,fill:w.$D[500],style:{height:"fit-content"}}):this.props.isFetchingProfile?a.createElement(V,{size:20}):a.createElement(M.A,{View:x.KD,fill:w.wV[500],style:{height:"fit-content"}})),this.state={nextStep:!1,isTiny:!1},this.nodeRef=(0,a.createRef)()}componentDidMount(){this.nodeRef.current.clientWidth<=390&&this.setState({isTiny:!0})}render(){const{t:e}=this.props;return a.createElement(D,{ref:this.nodeRef},a.createElement(b,null,this.props.profileError&&400===this.props.profileError.statusCode?a.createElement(f.G,{isTiny:this.props.isTiny}):a.createElement(L,{isTiny:this.props.isTiny},a.createElement(h.MH,{height:"100%",width:"100%"})),a.createElement(_,{err:this.props.err,isTiny:this.props.isTiny},e("profile_analysis.title")),a.createElement(I,{isTiny:this.props.isTiny},a.createElement(v,null,a.createElement(N,null,a.createElement(k,null,a.createElement(g.A,null,a.createElement(C.A,{key:!this.props.isFetchingProfile,addEndListener:(e,t)=>e.addEventListener("transitionend",t,!1),classNames:"checkmark"},a.createElement("div",null,this.renderProfileCheckmark())))),a.createElement(j,null,e("profile_analysis.profile_and_skills_analysis"))),!this.props.isFetchingProfile&&this.props.profileError&&this.renderRetryAfterError(),a.createElement(u.A,{in:!this.props.isFetchingProfile&&!this.props.profileError,addEndListener:this.onEndTransition},a.createElement(T,null,this.props.profile&&a.createElement(O,null,a.createElement("span",null,e("profile_analysis.hello")),this.props.profile.identity.first_name&&a.createElement(Q,null," ",this.props.profile.identity.first_name),",")))),a.createElement(u.A,{in:this.state.nextStep,mountOnEnter:!0},a.createElement(z,null,a.createElement(N,null,a.createElement(k,null,a.createElement(u.A,{in:!0},a.createElement("div",null,a.createElement($,null)))),a.createElement(j,null,e("application.application_preparation"))),this.props.applicationError&&this.renderRetryAfterError())))))}}F.propTypes={applicationError:l().object,isFetchingProfile:l().bool,jobOffer:l().object,profile:l().shape({identity:l().shape({first_name:l().string})}),profileError:l().shape({code:l().number})};const Z=(0,y.y)((0,s.Ng)(e=>({applicationError:e.applications[e.currentJobOffer.id]&&e.applications[e.currentJobOffer.id].err,isFetchingProfile:e.profile.isFetching,isFetchingJobOffers:e.search.isFetching,jobOffer:e.jobOffers[e.currentJobOffer.id],profile:e.profile,profileError:e.profile.err}),(e,t)=>({tryAgainAnalyse:()=>{e((0,E.sb)()),t.retryAnalysis(!1),t.termsOfService&&t.termsOfService(!1)}}))((0,o.CI)()(F)));var G=n(306),R=n(23099),H=n(19555),U=n(68153),Y=n(33515);const W=r.Ay.div`
  display: flex;
`,J=r.Ay.p`
  font-size: 16px;
  color: ${e=>{let{theme:t}=e;return t.palette.error.main}};
`,K=r.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,X=r.Ay.div`
  position: relative;
  display: block;
  max-width: fit-content;
  padding: 16px 24px;
  border-radius: 6px;
  background-color: ${e=>{let{theme:t}=e;return(0,c.x6)(t.palette,c.Fl,c.Xs)}};
  transition: ${e=>{let{theme:t}=e;return`${t.transitions.duration.standard}ms ease`}};

  &:hover,
  &:focus {
    transform: scale(1.05);
  }

  input {
    cursor: pointer;
    position: absolute;
    left: 0;
    top: 0;
    display: block;
    width: 100%;
    height: 100%;
    opacity: 0;
  }
`,q=r.Ay.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,ee=(0,r.Ay)(d.A)`
  font-weight: 600;
  line-height: 1.25;
  margin: 0;
`,te=r.Ay.div`
  margin: 0 auto;
  width: 100%;
`,ne=e=>{let{acceptTos:t,toggleEa:n,changeFile:r}=e;const{t:i}=(0,o.Bd)(),{config:l}=(0,U._r)(),c=(0,s.wA)(),[d,p]=(0,a.useState)(!0),[m,u]=(0,a.useState)(!1),[g,C]=(0,a.useState)(!1),[f,h]=(0,a.useState)(!1),y=(0,s.d4)(e=>e.applications[e.currentJobOffer.id]),E=y?.success,w=l?.resumeMaxSizeKo&&1024*l.resumeMaxSizeKo||H.we;return a.createElement(W,null,d&&!E&&a.createElement(K,null,a.createElement(X,null,a.createElement(q,null,a.createElement(M.A,{View:x.nR,size:24,withContrast:!0}),a.createElement(ee,{autoContrast:!0},i("upload_zone.title_2022"))),a.createElement("input",{"data-testid":"cvc-resume-upload-input",type:"file",onChange:e=>{const t=e.target.files[0];if(t&&t.size>w)return C(!0),void(0,R.Bl)(t.size);C(!1),p(!1),u(!0),r(event.target.files)}})),g&&a.createElement(J,null,i("upload_zone.file_size_error",{maxSize:(0,Y.M)(w)}))),m&&a.createElement(A.A,{acceptTos:()=>{p(!1),u(!1),t()},refuseTos:()=>{p(!0),u(!1),c((0,G.xD)(!1))},toggleEmailChecked:e=>{n(e),h(e),e&&(0,R.oU)("generic",{event_name:"email_subscribe"})},emailSubscribeIsChecked:f,i18nKey:"application.terms_of_use_text",acceptanceText:i("application.accept_terms_of_use")}),!d&&!m&&a.createElement(te,null,a.createElement(Z,{retryAnalysis:e=>{p(!e),u(!1)}})))};ne.propTypes={acceptTos:l().func,toggleEa:l().func,changeFile:l().func}},35772:(e,t,n)=>{n.d(t,{Ay:()=>d,oe:()=>A});var a=n(14041),r=n(39067),i=n.n(r),l=n(2345),o=n(61631);const s=l.Ay.svg`
  polygon,
  polyline,
  circle,
  path,
  line {
    stroke: var(--primary-color);
  }
`,A=l.AH`
  ${s} {
    polygon,
    polyline,
    circle,
    path,
    line {
      stroke: ${e=>{let{theme:t}=e;return(0,o.x6)(t.palette,o.Fl,o.Xs)}} !important; // Sorry about that. This is to override the inline-style of an old component
    }
  }
`;class c extends a.Component{render(){const{height:e,color:t}=this.props;return a.createElement(s,{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 22 28",height:e},a.createElement("polygon",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",points:"16.5 27.5 0.5 27.5 0.5 0.5 21.5 0.5 21.5 22.5 16.5 27.5"}),a.createElement("polyline",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",points:"21.5 22.5 16.5 22.5 16.5 27.5"}),a.createElement("circle",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",cx:"11",cy:"6.5",r:"2"}),a.createElement("path",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",d:"M8.92,13.67A4.26,4.26,0,0,1,12.5,12a4.26,4.26,0,0,1,3.58,1.67",transform:"translate(-1.5 -1.5)"}),a.createElement("circle",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",cx:"11",cy:"8",r:"5.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"6.5",y1:"15.5",x2:"15.5",y2:"15.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"7.5",y1:"17.5",x2:"13.5",y2:"17.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"3.5",y1:"20.5",x2:"8.5",y2:"20.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"11.5",y1:"20.5",x2:"18.5",y2:"20.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"3.5",y1:"22.5",x2:"8.5",y2:"22.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"10.5",y1:"22.5",x2:"14.5",y2:"22.5"}),a.createElement("line",{style:{stroke:t},fill:"none",strokeLinecap:"round",strokeLinejoin:"round",x1:"3.5",y1:"24.5",x2:"14.5",y2:"24.5"}))}}c.propTypes={height:i().string,color:i().string},c.defaultProps={height:"auto",color:"#1F3038"};const d=c},40126:(e,t,n)=>{n.d(t,{Y9:()=>C,B3:()=>g,h9:()=>m});var a=n(14041),r=n(97434),i=n(2345);let l=function(e){return e.CLASSIC_2022="classic-2022",e.HORIZONTAL_BAR_2022="horizontal-bar-2022",e.LATERAL_BAR_2022="lateral-bar-2022",e.BENTO_2024="bento-2024",e.PIPE_2025="pipe-2025",e}({});var o=n(85423),s=n(68153),A=n(80379),c=n(33106),d=n(45890),p=n(92241);const m=i.Ay.header`
  --header-max-height: var(--landing-cover-carousel-margin-top);
  --header-padding: 32px;

  width: 100%;
  max-height: var(--header-max-height);
  padding: var(--header-padding);
  display: flex;
  justify-content: center;
  position: ${e=>{let{position:t}=e;return t}};
  top: 0;
  z-index: 2;
  background-color: ${e=>{let{theme:t,transparent:n}=e;return n?"transparent":t.palette.primary.main}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    --header-max-height: var(--landing-cover-carousel-margin-top-mobile);
    --header-padding: 24px;
  }

  ${e=>{let{theme:t,isHomePage:n}=e;if(t.template!==l.LATERAL_BAR_2022)return;let a="";return a+=` \n        ${t.breakpoints.down("laptop")} {\n          position: absolute;\n          top: 0;\n        }\n      `,n&&(a+=`\n        @media (min-width: ${t.breakpoints.values.laptop}px) and (max-height: 830px) {\n          padding-top: 0;\n        }\n      `),a}}
`,u=i.Ay.div`
  height: 100%;
  margin: 0;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;

  span {
    display: block;
    height: 0;
    text-indent: -9999px;
  }

  img {
    --image-max-height: 160px;

    display: block;
    height: 100%;
    width: 100%;
    max-height: var(--image-max-height);
    max-width: min(50vw, 300px);
    object-fit: contain;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
      --image-max-height: 120px;
    }

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      --image-max-height: 80px;
    }

    ${e=>{let{theme:t,isHomePage:n}=e;return t.template===l.LATERAL_BAR_2022&&n&&`\n      @media (min-width: ${t.breakpoints.values.laptop}px) and (max-height: 830px) {\n        max-width: 185px;\n        max-height: 80px;\n      }\n    `}}
  }
`,g=e=>{let{children:t,className:n,position:r="absolute",transparent:i=!1}=e;const{isHomePage:l}=(0,o.a8)();return a.createElement(m,{"data-print-hidden":!0,transparent:i,position:r,isHomePage:l,className:n},t)};g.RouterLink=()=>{const{isHomePage:e}=(0,o.a8)(),{config:t}=(0,s._r)(),{t:n}=(0,r.Bd)(),i=(0,o.Pn)(),l=n("seo_markup.career_site_home_page.title",{clientName:t.company_name});return a.createElement(p.E,{to:A.J.HOME},a.createElement(u,{as:e?"h1":"div",isHomePage:e},a.createElement("span",null,l),i&&a.createElement("img",{src:(0,c.xI)(t),alt:`Logo ${t.company_name}`})))};const C=e=>{const t=(0,o.XV)();return a.createElement(g,e,a.createElement(g.RouterLink,null),t&&a.createElement(d.L,null))}},41593:(e,t,n)=>{n.d(t,{c:()=>K});var a=n(14041),r=n(38544),i=n(43322),l=n(68072),o=n(85426),s=n.n(o),A=n(97434),c=n(19274),d=n(50405),p=n(306),m=n(59123),u=n(492),g=n(31048),C=n(23099);const f=e=>{(0,C.oU)("transaction.confirmation",e),(0,C.oU)("product.purchased",e)},h=async(e,t,n,a,r,i)=>{const l=n();if(!l.applications[e.jobOfferId]||!l.applications[e.jobOfferId].isSending){a((0,p.Nf)(e.jobOfferId));try{await(0,m.sr)(e),a((0,p.I2)(e.jobOfferId)),f(t),u.A.addApplication(e.resumeId,e.jobOfferId),r&&(0,d.A)(r)&&r()}catch(t){a((0,p.W6)(e.jobOfferId,t)),i&&(0,d.A)(i)&&i()}}},y=async(e,t,n,a,r)=>{n((0,p.W5)());try{await(0,m.b9)(e),n((0,p.$r)()),f(t),u.A.addSpontaneousApplication(e.resumeId),a&&(0,d.A)(a)&&a()}catch(e){n((0,p.l4)(e)),r&&(0,d.A)(r)&&r()}},E=(e,t,n,a,r)=>async i=>{i(n?((e,t,n,a)=>async(r,i)=>{const l=i();if(!(0,g.gk)(l)){r((0,p.W5)());try{await(0,m.$F)(e,!0),setTimeout(()=>{r((0,p.$r)()),f(t),u.A.addSpontaneousApplication(e.resumeId),n&&(0,d.A)(n)&&n()},2e3)}catch(e){r((0,p.l4)("spontaneous-application",e)),a&&(0,d.A)(a)&&a()}}})(e,t,a,r):((e,t,n,a)=>async(r,i)=>{const l=i();if(!l.applications[e.jobOfferId]||!l.applications[e.jobOfferId].isSending){r((0,p.Nf)(e.jobOfferId));try{await(0,m.$F)(e),setTimeout(()=>{r((0,p.I2)(e.jobOfferId)),f(t),u.A.addApplication(e.resumeId,e.jobOfferId),n&&(0,d.A)(n)&&n()},2e3)}catch(t){r((0,p.W6)(e.jobOfferId,t)),a&&(0,d.A)(a)&&a()}}})(e,t,a,r))};var M=n(68382),x=n(82202),w=n(7398),D=n(68153),b=n(98012),L=n(85423),_=n(29085),I=n(87484),v=n(95839),N=n(32167),k=n(25509),j=n(19442),z=n(44512),T=n(58917),O=n(63832),Q=n(68114);const S="CIVILITY",P="COUNTRY",B={LAST_NAME:"identity.last_name",FIRST_NAME:"identity.first_name",EMAIL:"identity.email",PHONE:"identity.phone",CIVILITY:"identity.civility",ADDRESS:"identity.address",POSTALCODE:"identity.postalcode",CITY:"identity.city",COUNTRY:"identity.country"},V=(e,t)=>B[e.id]?B[e.id].split(".").reduce((e,t)=>e[t],t):null,$={fr:I,en:v,de:N,ja:k,zh:j,pt:z,it:T,es:O,nl:Q},F=function(e,t,n){let a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"fr";const r={};return e.ats_required_fields.forEach(i=>{switch(i.id){case P:r[i.api_name]=((e,t,n)=>{_.registerLocale($[n]||I);const a=_.getNames(n,{select:"official"});return{...t,value:e,options:Object.keys(a).map(e=>({value:e,placeholder:a[e]}))}})(t.identity.country,i,a);break;case S:r[i.api_name]=function(){let e=arguments.length>1?arguments[1]:void 0,t=arguments.length>2?arguments[2]:void 0,n=arguments.length>3?arguments[3]:void 0,a=e;"sap"===(arguments.length>0&&void 0!==arguments[0]?arguments[0]:"").toLowerCase()&&(a={male:1142,female:1141}[e]||"");return{...t,value:a,options:t.options.map(e=>({...e,value:n(`application.enums.CIVILITY.${e.value}`,e.value?e.value.toString():""),placeholder:n(`application.enums.CIVILITY.${e.placeholder}`,e.placeholder)}))}}(e.ats||e.atsConnectName,t.identity.gender,i,n);break;default:r[i.api_name]={...i,value:V(i,t)||"",error:null}}}),r};var Z=n(8049),G=n(14575);const R=e=>{let t;try{t=(0,Z.Wo)(e)}catch(n){t=e}return t};var H=n(46927);class U{static buildCommonRequestForJobOfferApplication(e,t,n,a){return{...e,origin:t||null,source:n,jobOfferReference:a.reference,jobOfferId:a.id,jobOfferTitle:a.title,recipient:a.partner_specific_fields&&a.partner_specific_fields.emailPage||null,partner:a.partner}}static buildRequestForJobOfferApplication(e,t){return{...e,resumeId:t.id}}static async buildRequestForApplicationWithoutResume(e,t){const n=await H.I.generatePdfResume(e,t),a=await H.I.getBlobFromFile(n),r=new File([a],`${e.first_name}-${e.last_name}-generated-resume`,{type:"application/pdf"});return{...e,resume:r}}static buildRequestForSpontaneousApplication(e,t,n,a){return{...e,resumeId:a.id,origin:t||null,source:n,jobOfferTitle:"Candidature spontanée",isSpontaneousApplication:!0}}}var Y=n(63511),W=n(26532),J=n.n(W);const K=e=>{let{view:t,isSpontaneousForm:n}=e;const{config:o}=(0,D._r)(),{t:d,i18n:p}=(0,A.Bd)(),m=(0,r.wA)(),u=(0,L.d7)(),f=(0,L.GV)(g.To),_=(0,L.GV)(g.rX),I=(0,L.GV)(g.w5),v=(()=>{const{t:e}=(0,A.Bd)();return[{id:"FIRST_NAME",api_name:"first_name",type:"text",placeholder:e("application.ats_required_fields.FIRST_NAME")},{id:"LAST_NAME",api_name:"last_name",type:"text",placeholder:e("application.ats_required_fields.LAST_NAME")},{id:"EMAIL",api_name:"email",type:"email",placeholder:e("application.ats_required_fields.EMAIL")},{id:"PHONE",api_name:"phone",type:"text",placeholder:e("application.ats_required_fields.PHONE")}]})();let N=(0,w._Z)(o,_?.partner,n,v);const[k,j]=(0,a.useState)(()=>{const e=F(N,f,d,p.language);return _?.questions&&_.questions.forEach(t=>{const n=t.type?.toLowerCase(),a=t.format?.toLowerCase();e[`question--${t.order}`]={question:t.question,id:t.id,api_name:`question--${t.order}`,type:n,format:a,limit:t.limit,max:t.max,min:t.min,options:t.options,error:null,value:"select"===n?t.options[0].label||t.options[0].value:null,order:t.order}}),e}),[z,T]=(0,a.useState)({cover_letter:{placeholder:d("application.cover_letter_placeholder"),name:"cover_letter",value:null,error:null}}),O=o?.brands,Q=O?.map(e=>e.name),S=[{value:"",placeholder:""}];Q?.map(e=>{S.push({value:e,placeholder:e})});const[P,B]=(0,a.useState)({entity:{id:"ENTITY",api_name:"entity",type:"select",placeholder:d("application.ats_required_fields.ENTITY"),value:"",error:null,is_required:!1,options:S}}),[V,$]=(0,a.useState)({linkedin:{placeholder:d("application_without_resume.linkedin_placeholder"),name:"linkedin",value:null,error:null}}),[H,W]=(0,a.useState)(!o.features?.display_application_form_terms_of_service),[K,X]=(0,a.useState)(!1),[q,ee]=(0,a.useState)(!1);(0,a.useEffect)(()=>{o.analytics?.google_tag_manager?.active&&s().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Bloc",EventAction:"Visible",EventLibelle:"[DO] - Formulaire récapitulatif"}})},[o.analytics?.google_tag_manager?.active]),(0,a.useEffect)(()=>{u(()=>{m((0,x.Nj)(f.id,{first_name:k?.first_name?.value,last_name:k?.last_name?.value,email:k?.email?.value,phone:k?.phone?.value,civility:k.civility?.value,address:k.address?.value,postalcode:k.postalcode?.value,city:k.city?.value,country:k.country?.value}))},600)},[u,m,k,f.id]);const te=e=>{let t,n;switch(e){case"cover_letter":t=z,n=T;break;case"entity":t=P,n=B;break;case"linkedin":t=V,n=$;break;default:t=k,n=j}return{formField:t,setFormField:n}},ne=(e,t,n)=>{t(()=>({...e,[n]:{...e[n],error:null}}))};return a.createElement(t,{linkedinField:V,coverLetterField:z,entityField:P,formFields:k,isSpontaneousForm:n,inputChange:e=>{const t=e.target,n=t.name,a=["decimal","numeric"].includes(e.target.inputMode);let r=t.value;a&&(r=isNaN(+r)?null:+r);let{formField:i,setFormField:l}=te(n);l({...i,[n]:{...i[n],value:r}})},inputFocus:e=>{const t=e.target.name;let{formField:n,setFormField:a}=te(t);n[t].error&&ne(n,a,t)},formSubmit:async e=>{e.preventDefault();const{atsConnectConfigId:t,ats:a}=N,r=(()=>{const e=(0,i.A)(k);let t=e.length;return Object.values(e).forEach(e=>{let n=null;e.value||(t--,n=d("application.required_field")),"email"!==e.type||(0,b.xf)(e.value)||(t--,n=d("application.invalid_email")),e.error=n}),j(e),t===e.length})(),A=(()=>{const e=(0,i.A)(V);let t=null;return!e.linkedin.value||((0,Z.fh)(e.linkedin.value)||(t=d("application_without_resume.invalid_linkedin_profile"),e.linkedin.error=t,$(e)),(0,Z.fh)(e.linkedin.value))})(),p=r&&A;if(H||X(!0),H&&p){m(n?(0,M.Nu)(M.M$.SPONTANEOUS_SEND_APPLICATION_BTN_CLICK,o.company_name,!!z.cover_letter.value):(0,M.NX)(M.M$.JOB_SEND_APPLICATION_BTN_CLICK,_.id,f.attachment_file_name?Y.Wn:Y.RC)),o.analytics?.google_tag_manager?.active&&s().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Application Button",EventAction:"Candidature",EventLibelle:"[DO] - Postuler"}});const e=()=>f.id?"cv":V?.linkedin?.value?"linkedin":"without_cv",r={transaction_id:J()(),method:e(),product_data:[(0,C.h6)(_)]},i=new URLSearchParams(window.location.search);let A=i.get("idOrigine");A||(A=i.get("idOrigin"));const d=(e=>{const t=sessionStorage.getItem(G.eL);let n=null;t&&(n=JSON.parse(t).utm_source);const a=e.get("utm_source")||n||document.referrer;let r="CV Catcher";return a&&(r=`${R(a)} (${r})`),r})(i),p=(0,l.A)(k,z,P,V),u=Object.keys(p).reduce((e,t)=>{const n=p[t];if(t.includes("question--"))e.questionsAndAnswers||(e.questionsAndAnswers=[]),e.questionsAndAnswers.push({question:{id:n.id,order:n.order},answer:n.value});else if("PHONE"===n.id){const r=(0,c.G)(a);e[t]=r.formatPhoneNumber(n.value)}else("ENTITY"!==n.id||n.value)&&(e[t]=n.value);return e},{}),g=_&&U.buildCommonRequestForJobOfferApplication(u,A,d,_);let x;f.id?x=n?U.buildRequestForSpontaneousApplication(u,A,d,f):U.buildRequestForJobOfferApplication(g,f):(ee(!0),x=await U.buildRequestForApplicationWithoutResume(g,_),ee(!1)),N.email_type&&(x.email_type=N.email_type),t?n&&o.features?.spontaneousApplication?.email?m(E(x,r,n)):(x.partner=(0,w.X3)(o,x.partner),m(((e,t,n,a,r)=>async(i,l)=>{n?await y(e,t,i,a,r):await h(e,t,l,i,a,r)})(x,r,n))):m(E(x,r,n))}},isTosChecked:H,tosChange:e=>{W(e)},displayTosError:K,isSending:I,isLoadingPdfBuilder:q})}},43500:(e,t,n)=>{n.d(t,{r:()=>vn});var a=n(14041),r=n(86090),i=n(85423),l=n(80379),o=n(89575),s=n(75992),A=n(38544),c=n(62004),d=n(2345),p=n(61160),m=n(306),u=n(3927),g=n(26270),C=n(68382),f=n(59437),h=n(39067),y=n.n(h),E=n(97434),M=n(66341),x=n(65563),w=n(58797),D=n(31048);const b=(0,d.Ay)(x.$n)`
  position: fixed;
  left: 50%;
  bottom: 32px;
  z-index: 2;
  transform: translate(-50%, 0);
  max-width: 300px;
  display: flex;
  box-shadow: ${e=>{let{theme:t}=e;return t.shadows[2]}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    left: auto;
    right: 24px;
    bottom: 12px;
    transform: none;
    padding: 16px;
    border-radius: 50%;
  }
`,L=d.Ay.span`
  display: block;
  text-align: left;
  border-left: 1px solid;
  margin-left: 8px;
  padding-left: 8px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    display: none;
  }
`,_=e=>{let{scrollTo:t}=e;const{t:n}=(0,E.Bd)(),r=(0,i.GV)(D.vD),l=r?n("job_details_page.apply_with_profile_2022",{firstname:r}):n("job_details_page.apply_2022");return a.createElement(b,{"data-print-hidden":!0,onClick:t,"data-testid":"cvc-apply-btn",size:"large"},a.createElement(w.h_,{View:M.nR,size:48,withContrast:!0}),a.createElement(L,null,l))};_.propTypes={scrollTo:y().func};var I=n(84234),v=n(92983),N=n(97134),k=n(89618),j=n(47056),z=n(36080),T=n(43895),O=n(17678),Q=n(68153),S=n(91831),P=n(76001),B=n(70855),V=n(33131),$=n(97985),F=n(52519),Z=n(8049),G=n(61631),R=n(32673),H=n(37529),U=n(80012),Y=n(77935),W=n(84595);const J=d.Ay.a`
  cursor: pointer;
`,K=e=>{let{size:t,handleCloseModal:n,sharingTracker:r}=e;return a.createElement(J,{"data-testid":"cvc-share-btn-print",onClick:async()=>{r(C.M$.SHARE_JOB_OFFER_ACTION,"print"),await n(),await window.print()}},a.createElement(V.A,{View:M.mC,size:t,withContrast:!0}))};var X=n(13761),q=n.n(X);const ee="facebook",te="twitter",ne="linkedin",ae="email",re=d.Ay.a.attrs({target:"_blank",rel:"noreferrer"})``,ie=e=>{let{size:t,socialNetworkName:n,sharingTracker:r}=e;const{t:i}=(0,E.Bd)(),l=(0,S.dX)(),{config:o}=(0,Q._r)(),s=`${window.location.href}?utm_source=cvcatcher-sharing&utm_medium=${n}`,A=`${i("share.texte_to_share.text",{company:o.company_name,jobTitle:l.title,url:s})}`,c=`cvc-share-btn-${n}`;return a.createElement(re,{"data-testid":c,onClick:()=>{r(C.M$.SHARE_JOB_OFFER_ACTION,n)},href:q()[n]({url:s,u:s,text:A,to:"",body:A})},((e,t)=>{switch(e){case ee:return a.createElement(V.A,{View:M.GA,size:t,fill:"#1877f2"});case ne:return a.createElement(V.A,{View:M.US,size:t,fill:"#0077B5"});case te:return a.createElement(V.A,{View:M.fO,size:t,fill:"#000"});default:return a.createElement(V.A,{View:M.jQ,size:t,withContrast:!0})}})(n,t))};ie.propTypes={size:y().number,socialNetworkName:y().oneOf([ee,ne,te,ae]).isRequired};const le=["facebook","linkedin","twitter","email"],oe=(0,d.Ay)(W.aF)`
  min-width: 35vw;
`,se=d.Ay.div`
  display: flex;
  justify-content: space-evenly;
  align-items: center;

  padding: 8px 0 8px;
  @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    margin: auto;
    gap: 32px;
    justify-content: center;
  }
`,Ae=(0,d.Ay)(R.A)`
  flex: 1;

  & fieldset {
    width: 100%;
    border-radius: 6px 0 0 6px;
  }
`,ce=(0,d.Ay)(H.A).withConfig({shouldForwardProp:e=>"isCopied"!==e})`
  border-radius: 0 6px 6px 0;
  text-transform: none;
  ${e=>{let{isCopied:t}=e;return t&&"background-color: #4caf50;"}}

  &:hover {
    background-color: ${e=>{let{theme:t}=e;return(0,G.x6)(t.palette,G.Fl,G.qf)}};
    box-shadow: none;

    ${e=>{let{isCopied:t}=e;return t&&`background-color: ${(0,U.e$)("#4caf50",.05)}`}}
  }
`,de=e=>{let{shareLogTracking:t,openModal:n,onToggleModal:r,urlWithCopyUtmSource:i}=e;const{t:l}=(0,E.Bd)(),{config:o}=(0,Q._r)(),[s,A]=(0,a.useState)(l("share.modal.copy_url_of_the_offer")),[c,d]=(0,a.useState)(!1),p=()=>{r(!1),d(!1),A(l("share.modal.copy_url_of_the_offer"))},m=o?.socialNetworksToDisplay?.length?o.socialNetworksToDisplay:le;return a.createElement(oe,{open:n,onClose:p,"data-testid":"cvc-share-modal"},a.createElement(W.aF.Header,{onClose:p,title:l("share.modal.title")}),a.createElement(W.aF.Content,null,a.createElement(N.A,{spacing:3},a.createElement(se,null,m.map((e,n)=>a.createElement(ie,{sharingTracker:t,size:34,key:n,socialNetworkName:e})),a.createElement(K,{sharingTracker:t,handleCloseModal:p,size:34})),a.createElement(Y.A,{row:!0},a.createElement(Ae,{disabled:!0,defaultValue:i,inputProps:{readOnly:!0}}),a.createElement(ce,{"data-testid":"cvc-share-btn-copy-to-clipboard",onClick:()=>{navigator.clipboard.writeText(i),d(!0),A(a.createElement(V.A,{View:M.iW,size:32,withContrast:!0})),t(C.M$.SHARE_JOB_OFFER_ACTION,"copy_to_clipboard")},isCopied:c,variant:"contained",type:"button",title:s,sx:{boxShadow:0}},s)))))};de.displayName="SharingModal",de.propTypes={shareLogTracking:h.func,openModal:h.bool,onToggleModal:h.func,urlWithCopyUtmSource:h.string};const pe=e=>{let{isComponentAtBottomOfThePage:t}=e;const{t:n}=(0,E.Bd)(),r=(0,A.wA)(),i=(0,S.dX)(),[l,o]=(0,a.useState)(!1),s=t?"share_job_offer_bottom_btn_click":"share_job_offer_top_btn_click",c=t?"cvc-share-btn-bottom":"cvc-share-btn-top",d=(e,t)=>{r((0,C.Iy)(e,i.id,t))},p=(0,a.useMemo)(()=>{const e=new URL(window.location.href);return(0,Z._6)(e.searchParams),e.href},[]),m=(0,a.useMemo)(()=>{const e=new URLSearchParams(p.search);return e.set("utm_source","cvcatcher-sharing"),e.set("utm_medium","clipboard"),p+"?"+e.toString()},[p]);return a.createElement(a.Fragment,null,a.createElement(x.yP,{colorName:G.Fl,"data-print-hidden":!0,"data-testid":c,Icon:M.ep,onClick:()=>{d(C.M$.SHARE_JOB_OFFER_BTN_CLICK,s),o(!0)}},t?n("share.modal.title"):void 0),a.createElement(de,{shareLogTracking:d,onToggleModal:o,openModal:l,urlWithCopyUtmSource:m}))};pe.displayName="SocialsMediaSharing";var me=n(23099),ue=n(26532),ge=n.n(ue);const Ce=e=>{let{view:t,jobOffer:n}=e;const r=(0,A.wA)(),i=()=>{r((0,C.NX)(C.M$.JOB_APPLY_BTN_CLICK,n.id)),r((0,C.NX)(C.M$.JOB_APPLY_BTN_CLICK_REDIRECT,n.id));const e={transaction_id:ge()(),product_data:[(0,me.h6)(n)]};(0,me.oU)("product.purchased",e)};let l=n.apply_link||n.link;if(l){const e=(0,Z.mh)(l,window.location.search);return a.createElement(t,{"data-testid":"cvc-job-offer-redirect-button",href:e,onClick:i})}return null};var fe=n(30534),he=n(65886),ye=n(29850);const Ee=(0,d.Ay)(he.v)`
  position: relative;
  z-index: 1;
  display: block;
  min-height: calc(50vh + 160px);
  margin: -160px auto 32px auto;
  padding: 64px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}}) {
    margin-top: -100px;
    padding: 32px;
  }
`,Me=(0,d.Ay)("div")`
  display: flex;
  flex-direction: ${j.Fr||j.v1?"column-reverse":"row"};
  justify-content: space-between;
  align-items: ${j.Fr||j.v1?"flex-start":"center"};
  gap: 32px;
  margin-bottom: 32px;
`,xe=d.Ay.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 16px;
  flex: 1;
`,we=(0,d.Ay)(fe.h)`
  margin-top: 0;
  margin-bottom: 0;
`,De=(0,d.Ay)("h3")`
  margin: 48px 0 16px 0;
`,be=e=>{let{isRedirection:t}=e;const n=(0,S.dX)(),{t:r}=(0,E.Bd)(),{config:l}=(0,Q._r)(),o=(0,i.GV)(D.dA),{description_permalink:s,mission_description_formatted:A,mission_description_title:c,profile_description_formatted:d,profile_description_title:p,additional_descriptions_formatted:m}=n,u=P.A.getEntityLogo(n);return a.createElement(Ee,null,a.createElement(Me,null,a.createElement(xe,null,u&&a.createElement(F.X,{src:P.A.getEntityLogo(n),alt:(0,B.x)(n,l)}),a.createElement(we,{variant:"h2"},r("job_details_page.offer-description"))),a.createElement(N.A,{alignSelf:"flex-end",direction:"row",spacing:3},a.createElement(T.Q,{rounded:!0,filters:(0,O.HP)(n)}),a.createElement(pe,null))),o?.success&&a.createElement(k.A,{icon:a.createElement(V.A,{View:M._$,fill:z.wV[700]}),severity:"success"},r("application.application_succeeded")),l.features?.use_split_description_fields?a.createElement(a.Fragment,null,a.createElement(De,null,c||r("job_details_page.mission_description")),a.createElement($.R,{rawHtml:A,testId:"mission-description"}),d&&a.createElement(a.Fragment,null,a.createElement(De,null,p||r("job_details_page.profile_description")),a.createElement($.R,{rawHtml:d,testId:"profile-description"})),m&&m.map(e=>a.createElement(a.Fragment,null,a.createElement(De,null,e.title),a.createElement($.R,{rawHtml:e.content,testId:"additional-description"})))):a.createElement($.R,{rawHtml:s,testId:"offer-description"}),t&&a.createElement(Ce,{view:ye.b,jobOffer:n}))};be.propTypes={isRedirection:y().bool.isRequired};var Le=n(7398),_e=n(47132),Ie=n(74798);const ve=d.Ay.div`
  display: flex;
  flex-direction: ${j.Fr?"column":"row"};
  justify-content: ${j.Fr?"":"space-between"};
  align-items: ${j.Fr?"flex-start":"center"};
  flex-wrap: wrap;
  gap: 32px;
  margin: 32px 16px;
`,Ne=d.Ay.span`
  display: flex;
  gap: 24px;
  margin-top: ${j.Fr?"8px":"0"};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    flex-direction: column;
  }
`,ke=d.Ay.ul`
  display: flex;
  flex-direction: ${j.Fr?"column":"row"};
  align-items: ${j.Fr?"flex-start":"center"};
  margin: 0;
  padding: 0;
`,je=(0,d.Ay)(Ie.A)`
  display: inline-block;
  margin-left: ${j.Fr?"0":"16px"};
  font-style: italic;
  margin-bottom: ${j.Fr?"16px":"0"};

  span {
    font-weight: bold;
  }
`,ze=()=>{const e=(0,S.dX)(),{t,i18n:n}=(0,E.Bd)(),{publication_date:r,reference:i}=e,l=(0,_e.JJ)(n.language);return a.createElement(ve,null,a.createElement(Ne,null,a.createElement(T.Q,{rounded:!0,withText:!0,filters:(0,O.HP)(e)}),a.createElement(pe,{isComponentAtBottomOfThePage:!0})),a.createElement(ke,null,a.createElement(je,{variant:"li",autoContrast:!0},a.createElement("span",null,t("job_details_page.publication_date")),(0,Le.Yq)(r,n.language,l)),a.createElement(je,{variant:"li",autoContrast:!0},a.createElement("span",null,t("job_details_page.reference")),i)))};var Te=n(20800);const Oe=(0,d.Ay)(Te.l)`
  padding: 64px 0 32px 0;
`,Qe=e=>{let{relatedJobOffers:t,isFetching:n,relatedJobOffersCount:r}=e;const i=(0,d.DP)(),{t:l}=(0,E.Bd)();return a.createElement(Oe,{dataTestId:"cvc-related-job-offers-card",slug:"swiper-related-offers",largeButtonLink:!0,bgColorName:i.palette.background.default,jobOffers:t,title:l("related_job_offers.title_2022"),jobOffersCount:r,isFetching:n})};var Se=n(8877),Pe=n(69421),Be=n(58793),Ve=n(35560),$e=n(6989),Fe=n(63991),Ze=n(23158),Ge=n(17143),Re=n(85561),He=n(41593);const Ue="APPLICATION_WITHOUT_RESUME_FAILED",Ye="APPLICATION_WITHOUT_RESUME_FORM",We="APPLICATION_WITHOUT_RESUME_SUCCEEDED",Je=e=>{let{views:t}=e;const{formView:n,successView:r,errorView:l}=t,o=(0,A.wA)(),s=(0,i.GV)(D.JT),c=(0,i.GV)(D.EC),d=(0,i.GV)(D.dA),p=(0,i.GV)(D.rX);switch((0,a.useMemo)(()=>d?d.success?We:!1===d.success?Ue:void 0:Ye,[s,c,o,d,p])){case We:return a.createElement(Ge.e,{view:r,isSpontaneousForm:!1});case Ue:return a.createElement(Re.C,{view:l,isSpontaneousForm:!1});default:return a.createElement(He.c,{view:n,isSpontaneousForm:!1})}};Je.propTypes={views:y().shape({formView:y().oneOfType([y().element,y().func]),successView:y().oneOfType([y().element,y().func]),errorView:y().oneOfType([y().element,y().func])}).isRequired};var Ke=n(34766),Xe=n(19996),qe=n(90835);const et=d.Ay.div`
  display: flex;
`,tt=d.Ay.div`
  position: relative;
  display: block;
  padding: 16px 24px;
  border-radius: 6px;
  border: 1px solid
    ${e=>{let{theme:t}=e;return(0,G.x6)(t.palette,G.Fl,G.Xs)}};
  background-color: #fff;
  transition: ${e=>{let{theme:t}=e;return`${t.transitions.duration.standard}ms ease`}};

  &:hover,
  &:focus {
    transform: scale(1.05);
  }

  input {
    cursor: pointer;
    position: absolute;
    left: 0;
    top: 0;
    display: block;
    width: 100%;
    height: 100%;
    opacity: 0;
  }
`,nt=d.Ay.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,at=(0,d.Ay)(Ie.A)`
  font-weight: 600;
  line-height: 1.25;
  margin: 0;
`,rt=e=>{let{setDisplayForm:t}=e;const{t:n}=(0,E.Bd)(),r=(0,A.wA)();return a.createElement(et,null,a.createElement(tt,null,a.createElement(nt,null,a.createElement(V.A,{View:M.GI,size:24,withContrast:!0}),a.createElement(at,{autoContrast:!0},n("job_details_page.application_without_resume_cta"))),a.createElement("input",{"data-testid":"cvc-apply-without-resume",onClick:()=>{t(!0),r((0,p.z)(!0))}})))};var it=n(97519);const lt=d.Ay.form`
  position: relative;
  margin: 32px auto;
`,ot=d.Ay.div`
  margin: 16px auto;
  font-size: 1rem;
`,st=(0,d.Ay)(R.A)`
  margin-top: 16px;
  font-size: 1rem;
`,At=d.Ay.p`
  color: #7d8397;
  font-size: 12px;
  margin: 32px 0;

  a {
    text-decoration: underline !important;
    color: ${z.c3[600]};
  }
`,ct=e=>{let{linkedinField:t,formFields:n,inputChange:r,inputFocus:l,formSubmit:o,isLoadingPdfBuilder:A,isSending:c}=e;const{t:d}=(0,E.Bd)(),p=(0,i.Ti)(!0),[m,u]=(0,a.useState)(!1),g=(0,i.GV)(D.rX),C=(0,a.useRef)();(0,a.useEffect)(()=>{m&&(0,me.oU)("product.add_to_cart",{product_data:[(0,me.h6)(g)],method:"without_cv"})},[m]);const f={__html:it.A.sanitize(d("application_without_resume.personal_data_text",{privacy_policy_url:p}),{USE_PROFILES:{html:!0}})};return m?a.createElement(Ke.A,{in:!0},a.createElement(lt,{onSubmit:o,"data-testid":"cvc-application-form",ref:e=>C.current=e},!(0,s.A)(n)&&a.createElement(Xe.Ay,{container:!0,spacing:2},Object.values(n).map((e,t)=>a.createElement(qe.x,{key:t,field:e,inputChange:r,inputFocus:l}))),a.createElement(st,{label:t.linkedin.placeholder,name:t.linkedin.name,error:!!t.linkedin.error,helperText:t.linkedin.error,defaultValue:t.linkedin.value,variant:"outlined",fullWidth:!0,onChange:r,onFocus:l}),a.createElement(At,{dangerouslySetInnerHTML:f}),c?a.createElement(ot,null,a.createElement(k.A,{severity:"info"},d("application.application_is_sending"))):a.createElement(x.$n,{type:"submit",fullWidth:!0,disabled:c,loading:A,"data-testid":"cvc-form-application-submit-button"},d(A?"application.pdf_being_generated":"application.submit")))):a.createElement(rt,{setDisplayForm:u})};ct.propTypes={formFields:y().object,inputChange:y().func,inputFocus:y().func,formSubmit:y().func,isSending:y().bool};var dt=n(46927);const pt=d.Ay.div`
  display: flex;
  margin: 32px auto;
  flex-wrap: wrap;
  gap: 24px;
`,mt=(0,d.Ay)(he.v)`
  display: flex;
  flex: 1;
  padding: 48px;
  gap: 48px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: 24px;
  }
`,ut=d.Ay.div`
  flex: 3;
  height: fit-content;

  svg {
    fill: ${e=>{let{theme:t}=e;return(0,G.x6)(t.palette,"secondary","light")}};
  }
`,gt=d.Ay.div`
  flex: 10;
`,Ct=(0,d.Ay)(fe.h)`
  font-size: 2rem;
  margin: 0 0 8px 0;
`,ft=(0,d.Ay)(Ie.A)`
  margin: 0 0 32px 0;
`,ht=d.Ay.div`
  display: flex;
  gap: 32px;
  flex-wrap: wrap;
`,yt=e=>{let{applicationBoxRef:t}=e;const{t:n}=(0,E.Bd)(),{config:r}=(0,Q._r)(),l=(0,i.GV)(e=>e.profile.isFetching),o=(0,i.GV)(e=>e.profile.id),s=(0,i.GV)(e=>e.profile.isFileUploaded),A=(0,S.dX)(),c=(0,Le._Z)(r,A.partner),d=(0,i.GV)(e=>e.isApplicationWithoutResumeSelected),p=!!(0,i.GV)(D.Ht)?.errorCode,m=(0,i.GV)(e=>e.applications[e.currentJobOffer.id]),u=m?.success,g=!(l||o||d||p||u);return a.createElement(pt,null,a.createElement(mt,{"data-print-hidden":!0,ref:t},a.createElement(Se.rb,{up:!0},g&&a.createElement(ut,null,a.createElement(Pe.F2,{height:"auto",width:"auto"}))),a.createElement(gt,null,a.createElement(Ct,{autoContrast:!0,variant:"h2"},n("job_details_page.one-click-application")),g&&a.createElement(ft,{autoContrast:!0,variant:"p"},n("job_details_page.one-click-application-subtitle")),a.createElement(ht,null,!d&&a.createElement(Be.N,{views:{uploadView:Ve.K,formView:$e.h,successView:Fe.D,errorView:Ze.V}}),dt.I.shouldDisplayApplicationWithoutResume(r,c,s,o)&&a.createElement(Je,{views:{formView:ct,successView:Fe.D,errorView:Ze.V}})))))};yt.propTypes={applicationBoxRef:y().shape({current:y().instanceOf(Element)})};var Et=n(61361),Mt=n(83878),xt=n(50446),wt=n(492),Dt=n(81868),bt=n(15195);const Lt=()=>{const e=(0,S.dX)(),t=(0,i.gl)(e),{metaTitle:n,metaDescription:r}=(e=>{let{titleOffer:t,companyName:n,locality:a,contractType:r}=e;const{t:i}=(0,E.Bd)(),{config:l}=(0,Q._r)(),{company_name:o,features:{override_entity_name_with_company_name:s}}=l,A=[o,t,n,r,a],c=[o,n&&i("seo_markup.job_offer_details.companyName",{companyName:n}),t&&i("seo_markup.job_offer_details.title_offer",{titleOffer:t}),r&&i("seo_markup.job_offer_details.contract_type",{contractType:r}),a&&i("seo_markup.job_offer_details.locality",{locality:a})];return(s||n===o)&&(A.splice(2,1),c.splice(1,1)),{metaTitle:(0,Dt.A)(A).join(" - "),metaDescription:(0,Dt.A)(c).join(" ")}})({titleOffer:e.title,companyName:e.company,locality:t,contractType:e.contract_type.join()});return a.createElement(a.Fragment,null,a.createElement(c.mg,null,a.createElement("title",null,n),a.createElement("meta",{name:"description",content:r}),a.createElement("link",{rel:"canonical",href:(0,Z.y5)(window.location)}),a.createElement("meta",{property:"og:title",content:n}),a.createElement("meta",{property:"og:description",content:r}),a.createElement("meta",{property:"og:url",content:(0,Z.y5)(window.location)})),a.createElement(w.im,{isDetailsPage:!0}),a.createElement(w.FP,{jobOffer:e}))};Lt.propTypes={jobOffer:bt.ss};var _t=n(87540);const It=d.Ay.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`,vt=d.Ay.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 32px;
  width: 100%;
  padding: 72px 32px;
  margin: auto;
  white-space: pre-line;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    gap: 16px;
    margin-top: 152px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin-top: 64px;
  }
`,Nt=d.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 32px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    gap: 16px;
  }
`,kt=(0,d.Ay)(W.hE)`
  font-size: 2rem;
  margin: 0;
`,jt=(0,d.Ay)(w.fz)`
  margin: 0;
`,zt=()=>{const{config:e}=(0,Q._r)(),t=(0,i.yM)(),n=(0,i.tk)(),r=(0,i.qx)(),l=(0,i.NB)();return e.features?.display_page_header||!t?n||r||l?a.createElement(Et.Y,{position:"static"}):a.createElement(_t.S,null):null},Tt=e=>{let{code:t="404"}=e;const{t:n}=(0,E.Bd)(),{display_page_footer:o}=(0,i.Jr)(),s=(0,i.yM)(),A=(0,r.zy)(),d=o||!s,p=(0,r.B6)(A.pathname,{path:l.J.OFFER_DETAILS,exact:!0})?"offer":"page";return a.createElement(a.Fragment,null,a.createElement(c.mg,null,a.createElement("meta",{name:"render:status_code",content:t}),a.createElement("meta",{name:"prerender-status-code",content:t}),a.createElement("link",{rel:"canonical",href:(0,Z.y5)(window.location.toString())})),a.createElement(It,null,a.createElement(zt,null),a.createElement(vt,{"data-testid":"cvc-page-404"},a.createElement(Nt,null,a.createElement(Pe.Ly,{"data-testid":"cvc-page-404-icon",width:"250"})),a.createElement(Nt,null,a.createElement(kt,{variant:"h1","data-testid":"cvc-page-404-title"},n(`not_found.${p}.title`)),a.createElement(jt,{"data-testid":"cvc-page-404-paragraph"},n(`not_found.${p}.paragraph`)),a.createElement(x.$n,{href:"/","data-testid":"cvc-page-404-button"},n("not_found.button")))),d&&a.createElement(Et.w,null)))},Ot=(0,Mt.Mz)(e=>e.jobOffers,(e,t)=>t,(e,t)=>({...e[t]?e[t]:{},contract_type:e[t]&&e[t].contract_type||[],company_description:e[t]&&(e[t].company_description_formatted||e[t].company_description),id:t||null,localities:e[t]&&e[t].localities||[{city_label:"",department_label:"",region_label:"",large_region_label:""}],skills:e[t]&&e[t].skills||[],redirectUrl:e[t]&&e[t].redirectUrl||null})),Qt=e=>{let{view:t,...n}=e;const l=(0,i.jL)(),o=(0,r.zy)(),s=(0,i.GV)(D.JT),[A,c]=(0,a.useState)(!1),d=(0,i.GV)(e=>Ot(e,e.currentJobOffer.id||n.match.params.id));return(0,a.useEffect)(()=>{l((0,C.Wf)(C.M$.DISPLAYED_JOB_OFFER_DETAILS_PAGES,{job_id:d.id}))},[l,d.id]),(0,a.useEffect)(()=>{s&&wt.A.setResumeId(s)},[s]),(0,a.useEffect)(()=>{const e=s||wt.A.getResumeId();l((0,xt.UG)(o)),l(e?(0,m.YO)(wt.A.getApplications(e)):(0,m.YO)(wt.A.getApplications(wt.A.generatedResumeIdKeyName)))},[]),(0,a.useEffect)(()=>{if(d.redirectUrl){if(window.location.href!==d.redirectUrl)return sessionStorage.setItem("hasBeenRedirectedFromJobOffer","true"),void(window.location.href=d.redirectUrl)}l((0,xt.vD)(n.match.params.id,()=>{c(!0)})),l((0,xt.HH)())},[l,n.match.params.id,d.redirectUrl]),A?a.createElement(Tt,{code:"410"}):a.createElement(S.Rh,{jobOffer:d},a.createElement(Lt,null),a.createElement(t,null))},St=(e,t)=>Object.values(e).filter(e=>t.includes(e.id)),Pt=(0,Mt.Mz)(D.mO,D.Z4,D.YS,(e,t,n)=>({isFetching:t.isFetching||n.isFetching,relatedJobOffers:St(e,t.list),total:t.total})),Bt=e=>{let{view:t}=e;const{isFetching:n,relatedJobOffers:r,total:l}=(0,i.GV)(Pt);return a.createElement(t,{relatedJobOffers:r,isFetching:n,relatedJobOffersCount:l})},Vt=e=>{let{view:t,anchorRef:n={}}=e;const r=(0,A.wA)(),i=(0,A.d4)(e=>e.jobOffers[e.currentJobOffer.id]),[l,o]=(0,a.useState)(!0);(0,a.useEffect)(()=>{const e=()=>{const{current:e}=n;if(e){const{y:t}=e.getBoundingClientRect();window.innerHeight>t?o(!1):o(!0)}};return window.addEventListener("scroll",e),window.addEventListener("resize",e),()=>{window.removeEventListener("scroll",e),window.removeEventListener("resize",e)}},[n]);return l?a.createElement(t,{scrollTo:()=>{const{current:e}=n;e&&e.scrollIntoView({block:"center",behavior:"smooth"}),r((0,C.NX)(C.M$.JOB_APPLY_BTN_CLICK,i.id)),r((0,C.NX)(C.M$.JOB_APPLY_BTN_CLICK_SCROLL,i.id))},anchorRef:n}):null};Vt.propTypes={view:y().func.isRequired,anchorRef:y().shape({current:y().instanceOf(Element)})};var $t=n(76073),Ft=n(98012),Zt=n(83609);const Gt=(0,d.Ay)(Ie.A)`
  line-height: 24px;
  margin: 0;
  white-space: pre-line;
`,Rt=e=>{let{isOpen:t,onClose:n,setIsSubscribedFromUrl:r}=e;const{t:l}=(0,E.Bd)(),o=(0,i.GV)(D.JT);(0,a.useEffect)(()=>{t&&(0,me.PK)("alert_activate",o)},[t,o]);const s=()=>{const e=new URLSearchParams(window.location.search);if(e.has("ea")){e.delete("ea");const t=window.location.pathname+(e.toString()?"?"+e.toString():"");history.replaceState(null,"",t)}r(!1),n()};return a.createElement(Zt.a,{open:t,onClose:s},a.createElement(Zt.a.Header,{title:l("email_alerts.confirmation_from_mail.modal_title"),onClose:s}),a.createElement(Zt.a.Content,null,a.createElement(N.A,{spacing:4},a.createElement(Gt,null,l("email_alerts.confirmation_from_mail.success_message")))),a.createElement(Zt.a.Footer,null,a.createElement(x.$n,{onClick:s,size:"small"},l("common.close"))))};var Ht=n(45728),Ut=n(8667),Yt=n(95600);const Wt=(0,d.Ay)(w.o5)`
  font-size: 1.125rem;
  font-weight: 700;
  margin: 0px 0px 8px;
  line-height: 2rem;
`,Jt=(0,d.Ay)(Wt)`
  font-size: 0.875rem;
`,Kt=()=>{const{t:e}=(0,E.Bd)(),t=(0,i.GV)(D.tX),n=(0,i.GV)(D.JT);return n||t?.length?a.createElement(Yt.A,null,a.createElement(Jt,null,e("email_alerts.common.filters_reminder")),a.createElement(N.A,{direction:"row",flexWrap:"wrap",gap:2},!!n&&a.createElement(w.vw,{mode:"secondary"},"Analyse de votre CV"),t.map(e=>a.createElement(w.vw,{key:e,mode:"secondary"},e)))):null};var Xt=n(28598);const qt=(0,d.Ay)(Ie.A)`
  font-size: 1.125rem;
  font-weight: 700;
  line-height: 1.5rem;
  margin: 0;
`,en=(0,d.Ay)(Zt.a.Footer)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    flex-direction: column-reverse;
    gap: 24px;
  }
`,tn=(0,d.Ay)(Ie.A)`
  color: ${z.wV[600]} !important;
  font-size: 0.75rem;
  line-height: 16px;
`,nn=(0,d.Ay)(Ie.A)`
  line-height: 24px;
  margin: 0;
  white-space: pre-line;
`,an=e=>{let{isOpen:t,onClose:n,isSending:r,webEmailUrl:l}=e;const{t:o}=(0,E.Bd)(),s=(0,i.jL)(),A=(0,i.pp)(),c=(0,i.d7)(),d=(0,i.GV)(D.JT),p=(0,i.GV)(D.Bi),[m,u]=(0,a.useState)(!1),[g,C]=(0,a.useState)(null),f=(0,a.useCallback)(async()=>{await s(await A(Ht.mu.Z$.WEB_EMAIL,{web_email_name:Object.keys(Ft.UM).find(e=>Ft.UM[e]===l),web_email_url:l}))},[s,A,l]),h=(0,a.useCallback)(()=>{(0,me.PK)("cta_click",d,"Accéder à ma boite email"),c(()=>f())},[d,o,c,f]),y=(0,a.useCallback)(async()=>{C(null),(0,me.PK)("cta_click",d,"Renvoyer l'email"),s((0,Xt.TR)({email:p,resumeId:d,source:"email-alerts-email-unverified-resend-button"},()=>{u(!0)},()=>{C(o("email_alerts.errors.resend_error_message"))}))},[s,p,d,o]);return a.createElement(Zt.a,{open:t,onClose:n},a.createElement(Zt.a.Header,{title:o("email_alerts.confirmation_after_submit.modal_title"),onClose:n}),a.createElement(Zt.a.Content,null,a.createElement(N.A,{spacing:4},a.createElement(N.A,{direction:"row",spacing:2,alignItems:"center"},a.createElement(w.h_,{fill:"#28a745",size:24,View:M._$}),a.createElement(qt,null,o("email_alerts.confirmation_after_submit.success_heading"))),a.createElement(nn,null,o("email_alerts.confirmation_after_submit.neutral_confirmation_message")),a.createElement(Kt,null),m&&a.createElement(N.A,{direction:"row",spacing:1},a.createElement(w.h_,{fill:z.wV[600],size:22,View:M._$}),a.createElement(tn,{variant:"span"},o("email_alerts.confirmation_after_submit.did_resend_message"))),g&&a.createElement(Ut.I,null,g))),a.createElement(en,null,a.createElement(x.$n,{onClick:y,loading:!!r,variant:"outlined",size:"small"},o("email_alerts.confirmation_after_submit.resend_button")),l&&a.createElement(x.$n,{href:l,icon:M.HW,iconPosition:"right",onClick:h,rel:"noopener noreferer",size:"small"},o("email_alerts.confirmation_after_submit.access_mailbox_button"))))};var rn=n(59193),ln=n(87448),on=n(18307);const sn=(0,d.Ay)(Ie.A)`
  font-size: 1.125rem;
  font-weight: 700;
  line-height: 24px;
  margin: 0;
`,An=(0,d.Ay)(w.HL)`
  display: flex;
  align-items: center;
  margin-bottom: 0px;
  margin-top: 8px;

  svg {
    margin-left: 4px;
  }
`,cn=(0,d.Ay)(Ie.A)`
  line-height: 24px;
  margin: 0;
  white-space: pre-line;
`,dn=(0,rn.Ay)(R.A)`
  flex: 1;
  width: 100%;

  .MuiInputBase-root {
    border-radius: 8px;

    &::before {
      border: none;
    }
  }
`,pn=(0,d.Ay)(x.$n)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    width: 100%;
  }

  background-color: ${e=>{let{theme:t}=e;return t.palette.primary.main}} !important;
`,mn=e=>{let{isOpen:t,onClose:n,inputValue:r,error:l,setError:o,onChange:s,isSending:A,isFormValid:c,setIsFormValid:d,onSubmitSuccess:p}=e;const{t:m}=(0,E.Bd)(),u=(0,i.jL)(),g=(0,i.GV)(D.JT),C=(0,on.HD)();(0,a.useEffect)(()=>{if(!t)return;const e=Object.values(C.filters).some(e=>!(0,Le.Im)(e));return null!=g||e?""===r.trim()?(l===m("email_alerts.errors.empty_email")&&o(null),void d(!1)):(0,Ft.xf)(r)?(l!==m("email_alerts.errors.email_format")&&l!==m("email_alerts.errors.empty_email")||o(null),void d(!0)):(o(m("email_alerts.errors.email_format")),void d(!1)):(o(m("email_alerts.errors.no_cv_no_filters")),void d(!1))},[r,g,C.filters,m,l,o,d]);const f=(0,a.useCallback)(async e=>{if(e.preventDefault(),!r)return o(m("email_alerts.errors.empty_email")),void d(!1);if(!(0,Ft.xf)(r))return o(m("email_alerts.errors.email_format")),void d(!1);const t=Object.values(C.filters).some(e=>!(0,Le.Im)(e)),n=null!=g||t;if(d(n),!n)return void o(m("email_alerts.errors.no_cv_no_filters"));(0,me.PK)("alert_create",g);const a={...C,email:r,emailSubscribeIsChecked:!1};u((0,Xt.AE)(a,e=>{o(null),p(),a.resume_id||wt.A.setNoResumeSubscribedEmailAlertsStatus(e)},e=>{429===e.statusCode?o(m("email_alerts.errors.subscription_failed_429")):o(m("email_alerts.errors.subscription_failed"))}))},[u,C,r,m,g,o,d,p]);return a.createElement(Zt.a,{open:t,onClose:n},a.createElement("form",{action:"#",onSubmit:f},a.createElement(Zt.a.Header,{title:m("email_alerts.subscription_form.modal_title"),onClose:n}),a.createElement(Zt.a.Content,null,a.createElement(N.A,{spacing:4},a.createElement(N.A,{spacing:2},a.createElement(sn,null,m("email_alerts.subscription_form.dont_miss_offers")),a.createElement(cn,null,m("email_alerts.subscription_form.incentive_text")),a.createElement(Yt.A,null,a.createElement(dn,{value:r,error:!!l,onChange:s,variant:"filled",label:m("common.email"),required:!0}),a.createElement(An,null,m("email_alerts.subscription_form.no_spam")," ",a.createElement(w.h_,{View:M.em,size:14,withContrast:!0})))),a.createElement(Kt,null),a.createElement(ln.A,{i18nKey:"email_alerts.subscription_form.terms_of_use_text",variant:"body2"}),l&&a.createElement(Ut.I,null,l))),a.createElement(Zt.a.Footer,null,a.createElement(pn,{disabled:!c,loading:A,size:"small",type:"submit"},m(A?"email_alerts.subscription_form.subscription_in_progress":"email_alerts.subscription_form.activate_alert")))))},un=()=>{const e=(0,i.jL)(),t=(0,i.GV)(D.wD),{isOpen:n}=(0,i.GV)(D.QW),r=(0,i.GV)(D.h8),l=(0,i.GV)(D.Bi),o=(0,i.GV)(D.v5),[s,A]=(0,a.useState)(t||""),[c,d]=(0,a.useState)(null),[p,m]=(0,a.useState)(!0),[u,g]=(0,a.useState)(!1),[C,f]=(0,a.useState)(!1),h=(0,Ft.Yp)(l);(0,a.useEffect)(()=>{new URLSearchParams(window.location.search).get("ea")===Ft.ft.SUBSCRIBED&&(f(!0),e((0,$t.AV)({isOpen:!0,filters:void 0})))},[e]),(0,a.useEffect)(()=>{t&&A(t)},[t]);const y=(0,a.useCallback)(()=>{e((0,$t.AV)({isOpen:!1,filters:void 0})),g(!1),d(null)},[e]),E=(0,a.useCallback)(e=>{A(e.target.value)},[]),M=(0,a.useCallback)(()=>{g(!0)},[]);return C?a.createElement(Rt,{isOpen:n,onClose:y,setIsSubscribedFromUrl:f}):u||o?a.createElement(an,{isOpen:n,onClose:y,isSending:r??!1,webEmailUrl:h}):a.createElement(mn,{isOpen:n,onClose:y,inputValue:s,error:c,setError:d,onChange:E,isSending:r??!1,isFormValid:p,setIsFormValid:m,onSubmitSuccess:M})},gn=d.Ay.main`
  background-color: ${e=>{let{theme:t}=e;return t.palette.background.default}};
  padding: 0 0 32px 0;
  @media (min-width: 930px) {
    margin-top: var(--app-wrapper-margin-top-desktop);
  }
`,Cn=()=>{const e=(0,S.dX)(),{config:t}=(0,Q._r)(),{display_page_footer:n,display_page_header:r}=(0,i.Jr)(),l=(0,i.GV)(D.dA),o=(0,i.GV)(D.du),d=(0,i.iI)(e),h=(0,i.yM)(),y=(0,a.useRef)(),E=(0,Le._Z)(t,e.partner),M=E.ats&&"in-app"===E.workflow,x=(0,A.wA)(),[w,b]=(0,a.useState)(!1);(0,a.useEffect)(()=>{"true"===sessionStorage.getItem("hasBeenRedirectedFromJobOffer")&&(b(!0),sessionStorage.removeItem("hasBeenRedirectedFromJobOffer"))},[]),(0,a.useEffect)(()=>{const n=new URLSearchParams(window.location.search).get("resume_id_to_reapply");let a,r=0;return a=setInterval(()=>r+=1,1e3),(0,me.oU)("page.display",{page_category:"Detail",page_subject:"Offer",page_type:"DO-Emploi",page_hostname:window.location.hostname,site_name:t.company_name}),n&&(wt.A.removeApplicationLinkedToResumeId(n,e.id),(0,Z.yE)((0,Z.y5)(window.location)),x((0,C.Wf)(C.M$.REAPPLY_JOB_OFFER,{job_id:e.id}))),()=>{x((0,g.Tu)(u.f7)),x((0,g.yo)(u.Vm)),x((0,p.z)(!1)),x((0,m.xD)(!1)),clearInterval(a),(0,me.oU)("product.page_display",{product_data:[],offer_timer:r})}},[x,e.id]),(0,a.useEffect)(()=>{e.reference&&(0,me.oU)("product.page_display",{product_data:[(0,me.h6)(e)]})},[e.reference]);const L=n||!h,N=r||!h;return a.createElement(a.Fragment,null,w&&a.createElement(c.mg,null,a.createElement("meta",{name:"prerender-status-code",content:"301"}),a.createElement("meta",{name:"prerender-header",content:`Location: ${window.location.href}`})),N&&a.createElement(Et.Y,{transparent:!0}),a.createElement(gn,null,a.createElement(v.F,null),(0,s.A)(l)&&M&&!o&&a.createElement(Vt,{view:_,anchorRef:y}),a.createElement(f.m,null,a.createElement(be,{isRedirection:!M}),d&&a.createElement(I.X,{companyDescription:d}),M&&a.createElement(yt,{applicationBoxRef:y}),a.createElement(ze,null)),t.features?.related_job_offers_enabled&&a.createElement(Bt,{view:Qe}),a.createElement(un,null)),L&&a.createElement(Et.w,null))},fn=e=>a.createElement(Qt,(0,o.A)({},e,{view:Cn})),hn=d.Ay.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`,yn=d.Ay.main`
  padding: 32px;
  margin: 0 auto auto auto;
  max-width: 1024px;
  line-height: 1.5;
`,En=e=>{let{content:t}=e;return a.createElement(hn,null,a.createElement(Et.Y,{position:"static"}),a.createElement(yn,null,a.createElement("div",{dangerouslySetInnerHTML:{__html:it.A.sanitize(t,{USE_PROFILES:{html:!0}})}})),a.createElement(Et.w,null))},Mn=()=>a.createElement(Tt,{code:"404"}),xn=()=>a.createElement(Tt,{code:"410"});var wn=n(93444);const Dn=d.Ay.main`
  background-color: ${e=>{let{theme:t}=e;return t.palette.background.default}};
  margin-top: var(--app-wrapper-margin-top-desktop);

  @media (min-width: 930px) {
    margin-top: var(--app-wrapper-margin-top-desktop);
  }

  @media screen and (max-width: 991px) {
    margin-top: var(--app-wrapper-margin-top-mobile);
  }
`,bn=d.Ay.div`
  width: 100%;
  padding: 0 24px;
  display: flex;
  align-items: center;
  flex-direction: column;
  position: absolute;
  transform: translate(0, -50%);
  z-index: 1;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 0 16px;
  }
`,Ln=(0,d.Ay)(f.m)`
  padding-top: 48px;
  padding-bottom: 64px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding-top: 64px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    padding-top: 88px;
  }
`,_n=(0,a.memo)(()=>{const{display_page_footer:e,display_search_bar_on_results_page:t}=(0,i.Jr)(),n=(0,i.yM)(),r=e||!n;return a.createElement(a.Fragment,null,a.createElement(Dn,null,a.createElement(W.H1,null),t&&a.createElement(bn,null,a.createElement(W.C8,null)),a.createElement(Ln,null,a.createElement(W.NA,null)),a.createElement(W.yP,null)),r&&a.createElement(Et.w,null),a.createElement(un,null))});_n.displayName="ResultsPageView";const In=()=>a.createElement(wn.JC,{view:_n}),vn=e=>{let{children:t,location:n}=e;const o=(0,i.Wh)();return a.createElement(r.dO,{location:n},t,a.createElement(r.qh,{exact:!0,path:l.J.SEARCH,component:In}),a.createElement(r.qh,{exact:!0,path:l.J.OFFER_DETAILS,component:fn}),o.map(e=>{let{configKey:t,text:n,url:i}=e;return a.createElement(r.qh,{key:t,exact:!0,path:i,render:()=>a.createElement(En,{content:n})})}),a.createElement(r.qh,{exact:!0,path:l.J.FOUR_HUNDRED_TEN,component:xn}),a.createElement(r.qh,{component:Mn}))}},43895:(e,t,n)=>{n.d(t,{Q:()=>f});var a=n(14041),r=n(95600),i=n(32066),l=n(97434),o=n(2345),s=n(66341),A=n(85423),c=n(18307),d=n(76073),p=n(31048),m=n(61631),u=n(23099),g=n(65563);const C=(0,o.Ay)(r.A)`
  bottom: 0;
  left: 0;
  margin: 16px;
  position: fixed;
  z-index: 1;
`,f=e=>{let{rounded:t=!1,withText:n=!1,filters:o}=e;const{t:f}=(0,l.Bd)(),h=(0,A.jL)(),{isBelowOrEqualToBreakpoint:y}=(0,A.dv)(),E=y("mobile"),M=(0,A.GV)(p.JT),x=(0,A.GV)(p.As),w=(0,A.GV)(p.Ut),D=(0,c.sc)(),b=(0,c.J0)(),L=(0,a.useCallback)(()=>{const e=o?{queries:"string"==typeof o.queries?o.queries:x,contracts:Array.isArray(o.contracts)?o.contracts:w.contracts,cities:Array.isArray(o.cities)?o.cities:w.cities}:{queries:x,contracts:w.contracts,cities:w.cities};(0,u.PK)("alert_load",M,"Créer une alerte mail"),h((0,d.AV)({isOpen:!0,filters:e}))},[h,o,x,w,M]);if(!D)return null;const _=!b,I=f("email_alerts.button_text");let v=a.createElement(g.wl,{colorName:m.ll,disabled:_,onClick:L},I);return t?v=a.createElement(g.yP,{colorName:m.ll,disabled:_,Icon:s.rY,onClick:L},n?I:void 0):E&&(v=a.createElement(C,null,a.createElement(g.K0,{colorName:m.ll,disabled:_,Icon:s.rY,onClick:L}))),_?a.createElement(i.A,{title:f("email_alerts.disabled_no_active_filters")},a.createElement(r.A,null,v)):v}},45311:(e,t,n)=>{n.d(t,{A:()=>i});var a=n(39067),r=n.n(a);const i=r().shape({apply_link:r().string,contract_type:r().array,company:r().string,company_description:r().string,description_permalink:r().string,id:r().string,internalId:r().string,link:r().string,lastProcessedDate:r().string,localities:r().array,publication_date:r().string,salary:r().string,skills:r().array,title:r().string,partner_specific_fields:r().object,reference:r().string})},45759:(e,t,n)=>{n.d(t,{A:()=>i});var a=n(14041);const r=n(2345).Ay.div`
  opacity: 0;
  transition: 550ms ease-in;
`,i=e=>{let{children:t,className:n}=e;const i=(0,a.useRef)();return(0,a.useEffect)(()=>{i.current.style.opacity=1},[]),a.createElement(r,{ref:i,className:n},t)}},45890:(e,t,n)=>{n.d(t,{L:()=>L});var a=n(14041),r=n(2345),i=n(81554),l=n(58797),o=n(59193),s=n(61631),A=n(85423),c=n(97434),d=n(85761),p=n(80379),m=n(79273),u=n(66341),g=n(33131);const C=r.Ay.span`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: ${e=>{let{theme:t}=e;return(0,s.x6)(t.palette,s.Fl,s.Xs)}};
  border-radius: 50%;
  height: 38px;
  width: 38px;
  border: white solid 2px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin-left: 0;
    padding: 0;
  }
`,f=(0,r.Ay)(g.A)`
  ${e=>{let{open:t,theme:n}=e;return`\n    transition: all ${n.transitions.duration.short}ms ease;\n    ${t&&"transform: rotateZ(180deg);"}\n  `}}
`,h=r.Ay.button`
  background: #ffffff;
  border: none;
  border-radius: 38px;
  cursor: pointer;
  display: ${e=>{let{displayMobile:t}=e;return t?"none":"flex"}};
  align-items: center;
  justify-content: space-between;
  padding: 0 0 0 16px;
  height: 38px;
  width: 115px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    display: ${e=>{let{displayMobile:t}=e;return t?"flex":"none"}};
    width: 38px;
    height: 38px;
    justify-content: center;
    padding: 0;
  }
`,y=(0,o.Ay)(i.Ay)`
  margin-top: 8px;
  max-height: 310px;
  margin-left: 52px;
  
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin-left: 20px;
  }
`,E=r.Ay.div`
  padding: 16px;
  margin: 0;
  min-width: 127px;
  min-height: 118px;
  display: flex;
  gap: 8px;
  flex-direction: column;
  justify-content: space-evenly;
`,M=(0,r.Ay)(l.Li)`
  cursor: pointer;
  user-select: none;
  padding: 8px;
  border-radius: 8px;
  display: flex;
  align-items: center;

  ${e=>{let{isSelected:t,theme:n}=e;return`\n  ${t&&`background-color: ${(0,s.x6)(n.palette,s.ll,s.qf)};`}\n    transition: all ${n.transitions.duration.shorter}ms ease;\n    &:hover {\n        background-color: ${(0,s.x6)(n.palette,s.ll,s.qf)}\n    };\n  `}}
`,x=r.Ay.span`
  margin-left: 8px;
`,w=r.Ay.div`
  display: flex;
  align-items: center;
  overflow: visible;
  position: absolute;
  z-index: 2;
  right: 64px;
  top: 64px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    right: 16px;
    top: 38px;
    z-index: 5;
  }

  &.feature {
    border: solid 1px #000000de;
    border-radius: 38px;
    position: relative;
    top: initial;
    right: initial;
  }
`,D=r.Ay.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  img {
    margin-right: 8px;
  }
`,b=e=>{let{language:t,selected:n}=e;const{t:r}=(0,c.Bd)(),{isSearchPage:i}=(0,A.a8)(),l=e=>{window.location.href=(e=>{const t=new URL(window.location.href);return t.pathname=`/${e}`,i&&(t.pathname+=p.J.SEARCH),t.toString()})(e)};return a.createElement(M,{key:t,isSelected:n,onClick:()=>l(t)},a.createElement(m.d,{lang:t}),a.createElement(x,null,r(`languages_names.${t}`)))},L=e=>{let{className:t}=e;const{i18n:n}=(0,c.Bd)(),r=(0,A.VE)(),[i,l]=a.useState(null),o=Boolean(i),p=e=>{l(e.currentTarget)},g=(0,a.useCallback)(()=>{l(null)},[]);return(0,a.useEffect)(()=>(document.addEventListener("scroll",g),()=>document.removeEventListener("scroll",g)),[g]),a.createElement(w,{className:t},a.createElement(h,{onClick:p,"data-testid":"cvc-languages-selector-button",displayMobile:!1},a.createElement(D,null,a.createElement(m.d,{lang:n.language}),(0,d.A)(n.language)),a.createElement(C,null,a.createElement(f,{View:u.rI,size:24,fill:s.QZ,open:o,withContrast:!0}))),a.createElement(h,{onClick:p,displayMobile:!0},a.createElement(m.d,{lang:n.language})),a.createElement(y,{open:o,anchorEl:i,onClose:g,disableScrollLock:!0,anchorOrigin:{vertical:"bottom",horizontal:"center"},transformOrigin:{vertical:"top",horizontal:"right"},PaperProps:{style:{borderRadius:"8px",scrollbarWidth:"none"}}},a.createElement(E,null,r.map(e=>{return a.createElement(b,{selected:(t=e,t===n.language),key:e,language:e});var t}))))}},46927:(e,t,n)=>{n.d(t,{I:()=>l});var a=n(45728),r=n(492);class i{static getFormattedDate(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};if(e instanceof Date)return e.toLocaleDateString(t,n)}}class l{static shouldDisplayApplicationWithoutResume(e,t,n,i){const l=r.A.getResumeId(),o=t.ats&&t.workflow===a.Yn.IN_APP;return e.features?.allow_application_without_resume&&!l&&!i&&o&&!n}static async generatePdfResume(e,t){const{first_name:n,last_name:a,email:r,phone:l,linkedin:o}=e,{title:s,reference:A}=t,c=new Date,d=i.getFormattedDate(c,"fr-fr",{day:"numeric",month:"long",year:"numeric"});return p={firstName:n,lastName:a,email:r,phone:l,jobTitle:s,jobReference:A,applicationDate:d||(new Date).toLocaleDateString("fr-FR"),linkedin:o},new Promise(e=>{const{firstName:t,lastName:n,email:a,phone:r,jobTitle:i,jobReference:l,applicationDate:o,linkedin:s}=p,A=`%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n\n3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n\n4 0 obj\n<< /Length 500 >>\nstream\nBT\n/F1 16 Tf\n50 750 Td\n(Candidature sans CV) Tj\n0 -40 Td\n/F1 12 Tf\n(Date: ${o}) Tj\n0 -30 Td\n(Candidat:) Tj\n0 -20 Td\n(${t} ${n}) Tj\n0 -20 Td\n(${a}) Tj\n0 -20 Td\n(${r}) Tj${s?`\n0 -20 Td\n(${s}) Tj`:""}\n0 -30 Td\n(Offre:) Tj\n0 -20 Td\n(${i}) Tj\n0 -20 Td\n(${l}) Tj\nET\nendstream\nendobj\n\n5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n\nxref\n0 6\n0000000000 65535 f \n0000000010 00000 n \n0000000079 00000 n \n0000000136 00000 n \n0000000301 00000 n \n0000000850 00000 n \n\ntrailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n950\n%%EOF`,c=(new TextEncoder).encode(A);e(new Blob([c],{type:"application/pdf"}))});var p}static getBlobFromFile(e){return e}}},47603:(e,t,n)=>{n.d(t,{A:()=>d});var a=n(89575),r=n(14041),i=n(2345),l=n(39067),o=n.n(l),s=n(61631);const A=i.Ay.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  background-color: ${e=>{let{theme:t,bgColorName:n}=e;return(0,s.x6)(t.palette,n,s.qf)}};
  padding: 1.5rem;
  border-radius: 8px;
  transition: ${e=>{let{theme:t}=e;return`${t.transitions.duration.standard}ms ease`}};

  ${e=>{let{hasHover:t}=e;return t&&"\n    &:hover {\n        filter: brightness(0.93)\n        };\n    }\n  "}}
`,c=e=>{let{children:t,bgColorName:n=s.QZ,hasHover:i=!1,...l}=e;return r.createElement(A,(0,a.A)({bgColorName:n,hasHover:i},l),t)};c.propTypes={bgColorName:o().oneOf([s.Fl,s.ll,s.QZ,s.o1]),hasHover:o().bool};const d=(0,i.Ay)(c)``},50446:(e,t,n)=>{n.d(t,{Fz:()=>u,HH:()=>C,UG:()=>m,sm:()=>f,tn:()=>h,vD:()=>g});var a=n(75992),r=n(492),i=n(16600),l=n(8049),o=n(71716),s=n(51902),A=n(82202),c=n(58026),d=n(96362),p=n(63926);const m=e=>async(t,n)=>{const{appConfig:r}=n(),o=new URLSearchParams(e.search),s=o.get(l.wW),A=(0,i.E3)(o);if(s&&t((0,c.Uz)(s)),!(0,a.A)(A)){const e=r.search_request?.custom_filters?(0,i.A8)(A,r.search_request.custom_filters):[];t((0,d.KV)({cities:A.cities,companies:A.companies,contracts:A.contracts,countries:A.countries,job_sectors:A.sectors,remote_work_types:A.remote,custom_filters:e},!1))}},u=e=>async(t,n)=>{const{appConfig:a}=n();if(!a.search_request)return;const{max_distance:r,max_distance_filter:i}=a.search_request;try{if(e){t((0,d.zL)({max_distance:r,max_distance_filter:i}));const n=await t((0,s.G5)(e));if(n)throw n}const{profile:l}=n();if(l.id){const e=y(l,a.language),n=await t((0,p.bX)(e));if(n)throw n}const A=await t((0,o.vM)());if(A)throw A;t((0,d.Ou)())}catch(e){t((0,d.YG)())}},g=(e,t)=>async(n,a)=>{const{appConfig:r}=a();await n((0,o.O9)(e,t)),r.related_job_offers?.enabled&&await n((0,o.mY)(e,r.related_job_offers.limit))},C=()=>async(e,t)=>{const{appConfig:n,profile:a}=t(),i=a.id||r.A.getResumeId(),l=!a.id,o=l&&a.id;try{if(l&&i){const t=await e((0,s.G5)(i));if(t)throw t}if(o){const t=y(a,n.language),r=await e((0,p.bX)(t));if(r)throw r}}catch(t){e(A.Bs)}},f=()=>(e,t)=>{const{appConfig:n}=t();if(!n.search_request)return;const{max_distance:a,max_distance_filter:r}=n.search_request;e((0,o.u8)()),e((0,d.zL)({max_distance:a,max_distance_filter:r})),e((0,d.G1)(!1))},h=e=>async(t,n)=>{const{appConfig:r,profile:i}=n();try{if(i.id){const e=y(i,r.language),n=await t((0,p.bX)(e));if(n)throw n}const n=2e3,l=!!i?.attachment_file_name&&(0,a.A)(i?.identity),s=await t((0,o.vM)(n,()=>{t((0,d.yF)(!0,!1)),e(l)}));if(s)throw s;setTimeout(()=>{t((0,d.Ou)())},n)}catch(e){t((0,d.YG)())}},y=(e,t)=>({skills:e.skills,jobs:e.jobs_and_sought_positions_v3.filter(e=>null!==e.id).map(e=>({id:e.id,weight:e.weight})),hobbies:e.hobbies,lang:t})},51566:(e,t,n)=>{n.d(t,{_:()=>c});var a=n(14041),r=n(2345),i=n(58797),l=n(39067),o=n.n(l),s=n(45728);const A=(0,r.Ay)(i.o5)`
  font-size: ${e=>{let{theme:t}=e;return t.template===s.tC.BENTO_2024?"1rem":"2rem"}};
  font-weight: 600;
  text-align: center;
  margin: ${e=>{let{theme:t}=e;return t.template===s.tC.BENTO_2024?"0":"0 0 2.25rem 0"}};

  span {
    margin-top: 4px;
    display: block;
    font-size: 1.25rem;
    font-weight: 400;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1.5rem;

    span {
      font-size: 1rem;
    }
  }
`,c=e=>{let{topLine:t,bottomLine:n}=e;return a.createElement(A,{variant:"h2",autoContrast:!0},t,n&&a.createElement("span",null,n))};c.propTypes={topLine:o().string.isRequired,bottomLine:o().string}},51902:(e,t,n)=>{n.d(t,{G5:()=>M,Cv:()=>E});var a,r=n(43322),i=n(98898),l=n(59123),o=n(82202),s=n(28598),A=n(492),c=n(24586),d=n(96949),p=n(75340),m=n(47304);class u{}a=u,(0,c.A)(u,"socket",void 0),(0,c.A)(u,"createSocket",async e=>{if(a.socket)return a.socket;const t=await(0,p.Y5)(),n=(0,p.Ni)(),r=A.A.getSessionKey();if(!t)throw new Error("Error: no authentication token found to open websocket");if(!n)throw new Error("Error: no session Id found to open websocket");if(!r)throw new Error("Error: no session key found to open websocket");return a.socket=(0,d.io)("https://marvin-websocket.cvcatcher.io",{query:e,reconnectionAttempts:2,reconnectionDelay:2e3,extraHeaders:{Authorization:"Bearer "+t,"x-session-id":n,"x-language":m.Ay.language,"x-session-key":r}}),a.socket.on("connect",()=>{console.log("Websocket is connected")}),a.socket.on("connect_error",e=>{console.error("Websocket connexion error:",e.message),a.socket=void 0}),a.socket.on("disconnect",()=>{console.log("Websocket is disconnected."),a.socket=void 0}),a.socket});var g=n(50446),C=n(306),f=n(96362),h=n(31048);const y=async(e,t,n,a,r,i)=>{e((0,o.xS)(t,r)),await e((0,g.tn)(n));const l=a.id||A.A.getResumeId();l?(e((0,C.YO)(A.A.getApplications(l))),await e((0,s.pW)(l))):e((0,C.YO)(A.A.getApplications(A.A.generatedResumeIdKeyName))),i&&await e(async(e,t)=>{const{appConfig:n,profile:a}=t();n.email_alerts_enabled&&a.id&&await e((0,s.AE)({email:a.identity.email,resume_id:a.id,source:"email-alerts-incentive-checkbox"}))})},E=(e,t)=>async(n,a)=>{const{appConfig:r}=a(),i=(0,h.Vs)(a());n((0,o.eT)(e.filename)),A.A.setAttachmentFilename(e.filename);try{const a=await(0,l.lA)({file:e.file,filename:e.filename,consent_given:e.consent_given,current_page:i});if(A.A.setResumeId(a.id),A.A.setSessionKey(a.session_key),!a.op_id&&a.profile)return y(n,a,t,a,r,e.email_alerts_subscribe);const s={consent_given:!!e.consent_given,current_page:i},c=await u.createSocket(s);c.on("cvc_done",i=>{y(n,i,t,a,r,e.email_alerts_subscribe)}),c.io.on("reconnect_failed",function(){A.A.removeResumeId(),A.A.removeSessionKey(),A.A.removeAttachmentFilename(),n((0,o.Z2)(new Error("Connection to websocket server failed"))),n((0,f.YG)())}),c.on("cvc_error",i=>{y(n,i,t,a,r,e.email_alerts_subscribe)})}catch(e){return setTimeout(()=>(n((0,o.Z2)(e)),e),2e3)}},M=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:null;return async(n,a)=>{const{appConfig:r,profile:i}=a();if(!r.search_request)return;const{max_distance:l,max_distance_filter:c}=r.search_request;n((0,o.GP)(e,{max_distance:l,max_distance_filter:c}));try{const a=await x(i);n((0,o.Fi)({...a,attachment_file_name:A.A.getAttachmentFilename()},r)),r.email_alerts_enabled&&n((0,s.pW)(e)),t&&t()}catch(e){const t=e;return n((0,o.Bs)(t)),404===t.statusCode&&(A.A.removeResumeId(),A.A.removeSessionKey(),A.A.removeAttachmentFilename(),n((0,o.sb)()),window.location.reload()),t}}},x=async e=>{const t=await(0,l.E$)(),n=(0,r.A)(t),{identity:a}=n.profile;return(0,i.A)(e.identity,(e,t)=>{if(e&&e!==a[t]){if("phone"===t){const t=e=>e.number===a.phone,n=a.phones.findIndex(t);a.phones[n].number=e}a[t]=e}}),n}},52519:(e,t,n)=>{n.d(t,{X:()=>i});var a=n(14041);const r=n(2345).Ay.div`
  background-color: white;
  border-radius: 5px;
  width: 100px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid ${e=>{let{theme:t}=e;return t.palette.grey[200]}};
  padding: 4px;

  img {
    max-height: 100%;
    max-width: 100%;
  }
`,i=e=>{let{alt:t,className:n,src:i}=e;return a.createElement(r,{className:n},a.createElement("img",{alt:t,src:i}))}},55481:(e,t,n)=>{n.d(t,{N:()=>o});var a=n(89575),r=n(14041),i=n(2345);const l=i.Ay.a`
  font-size: 1rem;
  &:hover {
    text-decoration: underline !important;
  }
`,o=(0,i.Ay)(e=>{const t={};return"_blank"===e.target&&(t.rel="noopener noreferrer"),r.createElement(l,(0,a.A)({},t,e))})``},56946:(e,t,n)=>{n.d(t,{QU:()=>o,Wz:()=>l,do:()=>r,kt:()=>i});var a=n(57480);const r=()=>({type:a.x7,payload:{isFetching:!0}}),i=(e,t,n)=>({type:a.Qg,payload:{isFetching:!1,fetchingComplete:!0,selectedJobs:e.selected_jobs,selectedSkills:e.selected_skills,suggestedSkills:e.suggested_skills,sortSkills:t,useHobbies:n,selectedHobbies:e.selected_hobbies,suggestedHobbies:e.suggested_hobbies}}),l=e=>({type:a.u4,payload:{isFetching:!1,err:{name:e.name,message:e.message,errorCode:e.errorCode,statusCode:e.statusCode}}}),o=e=>{let{id:t,label:n,category:r}=e;return{type:a.$5,payload:{id:t,label:n,category:r}}}},58793:(e,t,n)=>{n.d(t,{N:()=>I});var a=n(14041),r=n(39067),i=n.n(r),l=n(85423),o=n(31048),s=n(492),A=n(85561),c=n(41593),d=n(17143),p=n(85426),m=n.n(p),u=n(18307),g=n(306),C=n(51902),f=n(50446),h=n(68382),y=n(68153),E=n(19555);const M=e=>{let{view:t}=e;const n=(0,l.jL)(),{config:r}=(0,y._r)(),[i,o]=(0,a.useState)(!1),[s,A]=(0,a.useState)(),c=(0,u.Gb)();(0,a.useEffect)(()=>{r.analytics?.google_tag_manager?.active&&m().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Bloc",EventAction:"Visible",EventLibelle:"[DO] - Depot CV"}})},[r]);return a.createElement(t,{acceptTos:async()=>{n((0,f.sm)()),await n((0,C.Cv)({...s,email_alerts_subscribe:i}));const e=h.M$.UPLOAD_RESUME,t={page:E.Bd.JOB_OFFER_DETAILS,subscribed_to_email_alerts:c?i:null};n((0,h.Wf)(e,t))},toggleEa:e=>{o(e)},changeFile:e=>{const t=0!==e.length,a=e[0];t&&(A({file:a,filename:a.name,consent_given:!0}),n((0,g.xD)(!0)))}})},x="APPLICATION_FAILED",w="SPONTANEOUS_APPLICATION_FAILED",D="APPLICATION_FORM",b="APPLICATION_SUCCEEDED",L="SPONTANEOUS_APPLICATION_SUCCEEDED",_="APPLICATION_UPLOAD_FILE",I=e=>{let{views:t,isSpontaneousForm:n}=e;const{uploadView:r,formView:i,successView:p,errorView:m}=t,u=(0,l.GV)(o.JT),g=(0,l.GV)(o.EC),C=(0,l.GV)(o.dA),f=(0,l.GV)(o.cR),h=(0,l.GV)(o.rX),y=s.A.getResumeId(),E=u&&!g;switch((0,a.useMemo)(()=>E?h?C?.success?b:!1===C?.success?x:D:n?f?.success?L:!1===f?.success?w:D:_:_,[C,E,n,h,y,f])){case D:return a.createElement(c.c,{view:i,isSpontaneousForm:n});case L:case b:return a.createElement(d.e,{view:p,isSpontaneousForm:n});case w:case x:return a.createElement(A.C,{view:m,isSpontaneousForm:n});default:return a.createElement(M,{view:r})}};I.propTypes={views:i().shape({uploadView:i().oneOfType([i().element,i().func]),formView:i().oneOfType([i().element,i().func]),successView:i().oneOfType([i().element,i().func]),errorView:i().oneOfType([i().element,i().func])}).isRequired}},59437:(e,t,n)=>{n.d(t,{m:()=>l});var a=n(2345),r=n(39067),i=n.n(r);const l=a.Ay.div`
  width: 100%;
  margin: 0 auto;
  display: block;
  padding: 0 24px;
  max-width: calc(
    ${e=>{let{theme:t,large:n}=e;return`${n?t.breakpoints.desktop:t.breakpoints.laptop}px`}} +
      48px
  );

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    padding: 0 16px;
    max-width: calc(${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}} + 32px);
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.mobile}px`}}) {
    padding: 0 12px;
    max-width: calc(${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}} + 24px);
  }

  ${e=>{let{full:t}=e;return t?"max-width: none":""}};
`;l.propTypes={large:i().bool,full:i().bool}},61361:(e,t,n)=>{n.d(t,{w:()=>w,Y:()=>D.Y9});var a=n(14041),r=n(97434),i=n(2345),l=n(45728),o=n(68153),s=n(85423),A=n(80379),c=n(33106),d=n(61631),p=n(55481),m=n(13532),u=n(65563),g=n(92241);const C=i.Ay.footer`
  width: 100%;
  padding: 56px 48px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  ${e=>{let{theme:t}=e;return`\n    background-color: ${(0,d.x6)(t.palette,"primary","dark")};\n    * {\n      color: ${(0,d.Vh)((0,d.x6)(t.palette,"primary","dark"),t.palette)};\n    }\n  `}}
`,f=i.Ay.div`
  display: flex;
  margin: 30px 0px 56px;
  & > * {
    margin: 0 16px !important;
    text-align: center;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-direction: column;
    align-items: center;
    margin: 24px 0px 32px;
    * {
      margin: 16px 0px !important;
    }
  }
`,h=i.Ay.img`
  display: block;
  height: auto;
  width: 156px;
  max-height: 80px;
  object-fit: contain;
`,y=i.Ay.div`
  display: flex;
  align-items: center;
  margin-bottom: 12px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-direction: column;
    align-items: center;
    *:first-child {
      margin-right: 0px;
      margin-bottom: 8px;
    }
  }
`,E=i.Ay.span``,M=i.Ay.span`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    span {
      display: block;
      text-align: center;
      margin-bottom: 8px;
    }
    ${E} {
      display: none;
    }
  }
`,x=()=>{const{t:e}=(0,r.Bd)(),t=(0,s.z)(),n=(0,s.zk)(),i=(0,s.Ou)(),o=e("career_footer_links.required_links",{defaultValue:[],returnObjects:!0}),A=[...i];switch(t){case l.ch.CVC_JOB_OFFERS:case l.ch.CVC_SC:case l.ch.CVC_CORE:}return A.push(...o),a.createElement(f,null,n.map(e=>(0,s.UC)(e)?a.createElement(g.E,{key:e.configKey,to:e.url},e.label):a.createElement(p.N,{key:e.configKey,href:e.url,target:"_blank"},e.label)),A.map((e,t)=>"id"in e&&"cookie_handler"===e.id?a.createElement(u.xy,{key:t,onClick:()=>window.cvc_orejime.show()},e.label):"url"in e?a.createElement(p.N,{key:t,href:e.url,target:"_blank"},e.label):null))},w=e=>{let{className:t}=e;const{config:n}=(0,o._r)(),{t:l}=(0,r.Bd)(),{palette:s}=(0,i.DP)(),{contrastThreshold:u,text:{dark:f}}=s;return a.createElement(C,{"data-print-hidden":!0,className:t},a.createElement(g.E,{to:A.J.HOME},a.createElement(h,{src:(0,c.pl)(n),alt:l("seo_markup.career_site_home_page.title",{clientName:n.company_name})})),a.createElement(x,null),!n.features?.hide_powered_by&&a.createElement(y,null,a.createElement("span",null,l("career_footer.powered_by")),a.createElement(p.N,{target:"_blank",href:"https://magnet.work/"},a.createElement(m.e,{isWhite:(0,d.wB)((0,d.x6)(s,"primary","dark"),f.primary,u)}))),a.createElement(M,null,a.createElement("span",null,"© ",(new Date).getFullYear()," ",l("career_footer.copyright")),n.photoVideoCredits&&a.createElement(a.Fragment,null,a.createElement(E,null," - "),a.createElement("span",null,l("career_footer.photos_videos_credits")," :"," ",n.photoVideoCredits))))};var D=n(40126)},63926:(e,t,n)=>{n.d(t,{Pd:()=>s,bX:()=>l,m3:()=>o});var a=n(56946),r=n(59123),i=n(75830);const l=e=>async(t,n)=>{t((0,a.do)());try{const{appConfig:i}=n(),l=i.search_request?.use_hobbies,o=!0,s=await(0,r.KW)(e);t((0,a.kt)(s,o,l))}catch(e){return t((0,a.Wz)(e)),e}},o=()=>async(e,t)=>{const n=t(),i=n.profile,l={skills:i.skills,jobs:i.jobs_and_sought_positions_v3.filter(e=>null!==e.id).map(e=>({id:e.id,weight:e.weight})),hobbies:i.hobbies,lang:n.appConfig.language};e((0,a.do)());try{const{appConfig:t}=n,i=t.search_request?.use_hobbies,o=!0,s=await(0,r.KW)(l);e((0,a.kt)(s,o,i))}catch(t){e((0,a.Wz)(t))}},s=()=>async(e,t)=>{e((0,a.do)());const n=t(),l={skills:n.search.skills.map(e=>(0,i.A)(e,"category")),jobs:n.search.jobs.filter(e=>null!==e.id).map((e,t)=>({id:e.id,weight:n.search.jobs.length-t})),hobbies:n.search.hobbies,lang:n.appConfig.language};try{const{appConfig:n}=t(),i=n.search_request?.use_hobbies,o=!1,s=await(0,r.KW)({skills:l.skills,jobs:l.jobs,hobbies:l.hobbies,lang:l.lang});e((0,a.kt)(s,o,i))}catch(t){e((0,a.Wz)(t))}}},63991:(e,t,n)=>{n.d(t,{D:()=>h});var a=n(14041),r=n(2345),i=n(89618),l=n(34766),o=n(65706),s=n(97434),A=n(38544),c=n(13568),d=n(80379),p=n(33131),m=n(66341),u=n(31048);const g=r.Ay.div`
  display: block;
  margin: 32px auto 0 auto;
  width: 100%;
  max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}};
  text-align: center;
`,C=(0,r.Ay)(i.A)`
  flex-direction: column;
  align-items: center;
  justify-content: center;

  .MuiAlert-icon {
    margin: 0;
  }
`,f=(0,r.Ay)(c.g)`
  display: block;
  margin-top: 16px;
`,h=e=>{let{isSpontaneousForm:t}=e;const{t:n}=(0,s.Bd)(),r=(0,A.d4)(u.Nk);return a.createElement(l.A,{in:!0},a.createElement(g,{"data-testid":"cvc-application-success-content"},a.createElement(C,{severity:"success",iconMapping:{success:a.createElement(p.A,{View:m._$,fill:"#418944"})}},t?a.createElement(o.A,null,n("application.spontaneous_application_be_sent")):a.createElement(o.A,null,n("application.application_be_sent")),!t&&a.createElement(a.Fragment,null,a.createElement("span",null,n("application.application_succeeded")," : "),a.createElement("strong",null,r),a.createElement(f,{to:d.J.SEARCH},n("application.back_to_job_offers"))))))}},65563:(e,t,n)=>{n.d(t,{$n:()=>a.$,xy:()=>s,K0:()=>m,_s:()=>u._,yP:()=>h,wl:()=>y.w,R2:()=>_});var a=n(12973),r=n(14041),i=n(2345),l=n(61631);const o=i.Ay.button`
  cursor: pointer;

  ${e=>{let{large:t,theme:n,withUnderline:a,bold:r}=e;return`\n    font-size: ${t?"1.15rem !important":"1rem"};\n    font-weight: ${r?"600":"normal"};\n    transition: all ${n.transitions.duration.short}ms ease;\n    border-bottom: ${a?"1px solid":"none"};\n    border-color: ${(0,l.Vh)(n.palette.secondary.main,n.palette)};\n    \n    &:hover {\n      opacity: ${a?"0.6":"1"};\n      text-decoration: ${a?"none":"underline !important"};\n    }\n  `}}
`,s=e=>r.createElement(o,e);var A=n(89575),c=n(58797),d=n(36080);const p=i.Ay.button`
  cursor: pointer;

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    pointer-events: none;
  }

  ${e=>{let{theme:t,colorName:n}=e;const a=(0,l.x6)(t.palette,n,l.Xs),r=(0,l.x6)(t.palette,n,l.qf);return`\n      & > div {\n        border-color: ${a};\n        transition: all ${t.transitions.duration.standard}ms ease;\n      }\n\n      &:hover > div {\n        background-color: ${(0,l.Po)(a)};\n        border-color: ${(0,l.Po)(a)};\n      }\n\n      &:hover > svg {\n        fill: ${(0,l.Vh)(a,t.palette)} !important;\n      }\n\n      &:focus > div {\n        background-color: ${(0,l.TJ)(a)};\n        border-color: ${(0,l.TJ)(a)};\n        box-shadow: 0 0 0 0.2rem ${(0,l.EY)(r)};\n      }\n    `}}
`,m=e=>{let{disabled:t,Icon:n,size:a,...i}=e;const o=t?l.o1:i.colorName??l.Fl;return r.createElement(p,(0,A.A)({colorName:o,disabled:t},i),r.createElement(c.ux,{colorName:o,fill:t?d.c3[600]:i.fill,Icon:n,size:a}))};var u=n(76772);const g=i.Ay.button`
  display: flex;
  align-items: stretch;
  background-color: ${e=>{let{theme:t}=e;return(0,l.x6)(t.palette,l.QZ,l.Xs)}};
  border-radius: 24px;
  cursor: pointer;

  :disabled {
    opacity: 0.5;
    cursor: not-allowed;
    // Prevents any events
    pointer-events: none;
  }
`,C=(0,i.Ay)(c.ux)`
  border-color: #fff;
`,f=(0,i.Ay)(c.o5)`
  line-height: 22px;
  padding: 8px 16px;
`,h=e=>{let{children:t,colorName:n=l.Fl,Icon:a,...i}=e;return r.createElement(g,i,r.createElement(C,{colorName:n,Icon:a}),t&&r.createElement(f,{variant:"span",autoContrast:!0},t))};var y=n(93368),E=n(97434),M=n(83878),x=n(66341),w=n(85423),D=n(31048);const b=(0,i.Ay)(a.$).attrs(e=>{let{theme:{palette:t}}=e;return{colorName:(0,l.wB)(t.primary.main,t.background.default,t.contrastThreshold)?"primary":"black"}})`
  margin-top: 0;
  white-space: nowrap;
`,L=(0,M.Mz)(D.LH,D.EC,D.Qu,(e,t,n)=>e||t||n),_=e=>{let{isMapDisplayed:t,...n}=e;const{t:a}=(0,E.Bd)(),i=(0,w.GV)(L);return r.createElement(b,(0,A.A)({icon:x.Gt,iconPosition:"left",disabled:i,size:"small",variant:"outlined"},n),a(t?"map.button.hide":"map.button.show"))}},69421:(e,t,n)=>{n.d(t,{MH:()=>i,F2:()=>l,Ly:()=>o});var a=n(89575),r=n(14041);const i=(0,r.forwardRef)((e,t)=>r.createElement("svg",(0,a.A)({width:"401",height:"403",viewBox:"0 0 401 403",fill:"none",xmlns:"http://www.w3.org/2000/svg",ref:t},e),r.createElement("path",{d:"M60.4331 72.8887H9.7832C7.7232 72.8887 6.05322 71.2187 6.05322 69.1587C6.05322 67.0987 7.7232 65.4287 9.7832 65.4287H60.4331C62.4931 65.4287 64.1631 67.0987 64.1631 69.1587C64.1631 71.2187 62.4931 72.8887 60.4331 72.8887Z",fill:"#030303"}),r.createElement("path",{d:"M60.4331 94.6387H9.7832C7.7232 94.6387 6.05322 92.9687 6.05322 90.9087C6.05322 88.8487 7.7232 87.1787 9.7832 87.1787H60.4331C62.4931 87.1787 64.1631 88.8487 64.1631 90.9087C64.1631 92.9687 62.4931 94.6387 60.4331 94.6387Z"}),r.createElement("path",{d:"M60.4331 116.398H9.7832C7.7232 116.398 6.05322 114.728 6.05322 112.668C6.05322 110.608 7.7232 108.938 9.7832 108.938H60.4331C62.4931 108.938 64.1631 110.608 64.1631 112.668C64.1631 114.728 62.4931 116.398 60.4331 116.398Z",fill:"#030303"}),r.createElement("path",{d:"M339.993 54.1983H289.343C287.283 54.1983 285.613 52.5283 285.613 50.4683C285.613 48.4083 287.283 46.7383 289.343 46.7383H339.993C342.053 46.7383 343.723 48.4083 343.723 50.4683C343.723 52.5283 342.053 54.1983 339.993 54.1983Z"}),r.createElement("path",{d:"M339.993 138.108H289.343C287.283 138.108 285.613 136.438 285.613 134.378C285.613 132.318 287.283 130.648 289.343 130.648H339.993C342.053 130.648 343.723 132.318 343.723 134.378C343.723 136.438 342.053 138.108 339.993 138.108Z",fill:"#030303"}),r.createElement("path",{d:"M339.993 159.868H289.343C287.283 159.868 285.613 158.198 285.613 156.138C285.613 154.078 287.283 152.408 289.343 152.408H339.993C342.053 152.408 343.723 154.078 343.723 156.138C343.723 158.198 342.053 159.868 339.993 159.868Z",fill:"#030303"}),r.createElement("path",{d:"M134.303 265.138H149.533C150.693 265.138 151.633 264.198 151.633 263.038C151.633 261.878 150.693 260.938 149.533 260.938H134.303C133.143 260.938 132.203 261.878 132.203 263.038C132.203 264.198 133.143 265.138 134.303 265.138Z",fill:"#030303"}),r.createElement("path",{d:"M112.983 265.138H121.233C122.393 265.138 123.333 264.198 123.333 263.038C123.333 261.878 122.393 260.938 121.233 260.938H112.983C111.823 260.938 110.883 261.878 110.883 263.038C110.883 264.198 111.823 265.138 112.983 265.138Z",fill:"#030303"}),r.createElement("path",{d:"M97.853 265.138H101.533C102.693 265.138 103.633 264.198 103.633 263.038C103.633 261.878 102.693 260.938 101.533 260.938H97.853C96.693 260.938 95.7534 261.878 95.7534 263.038C95.7534 264.198 96.693 265.138 97.853 265.138Z",fill:"#030303"}),r.createElement("path",{d:"M86.1831 265.138H88.1133C89.2733 265.138 90.2134 264.198 90.2134 263.038C90.2134 261.878 89.2733 260.938 88.1133 260.938H86.1831C85.0231 260.938 84.083 261.878 84.083 263.038C84.083 264.198 85.0231 265.138 86.1831 265.138Z",fill:"#030303"}),r.createElement("path",{d:"M76.0732 265.138H77.0332C78.1932 265.138 79.1333 264.198 79.1333 263.038C79.1333 261.878 78.1932 260.938 77.0332 260.938H76.0732C74.9132 260.938 73.9731 261.878 73.9731 263.038C73.9731 264.198 74.9132 265.138 76.0732 265.138Z",fill:"#030303"}),r.createElement("path",{d:"M397.793 197.928C397.793 206.738 390.653 213.888 381.843 213.888H264.283C255.473 213.888 248.333 206.748 248.333 197.928C248.333 189.118 255.473 181.968 264.283 181.968H381.843C390.653 181.968 397.793 189.108 397.793 197.928Z",fill:"white"}),r.createElement("path",{d:"M381.833 216.158H264.273C254.223 216.158 246.043 207.978 246.043 197.928C246.043 187.878 254.223 179.698 264.273 179.698H381.833C391.883 179.698 400.063 187.878 400.063 197.928C400.063 207.978 391.883 216.158 381.833 216.158ZM264.273 184.248C256.733 184.248 250.593 190.388 250.593 197.928C250.593 205.468 256.733 211.608 264.273 211.608H381.833C389.373 211.608 395.513 205.468 395.513 197.928C395.513 190.388 389.373 184.248 381.833 184.248H264.273Z",fill:"#030303"}),r.createElement("path",{d:"M371.393 205.858C370.673 205.858 369.963 205.588 369.413 205.038C368.323 203.948 368.323 202.168 369.413 201.078L379.663 190.828C380.753 189.738 382.533 189.738 383.623 190.828C384.713 191.918 384.713 193.698 383.623 194.788L373.373 205.038C372.823 205.588 372.113 205.858 371.393 205.858Z",fill:"#030303"}),r.createElement("path",{d:"M381.643 205.858C380.923 205.858 380.213 205.588 379.663 205.038L369.413 194.788C368.323 193.698 368.323 191.918 369.413 190.828C370.503 189.738 372.283 189.738 373.373 190.828L383.623 201.078C384.713 202.168 384.713 203.948 383.623 205.038C383.073 205.588 382.363 205.858 381.643 205.858Z",fill:"#030303"}),r.createElement("path",{d:"M369.643 98.0576C369.643 106.868 362.503 114.008 353.693 114.008H236.133C227.323 114.008 220.183 106.868 220.183 98.0576C220.183 89.2476 227.323 82.0977 236.133 82.0977H353.693C362.503 82.0977 369.643 89.2376 369.643 98.0576Z",fill:"white"}),r.createElement("path",{d:"M353.693 116.288H236.133C226.083 116.288 217.903 108.108 217.903 98.0581C217.903 88.0081 226.083 79.8281 236.133 79.8281H353.693C363.743 79.8281 371.923 88.0081 371.923 98.0581C371.923 108.108 363.743 116.288 353.693 116.288ZM236.133 84.3781C228.593 84.3781 222.453 90.5181 222.453 98.0581C222.453 105.598 228.593 111.738 236.133 111.738H353.693C361.233 111.738 367.373 105.598 367.373 98.0581C367.373 90.5181 361.243 84.3781 353.693 84.3781H236.133Z",fill:"#030303"}),r.createElement("path",{d:"M343.254 105.978C342.534 105.978 341.824 105.708 341.274 105.158C340.184 104.068 340.184 102.288 341.274 101.198L351.524 90.9484C352.614 89.8584 354.394 89.8584 355.484 90.9484C356.574 92.0384 356.574 93.8184 355.484 94.9084L345.234 105.158C344.684 105.708 343.974 105.978 343.254 105.978Z",fill:"#030303"}),r.createElement("path",{d:"M353.504 105.978C352.784 105.978 352.074 105.708 351.524 105.158L341.274 94.9084C340.184 93.8184 340.184 92.0384 341.274 90.9484C342.364 89.8584 344.144 89.8584 345.234 90.9484L355.484 101.198C356.574 102.288 356.574 104.068 355.484 105.158C354.934 105.708 354.224 105.978 353.504 105.978Z",fill:"#030303"}),r.createElement("path",{d:"M2.85303 156.959C2.85303 148.149 9.99322 141.009 18.8032 141.009H136.363C145.173 141.009 152.313 148.149 152.313 156.959C152.313 165.769 145.173 172.909 136.363 172.909H18.8032C9.99322 172.909 2.85303 165.769 2.85303 156.959Z",fill:"white"}),r.createElement("path",{d:"M136.373 175.189H18.8135C8.76348 175.189 0.583008 167.008 0.583008 156.958C0.583008 146.908 8.76348 138.729 18.8135 138.729H136.373C146.423 138.729 154.603 146.908 154.603 156.958C154.603 167.008 146.423 175.189 136.373 175.189ZM18.8135 143.279C11.2735 143.279 5.1333 149.418 5.1333 156.958C5.1333 164.498 11.2735 170.639 18.8135 170.639H136.373C143.913 170.639 150.053 164.498 150.053 156.958C150.053 149.418 143.913 143.279 136.373 143.279H18.8135Z",fill:"#030303"}),r.createElement("path",{d:"M19.0133 164.879C18.2933 164.879 17.5833 164.609 17.0333 164.059C15.9433 162.969 15.9433 161.189 17.0333 160.099L27.2833 149.849C28.3733 148.759 30.1533 148.759 31.2433 149.849C32.3333 150.939 32.3333 152.719 31.2433 153.809L20.9933 164.059C20.4433 164.609 19.7333 164.879 19.0133 164.879Z",fill:"#030303"}),r.createElement("path",{d:"M29.2535 164.879C28.5335 164.879 27.8236 164.609 27.2736 164.059L17.0236 153.809C15.9336 152.719 15.9336 150.939 17.0236 149.849C18.1136 148.759 19.8935 148.759 20.9835 149.849L31.2335 160.099C32.3235 161.189 32.3235 162.969 31.2335 164.059C30.6835 164.609 29.9735 164.879 29.2535 164.879Z",fill:"#030303"}),r.createElement("path",{d:"M208.885 188.973L191.701 194.361L220.472 286.116L237.657 280.727L208.885 188.973Z",fill:"#030303"}),r.createElement("path",{d:"M226.779 211.123L189.681 222.756L224.018 332.258L261.116 320.625L226.779 211.123Z"}),r.createElement("path",{d:"M146.904 21.4085C97.7935 36.8085 70.4533 89.0985 85.8533 138.218C101.253 187.328 153.543 214.668 202.663 199.268C251.773 183.868 279.114 131.578 263.714 82.4585C248.314 33.3484 196.014 6.00846 146.904 21.4085ZM196.274 178.898C158.404 190.768 118.084 169.698 106.214 131.828C94.3436 93.9585 115.413 53.6385 153.283 41.7684C191.153 29.8984 231.473 50.9685 243.343 88.8385C255.213 126.708 234.144 167.028 196.274 178.898Z"}),r.createElement("path",{d:"M174.763 207.288C154.563 207.288 134.383 200.738 117.943 188.848C100.923 176.548 88.6032 159.428 82.3032 139.338C74.5532 114.638 76.8933 88.3884 88.8833 65.4484C100.873 42.4984 121.083 25.5984 145.793 17.8584C155.243 14.8984 165.003 13.3984 174.813 13.3984C195.003 13.3984 215.183 19.9484 231.633 31.8384C248.653 44.1384 260.973 61.2584 267.273 81.3584C275.023 106.058 272.683 132.308 260.683 155.248C248.693 178.198 228.483 195.098 203.773 202.838C194.323 205.798 184.563 207.298 174.753 207.298L174.763 207.288ZM174.803 20.8484C165.753 20.8484 156.733 22.2384 148.013 24.9684C125.213 32.1184 106.553 47.7184 95.4834 68.8984C84.4134 90.0784 82.2533 114.298 89.4033 137.098C95.2133 155.638 106.593 171.448 122.293 182.798C137.483 193.778 156.103 199.828 174.743 199.828C183.793 199.828 192.803 198.438 201.523 195.708C224.323 188.558 242.983 172.958 254.043 151.778C265.113 130.598 267.273 106.378 260.123 83.5784C254.313 65.0384 242.933 49.2284 227.233 37.8784C212.043 26.8984 193.423 20.8484 174.783 20.8484H174.803ZM174.763 185.938C159.013 185.938 143.283 180.828 130.453 171.558C117.183 161.968 107.573 148.608 102.663 132.938C96.6231 113.668 98.4432 93.2084 107.803 75.3184C117.153 57.4284 132.913 44.2484 152.183 38.2084C159.553 35.8984 167.163 34.7284 174.813 34.7284C190.563 34.7284 206.303 39.8384 219.123 49.1084C232.393 58.6984 242.003 72.0584 246.913 87.7184C252.953 106.988 251.133 127.448 241.773 145.338C232.423 163.228 216.663 176.408 197.393 182.448C190.023 184.758 182.413 185.928 174.763 185.928V185.938ZM174.803 42.1984C167.913 42.1984 161.043 43.2584 154.403 45.3384C118.563 56.5784 98.5432 94.8784 109.783 130.718C114.213 144.838 122.873 156.878 134.823 165.518C146.383 173.878 160.573 178.478 174.763 178.478C181.653 178.478 188.523 177.418 195.163 175.338C231.003 164.098 251.023 125.798 239.783 89.9584C235.353 75.8384 226.693 63.7984 214.743 55.1584C203.183 46.7984 188.993 42.1984 174.803 42.1984Z",fill:"#030303"}),r.createElement("path",{d:"M249.683 86.8488C262.653 128.219 239.633 172.269 198.263 185.239C156.893 198.209 112.843 175.189 99.8731 133.819C86.9031 92.4488 109.923 48.3988 151.293 35.4288C192.663 22.4588 236.713 45.4788 249.683 86.8488Z",fill:"white"}),r.createElement("path",{d:"M175.313 75.8086C148.893 76.2086 126.283 90.8986 115.863 111.839C126.923 132.459 149.963 146.439 176.383 146.039C202.803 145.639 225.403 130.949 235.833 110.009C224.773 89.3986 201.733 75.4086 175.313 75.8186V75.8086Z",fill:"white"}),r.createElement("path",{d:"M175.273 149.189C162.153 149.189 149.383 145.759 138.333 139.279C127.523 132.939 118.793 123.969 113.093 113.329C112.613 112.429 112.593 111.349 113.053 110.439C118.513 99.4689 127.113 90.1389 137.943 83.4489C149.023 76.5989 161.933 72.8689 175.273 72.6689C175.663 72.6689 176.043 72.6689 176.433 72.6689C189.543 72.6689 202.323 76.0989 213.373 82.5789C224.183 88.9189 232.903 97.8889 238.613 108.529C239.093 109.429 239.113 110.509 238.653 111.419C233.193 122.389 224.583 131.719 213.763 138.409C202.683 145.259 189.773 148.989 176.433 149.189C176.043 149.189 175.653 149.189 175.273 149.189ZM119.443 111.779C124.603 120.769 132.203 128.379 141.523 133.839C151.613 139.759 163.283 142.889 175.283 142.889C175.633 142.889 175.993 142.889 176.343 142.889C188.543 142.699 200.343 139.299 210.453 133.049C219.793 127.279 227.303 119.359 232.263 110.069C227.103 101.079 219.493 93.4789 210.183 88.0089C200.093 82.0889 188.423 78.9589 176.433 78.9589C176.083 78.9589 175.723 78.9589 175.363 78.9589C163.163 79.1489 151.363 82.5489 141.243 88.7989C131.903 94.5689 124.393 102.489 119.433 111.779H119.443Z",fill:"#030303"}),r.createElement("path",{d:"M200.823 110.539C201.023 123.949 190.013 134.999 176.223 135.209C162.433 135.419 151.093 124.709 150.883 111.299C150.673 97.8888 161.693 86.8488 175.483 86.6388C189.273 86.4288 200.623 97.1288 200.823 110.539Z"}),r.createElement("path",{d:"M127.903 231.289H117.183V220.569C117.183 219.409 116.243 218.469 115.083 218.469C113.923 218.469 112.983 219.409 112.983 220.569V231.289H102.263C101.103 231.289 100.163 232.229 100.163 233.389C100.163 234.549 101.103 235.489 102.263 235.489H112.983V246.209C112.983 247.369 113.923 248.309 115.083 248.309C116.243 248.309 117.183 247.369 117.183 246.209V235.489H127.903C129.063 235.489 130.003 234.549 130.003 233.389C130.003 232.229 129.063 231.289 127.903 231.289Z",fill:"#030303"}),r.createElement("path",{d:"M197.283 230.839C197.213 226.089 193.303 222.309 188.563 222.379C183.823 222.449 180.033 226.359 180.103 231.109L180.813 277.499L197.993 277.239L197.283 230.849V230.839Z",fill:"white"}),r.createElement("path",{d:"M180.533 280.099C179.233 279.959 178.203 278.869 178.183 277.529L177.473 231.139C177.383 224.949 182.333 219.849 188.513 219.749C191.513 219.699 194.343 220.829 196.493 222.909C198.643 224.999 199.854 227.799 199.904 230.789L200.614 277.179C200.634 278.629 199.473 279.819 198.033 279.839C196.583 279.859 195.394 278.709 195.364 277.259L194.654 230.869C194.634 229.279 193.983 227.789 192.843 226.679C191.703 225.569 190.193 224.969 188.593 224.999C185.303 225.049 182.674 227.769 182.714 231.059L183.424 277.449C183.444 278.899 182.283 280.089 180.843 280.109C180.733 280.109 180.634 280.109 180.524 280.099H180.533Z",fill:"#030303"}),r.createElement("path",{d:"M167.793 288.878C167.193 288.438 166.833 287.728 166.793 286.898C166.773 286.488 166.833 286.058 166.973 285.648C167.113 285.248 167.323 284.858 167.593 284.508C167.593 284.508 168.493 283.358 170.073 281.358C170.883 280.388 171.863 279.218 172.983 277.868C174.113 276.528 175.413 275.078 176.823 273.478C179.673 270.358 183.023 266.748 186.723 263.138C190.413 259.508 194.413 255.778 198.473 252.208C206.603 245.068 214.983 238.478 221.383 233.768C224.573 231.398 227.273 229.488 229.163 228.148C231.063 226.828 232.143 226.068 232.143 226.068C232.273 225.978 232.413 225.898 232.553 225.828L233.053 225.488C235.283 223.958 237.913 223.468 240.323 223.908C242.733 224.348 244.923 225.728 246.333 227.898C247.063 229.028 247.513 230.258 247.713 231.518L247.923 231.378C250.073 229.968 252.673 229.518 255.153 230.098C257.583 230.668 259.623 232.168 260.903 234.278C262.933 237.658 262.663 241.768 260.623 244.718C261.923 245.458 263.073 246.538 263.923 247.898C266.143 251.448 265.883 255.808 263.623 258.738C264.823 259.468 265.883 260.488 266.713 261.758C268.133 263.928 268.613 266.408 268.293 268.668C267.963 270.928 266.833 272.968 264.933 274.278C264.933 274.278 264.073 274.878 262.793 275.768C261.513 276.668 259.813 277.878 258.133 279.108C256.453 280.338 254.773 281.578 253.543 282.518C252.923 282.988 252.403 283.378 252.043 283.658C251.683 283.938 251.483 284.098 251.483 284.098C251.353 284.198 251.213 284.288 251.073 284.358C251.073 284.358 250.403 284.878 249.233 285.788C248.653 286.248 247.953 286.808 247.143 287.448C246.333 288.088 245.433 288.818 244.453 289.618C240.543 292.808 235.443 297.158 230.703 301.668C225.943 306.168 221.543 310.798 218.503 314.318C217.713 315.188 217.053 316.008 216.463 316.718C215.873 317.438 215.323 318.058 214.933 318.578C214.123 319.608 213.663 320.198 213.663 320.198C213.463 320.448 213.223 320.638 212.933 320.768C212.653 320.898 212.353 320.968 212.033 320.978C211.383 320.998 210.673 320.788 210.053 320.328L167.803 288.898L167.793 288.878Z",fill:"white"}),r.createElement("path",{d:"M268.963 260.308C268.443 259.498 267.853 258.768 267.203 258.128C268.743 254.578 268.573 250.178 266.283 246.438C265.703 245.498 265.013 244.648 264.233 243.908C265.613 240.448 265.463 236.338 263.483 232.758C261.843 230.008 259.183 228.068 256.023 227.318C253.873 226.808 251.653 226.898 249.583 227.538C249.373 227.108 249.143 226.688 248.883 226.268C247.083 223.438 244.233 221.628 241.063 221.058C237.903 220.488 234.433 221.138 231.483 223.168L231.143 223.398C230.943 223.508 230.753 223.618 230.573 223.748C230.573 223.748 229.483 224.508 227.563 225.838C225.663 227.188 222.943 229.108 219.723 231.498C213.273 236.248 204.833 242.878 196.633 250.088C192.533 253.698 188.493 257.468 184.763 261.128C181.023 264.778 177.633 268.428 174.743 271.588C173.313 273.218 172.003 274.688 170.853 276.038C169.713 277.408 168.723 278.598 167.903 279.578C166.303 281.618 165.383 282.778 165.383 282.778C165.103 283.138 164.853 283.508 164.643 283.898C164.433 284.288 164.263 284.708 164.123 285.128C163.853 285.968 163.723 286.828 163.763 287.648C163.843 289.308 164.583 290.708 165.793 291.568L208.673 322.138C209.933 323.038 211.373 323.438 212.673 323.398C213.323 323.378 213.933 323.238 214.463 322.988C214.733 322.858 214.973 322.708 215.213 322.528C215.453 322.348 215.673 322.128 215.863 321.888C215.863 321.888 216.313 321.318 217.103 320.308C217.483 319.798 218.013 319.198 218.593 318.498C219.173 317.798 219.813 317.008 220.593 316.148C223.563 312.708 227.883 308.168 232.563 303.738C237.223 299.298 242.243 295.018 246.103 291.858C248.023 290.278 249.673 288.988 250.813 288.078C251.973 287.178 252.633 286.668 252.633 286.668C252.833 286.558 253.013 286.428 253.203 286.288C253.203 286.288 253.403 286.128 253.763 285.858C254.123 285.588 254.633 285.198 255.253 284.728C256.473 283.788 258.143 282.568 259.803 281.348C261.473 280.128 263.163 278.928 264.423 278.038C265.693 277.148 266.543 276.558 266.543 276.558C269.013 274.858 270.493 272.208 270.943 269.278C271.383 266.348 270.783 263.118 268.973 260.288L268.963 260.308ZM263.353 271.968C263.353 271.968 262.493 272.568 261.193 273.468C259.903 274.378 258.193 275.598 256.493 276.838C254.803 278.078 253.113 279.328 251.863 280.278C251.233 280.748 250.713 281.148 250.353 281.428C249.993 281.708 249.783 281.868 249.783 281.868L249.803 281.788C249.803 281.788 249.123 282.318 247.923 283.248C247.323 283.708 246.603 284.278 245.783 284.938C244.963 285.588 244.033 286.328 243.033 287.148C239.033 290.398 233.833 294.838 228.963 299.438C224.093 304.038 219.563 308.788 216.433 312.408C215.623 313.308 214.943 314.148 214.323 314.878C213.713 315.618 213.153 316.258 212.743 316.788C211.903 317.858 211.423 318.468 211.423 318.468L169.793 286.218C169.793 286.218 170.683 285.088 172.243 283.118C173.033 282.168 174.003 281.008 175.113 279.678C176.223 278.358 177.513 276.928 178.893 275.348C181.713 272.268 185.023 268.698 188.683 265.138C192.333 261.548 196.293 257.858 200.313 254.308C208.373 247.228 216.683 240.698 223.043 236.018C226.213 233.658 228.893 231.768 230.773 230.438C232.663 229.128 233.733 228.378 233.733 228.378L233.753 228.408L234.633 227.808C237.693 225.698 241.843 226.508 243.833 229.548C245.823 232.598 245.023 236.648 242.083 238.668C242.083 238.668 243.903 237.408 245.753 236.178C247.593 234.948 249.453 233.738 249.453 233.738C252.473 231.768 256.523 232.728 258.433 235.818C260.343 238.918 259.523 242.888 256.633 244.768C256.633 244.768 255.703 245.378 254.763 245.998C253.833 246.618 252.903 247.238 252.903 247.238C255.773 245.398 259.653 246.378 261.583 249.398C263.543 252.468 262.873 256.398 260.113 258.248L258.153 259.578C257.173 260.248 256.203 260.918 256.203 260.918L256.183 260.948C258.913 259.348 262.553 260.338 264.483 263.248C266.493 266.288 265.963 270.168 263.333 271.988L263.353 271.968Z",fill:"#030303"}),r.createElement("path",{d:"M237.773 261.189C237.203 261.129 236.663 260.839 236.303 260.349C235.613 259.419 235.813 258.099 236.743 257.409L240.173 254.879C242.963 252.849 245.553 251.009 247.873 249.419C250.373 247.699 253.223 245.779 255.693 244.169L259.283 241.859C260.263 241.229 261.553 241.509 262.183 242.489C262.813 243.469 262.523 244.759 261.553 245.389L257.973 247.689C255.543 249.279 252.723 251.169 250.253 252.879C247.963 254.459 245.403 256.269 242.653 258.279L239.233 260.799C238.793 261.119 238.273 261.249 237.773 261.199V261.189Z",fill:"#030303"}),r.createElement("path",{d:"M229.013 249.369C228.443 249.339 227.893 249.069 227.503 248.589C226.773 247.689 226.913 246.369 227.823 245.639L231.143 242.969C233.843 240.819 236.353 238.879 238.603 237.179C241.023 235.349 243.793 233.309 246.193 231.599L249.683 229.139C250.633 228.469 251.943 228.699 252.613 229.649C253.283 230.599 253.053 231.909 252.103 232.579L248.623 235.039C246.263 236.729 243.523 238.739 241.123 240.549C238.903 242.229 236.423 244.149 233.763 246.259L230.453 248.919C230.033 249.259 229.513 249.409 229.003 249.379L229.013 249.369Z",fill:"#030303"}),r.createElement("path",{d:"M243.393 275.369C242.823 275.339 242.273 275.069 241.883 274.589C241.153 273.689 241.293 272.359 242.203 271.639L245.523 268.969C248.223 266.819 250.733 264.879 252.983 263.179C255.403 261.349 258.173 259.319 260.573 257.599L264.063 255.139C265.013 254.469 266.323 254.699 266.993 255.649C267.663 256.599 267.433 257.909 266.493 258.579L263.013 261.029C260.653 262.719 257.913 264.729 255.523 266.539C253.303 268.209 250.823 270.139 248.163 272.249L244.853 274.909C244.433 275.249 243.913 275.399 243.403 275.369H243.393Z",fill:"#030303"}),r.createElement("path",{d:"M215.463 324.348C215.463 324.348 215.353 324.448 215.133 324.658C214.923 324.848 214.613 325.138 214.213 325.508C213.823 325.868 213.333 326.308 212.753 326.838C212.173 327.368 211.523 327.938 210.803 328.578C210.073 329.218 209.273 329.928 208.393 330.698C207.523 331.448 206.573 332.258 205.563 333.118C203.543 334.868 201.253 336.718 198.763 338.778C188.763 346.938 175.103 357.068 160.813 366.358C153.683 371.018 146.403 375.458 139.453 379.448C136.023 381.508 132.573 383.298 129.353 385.068C127.733 385.948 126.163 386.798 124.643 387.628C123.103 388.428 121.603 389.168 120.163 389.898C117.283 391.348 114.653 392.668 112.313 393.838C109.943 394.968 107.853 395.908 106.153 396.698C102.733 398.268 100.773 399.168 100.773 399.168L72.2832 335.158C72.2832 335.158 73.9031 334.408 76.7231 333.108C78.1331 332.448 79.8632 331.678 81.8232 330.748C83.7732 329.768 85.963 328.668 88.353 327.458C89.553 326.858 90.803 326.238 92.083 325.578C93.353 324.888 94.6734 324.168 96.0234 323.428C98.7234 321.938 101.613 320.458 104.503 318.708C110.343 315.348 116.503 311.598 122.543 307.648C134.633 299.778 146.273 291.148 154.563 284.388C156.613 282.688 158.533 281.148 160.133 279.748C160.943 279.058 161.703 278.408 162.413 277.808C163.093 277.208 163.713 276.658 164.283 276.158C164.853 275.658 165.353 275.218 165.763 274.838C166.173 274.458 166.533 274.138 166.813 273.878C167.103 273.618 167.323 273.418 167.443 273.298C167.573 273.178 167.643 273.108 167.643 273.108L215.453 324.318L215.463 324.348Z"}),r.createElement("path",{d:"M68.7032 336.199C68.7532 336.379 68.8234 336.549 68.9034 336.729C69.7634 338.599 71.9831 339.419 73.8531 338.559L78.2935 336.509C78.8135 336.269 79.3632 336.019 79.9532 335.749C80.9932 335.279 82.1632 334.739 83.4332 334.139C83.4632 334.129 83.4832 334.119 83.5132 334.099L90.0435 330.809C90.4835 330.589 90.9231 330.369 91.3731 330.139C92.1731 329.739 92.9835 329.329 93.8135 328.909C93.8335 328.899 93.8634 328.879 93.8834 328.869L97.8233 326.719C98.6033 326.289 99.3834 325.869 100.173 325.439C102.193 324.349 104.283 323.219 106.413 321.939C112.593 318.389 118.713 314.639 124.603 310.789C135.703 303.569 147.493 294.999 156.943 287.289C157.583 286.759 158.183 286.269 158.763 285.789C160.133 284.659 161.433 283.599 162.593 282.589L164.853 280.659C164.853 280.659 164.883 280.629 164.903 280.619L166.773 278.969C167.013 278.759 167.233 278.559 167.443 278.379L210.173 324.139C209.623 324.639 209.023 325.179 208.343 325.769L205.953 327.879L203.143 330.279C201.653 331.569 199.993 332.939 198.233 334.379C197.633 334.879 197.013 335.379 196.383 335.899C185.343 344.899 171.633 354.869 158.773 363.229C151.903 367.719 144.783 372.079 137.593 376.209C137.573 376.219 137.553 376.229 137.533 376.239C135.063 377.719 132.553 379.079 130.133 380.389C129.263 380.859 128.404 381.329 127.564 381.789L122.903 384.319C121.913 384.839 120.923 385.329 119.973 385.809C119.473 386.059 118.973 386.309 118.483 386.559L110.683 390.479C109.123 391.219 107.673 391.889 106.393 392.469C105.753 392.759 105.143 393.039 104.583 393.299L99.2134 395.769C97.3434 396.629 96.5234 398.849 97.3834 400.719C98.2434 402.589 100.463 403.409 102.333 402.549L107.713 400.079C108.283 399.819 108.873 399.539 109.503 399.249C110.813 398.649 112.303 397.959 113.923 397.199C113.943 397.189 113.973 397.179 113.993 397.169L121.843 393.229C122.333 392.979 122.824 392.739 123.314 392.489C124.304 391.989 125.323 391.479 126.363 390.939C126.383 390.929 126.403 390.919 126.423 390.909L131.133 388.349C131.983 387.879 132.823 387.429 133.683 386.959C136.173 385.609 138.743 384.219 141.333 382.669C148.633 378.479 155.873 374.039 162.843 369.489C175.903 360.989 189.853 350.849 201.103 341.669C201.743 341.139 202.353 340.639 202.953 340.149C204.753 338.669 206.443 337.279 207.993 335.939L210.803 333.539C210.803 333.539 210.833 333.509 210.843 333.499L213.253 331.379C213.993 330.729 214.653 330.149 215.263 329.589L217.993 327.079C219.493 325.669 219.573 323.309 218.173 321.809L170.363 270.599C169.683 269.869 168.753 269.449 167.763 269.419C166.773 269.389 165.813 269.749 165.083 270.429L164.883 270.609C164.883 270.609 164.863 270.629 164.853 270.639C164.743 270.739 164.553 270.909 164.303 271.139L163.243 272.099C162.863 272.459 162.394 272.869 161.814 273.369L159.963 274.999L157.713 276.919C157.713 276.919 157.693 276.939 157.683 276.939C156.603 277.879 155.343 278.919 154.003 280.009C153.413 280.499 152.803 280.999 152.173 281.509C142.943 289.039 131.393 297.429 120.503 304.519C114.713 308.299 108.703 311.979 102.643 315.469C102.623 315.479 102.593 315.499 102.573 315.509C100.583 316.709 98.5631 317.799 96.6031 318.859C95.7931 319.299 95.0032 319.729 94.2232 320.159L90.3331 322.279C89.5431 322.689 88.7732 323.069 88.0132 323.449C87.5532 323.679 87.1034 323.909 86.6534 324.129L80.1631 327.399C78.9531 327.969 77.8233 328.489 76.8233 328.949C76.2233 329.229 75.6534 329.479 75.1334 329.729L70.7032 331.769C69.0032 332.549 68.1732 334.449 68.6832 336.189L68.7032 336.199Z"}),r.createElement("path",{d:"M91.803 364.979C91.823 365.029 91.8328 365.089 91.8528 365.139C92.1928 365.989 93.163 366.399 94.013 366.059C94.373 365.919 102.973 362.429 117.903 353.679C131.643 345.629 153.513 331.429 179.703 309.469C180.403 308.879 180.493 307.839 179.913 307.129C179.323 306.429 178.283 306.339 177.573 306.929C151.553 328.739 129.853 342.839 116.223 350.819C101.503 359.439 92.8533 362.949 92.7733 362.979C91.9733 363.299 91.563 364.169 91.803 364.979Z",fill:"#030303"}),r.createElement("path",{d:"M125.993 373.399C126.163 374.009 126.683 374.479 127.353 374.579C128.263 374.709 129.103 374.079 129.233 373.179C130.533 364.119 129.233 353.049 125.373 340.289C122.513 330.839 119.313 324.119 119.183 323.839C118.793 323.009 117.803 322.659 116.973 323.059C116.143 323.449 115.793 324.439 116.193 325.269C116.323 325.539 128.903 352.199 125.953 372.709C125.913 372.949 125.933 373.189 126.003 373.409L125.993 373.399Z",fill:"#030303"}),r.createElement("path",{d:"M121.884 321.859C121.974 322.149 122.134 322.429 122.384 322.639C122.584 322.819 142.554 340.459 147.114 361.269C147.314 362.159 148.193 362.729 149.083 362.529C149.983 362.329 150.543 361.449 150.353 360.559C145.553 338.649 125.414 320.889 124.564 320.139C123.874 319.539 122.823 319.609 122.223 320.299C121.843 320.739 121.724 321.329 121.884 321.849V321.859Z",fill:"#030303"}),r.createElement("path",{d:"M189.633 110.708C189.743 118.108 183.673 124.208 176.053 124.328C168.443 124.448 162.183 118.538 162.063 111.128C161.953 103.728 168.033 97.6284 175.643 97.5184C183.253 97.3984 189.523 103.308 189.633 110.708Z",fill:"#030303"}),r.createElement("path",{d:"M269.194 59.6885C268.574 59.6885 267.983 59.3585 267.663 58.7885C255.993 37.6985 237.193 21.0585 214.723 11.9285C203.533 7.37854 191.784 4.78854 179.774 4.21854C167.354 3.62854 154.984 5.23853 143.004 8.99854C142.084 9.28854 141.104 8.77854 140.814 7.84854C140.524 6.92854 141.034 5.94854 141.964 5.65854C154.334 1.77854 167.113 0.11853 179.953 0.72853C192.353 1.31853 204.503 3.98854 216.053 8.68854C239.253 18.1185 258.674 35.3085 270.734 57.0985C271.204 57.9485 270.893 59.0085 270.053 59.4785C269.783 59.6285 269.493 59.6985 269.203 59.6985L269.194 59.6885Z",fill:"#030303"}),r.createElement("path",{d:"M163.153 219.449C163.093 219.449 163.023 219.449 162.963 219.449C140.523 217.009 119.653 207.859 102.593 192.989C101.863 192.349 101.793 191.249 102.423 190.519C103.063 189.789 104.163 189.719 104.893 190.349C121.403 204.749 141.613 213.609 163.343 215.969C164.303 216.069 164.993 216.939 164.893 217.899C164.793 218.799 164.033 219.459 163.153 219.459V219.449Z",fill:"#030303"})));i.displayName="AnalyseIllustration";const l=(0,r.forwardRef)((e,t)=>r.createElement("svg",(0,a.A)({width:"326",height:"308",viewBox:"0 0 326 308",fill:"none",xmlns:"http://www.w3.org/2000/svg",ref:t},e),r.createElement("path",{d:"M130.528 179.308H87.1355C85.3706 179.308 83.9399 177.877 83.9399 176.112C83.9399 174.347 85.3706 172.917 87.1355 172.917H130.528C132.293 172.917 133.723 174.347 133.723 176.112C133.723 177.877 132.293 179.308 130.528 179.308Z",fill:"#030303"}),r.createElement("path",{d:"M130.528 197.949H87.1355C85.3706 197.949 83.9399 196.519 83.9399 194.754C83.9399 192.989 85.3706 191.558 87.1355 191.558H130.528C132.293 191.558 133.723 192.989 133.723 194.754C133.723 196.519 132.293 197.949 130.528 197.949Z",fill:"#030303"}),r.createElement("path",{d:"M130.528 216.592H87.1355C85.3706 216.592 83.9399 215.161 83.9399 213.396C83.9399 211.631 85.3706 210.201 87.1355 210.201H130.528C132.293 210.201 133.723 211.631 133.723 213.396C133.723 215.161 132.293 216.592 130.528 216.592Z",fill:"#030303"}),r.createElement("path",{d:"M272.323 137.705H70.7643C70.1046 137.705 69.5649 138.245 69.5649 138.904C69.5649 139.564 70.1046 140.104 70.7643 140.104H272.323C272.983 140.104 273.523 139.564 273.523 138.904C273.523 138.245 272.983 137.705 272.323 137.705Z",fill:"#030303"}),r.createElement("path",{d:"M89.8429 120.28C89.8429 124.623 86.3221 128.144 81.9786 128.144C77.635 128.144 74.1138 124.623 74.1138 120.28C74.1138 115.936 77.635 112.415 81.9786 112.415C86.3221 112.415 89.8429 115.936 89.8429 120.28Z",fill:"#030303"}),r.createElement("path",{d:"M110.73 120.28C110.73 124.623 107.209 128.144 102.865 128.144C98.5217 128.144 95.0005 124.623 95.0005 120.28C95.0005 115.936 98.5217 112.415 102.865 112.415C107.209 112.415 110.73 115.936 110.73 120.28Z",fill:"#030303"}),r.createElement("path",{d:"M131.608 120.28C131.608 124.623 128.087 128.144 123.743 128.144C119.4 128.144 115.878 124.623 115.878 120.28C115.878 115.936 119.4 112.415 123.743 112.415C128.087 112.415 131.608 115.936 131.608 120.28Z",fill:"#030303"}),r.createElement("path",{d:"M323.512 83.6039L292.67 84.572C292.344 84.5806 292.036 84.6748 291.779 84.8376C291.248 85.1631 290.905 85.7542 290.931 86.4225C290.965 87.4163 291.796 88.1959 292.782 88.1616L323.623 87.1935C324.617 87.1593 325.397 86.3282 325.362 85.3344C325.328 84.3406 324.505 83.5611 323.512 83.5953V83.6039Z"}),r.createElement("path",{d:"M281.233 54.2791C281.756 55.1272 282.87 55.3842 283.709 54.8616L309.933 38.6012C310.781 38.0786 311.038 36.9735 310.516 36.1253C309.993 35.2772 308.879 35.0202 308.04 35.5428L281.816 51.8032C280.968 52.3258 280.711 53.4395 281.233 54.2791Z"}),r.createElement("path",{d:"M259.19 30.5479L273.771 3.35576C274.242 2.48191 273.908 1.39392 273.034 0.922725C272.452 0.60574 271.766 0.648582 271.235 0.982701C270.978 1.14548 270.756 1.37677 270.601 1.65949L256.02 28.8516C255.549 29.7254 255.883 30.8135 256.757 31.2847C257.631 31.7559 258.719 31.4218 259.19 30.5479Z"}),r.createElement("path",{d:"M52.9697 245.634V114.257C52.9697 103.18 61.9825 94.167 73.0598 94.167H267.782C278.86 94.167 287.872 103.18 287.872 114.257V245.634C287.872 256.711 278.86 265.724 267.782 265.724H73.0598C61.9825 265.724 52.9697 256.711 52.9697 245.634ZM73.051 100.25C65.3235 100.25 59.0441 106.538 59.0441 114.257V245.634C59.0441 253.362 65.3321 259.641 73.051 259.641H267.774C275.501 259.641 281.781 253.353 281.781 245.634V114.257C281.781 106.529 275.501 100.25 267.774 100.25H73.051Z",fill:"#030303"}),r.createElement("path",{d:"M271.484 275.885V287.245C271.484 298.323 262.471 307.335 251.394 307.335H23.8679C12.7906 307.335 3.77783 298.323 3.77783 287.245V275.885H271.484Z",fill:"#030303"}),r.createElement("path",{d:"M87.933 293.439H132.825C134.829 293.439 136.449 291.811 136.449 289.815C136.449 287.819 134.829 286.191 132.825 286.191H87.933C85.9283 286.191 84.3091 287.81 84.3091 289.815C84.3091 291.82 85.9368 293.439 87.933 293.439Z",fill:"white"}),r.createElement("path",{d:"M182.642 72.2783L170.862 64.0196C170.245 63.5827 169.414 63.5827 168.797 64.0196L158.054 71.5587L147.311 64.0196C146.694 63.5827 145.863 63.5827 145.246 64.0196L134.503 71.5587L123.76 64.0196C123.143 63.5827 122.312 63.5827 121.695 64.0196L110.952 71.5587L100.209 64.0196C99.592 63.5827 98.7608 63.5827 98.144 64.0196L87.4008 71.5587L76.658 64.0196C76.0411 63.5827 75.21 63.5827 74.5932 64.0196L62.8133 72.2783C61.9995 72.8523 61.8022 73.9746 62.3762 74.7885C62.7275 75.2854 63.2845 75.551 63.8499 75.551C64.2098 75.551 64.5697 75.4482 64.8782 75.2254L75.621 67.6949L86.3642 75.2254C86.981 75.6623 87.8122 75.6623 88.429 75.2254L99.1722 67.6949L109.915 75.2254C110.532 75.6623 111.363 75.6623 111.98 75.2254L122.723 67.6949L133.466 75.2254C134.083 75.6623 134.914 75.6623 135.531 75.2254L146.274 67.6949L157.018 75.2254C157.634 75.6623 158.466 75.6623 159.082 75.2254L169.826 67.6949L180.568 75.2254C181.382 75.7994 182.505 75.6024 183.079 74.7885C183.653 73.9746 183.456 72.8523 182.642 72.2783Z"}),r.createElement("path",{d:"M36.2807 194.977C36.2807 194.977 40.2045 192.21 40.4015 188.003C40.5214 185.468 39.2963 183.129 36.7605 181.038C33.5992 178.442 32.9908 176.798 33.0337 175.881C33.0936 174.527 34.7471 173.311 36.2807 172.266C36.3235 172.24 40.2047 169.498 40.4103 165.292C40.5302 162.756 39.3051 160.417 36.7693 158.327C34.8673 156.768 33.9249 155.2 33.9506 153.683C33.9935 151.336 36.3066 149.546 36.358 149.511C37.1462 148.92 37.3173 147.798 36.7262 147.001C36.135 146.204 35.0042 146.033 34.2075 146.624C34.0533 146.735 30.4551 149.451 30.3523 153.572C30.2837 156.262 31.6719 158.798 34.4819 161.103C36.0754 162.413 36.855 163.741 36.8207 165.061C36.7607 167.022 34.9102 168.813 34.2506 169.301C32.5029 170.484 29.5983 172.454 29.4441 175.71C29.3242 178.28 30.9694 180.927 34.4819 183.814C36.0754 185.125 36.855 186.453 36.8207 187.772C36.7607 189.734 34.9102 191.524 34.2506 192.013C32.5029 193.195 29.5983 195.166 29.4441 198.421C29.3242 200.991 30.9694 203.638 34.4819 206.526C36.0754 207.836 36.855 209.164 36.8207 210.484C36.7607 212.445 34.9102 214.236 34.2506 214.724C32.5029 215.907 29.5983 217.877 29.4441 221.132C29.3242 223.703 30.9694 226.35 34.4819 229.237C34.816 229.511 35.2183 229.648 35.621 229.648C36.1436 229.648 36.6577 229.425 37.0089 228.989C37.6429 228.218 37.5315 227.087 36.7605 226.453C33.5992 223.857 32.9908 222.212 33.0337 221.295C33.0936 219.942 34.7471 218.725 36.2807 217.68C36.3235 217.654 40.2047 214.921 40.4103 210.706C40.5302 208.17 39.3051 205.823 36.7693 203.741C33.608 201.145 32.9996 199.5 33.0425 198.584C33.1024 197.23 34.7559 196.014 36.2894 194.968L36.2807 194.977Z",fill:"#030303"}),r.createElement("path",{d:"M31.2098 244.143H18.3591V231.293C18.3591 230.299 17.5537 229.494 16.5599 229.494C15.5661 229.494 14.7612 230.299 14.7612 231.293V244.143H1.91881C0.925024 244.143 0.119629 244.949 0.119629 245.943C0.119629 246.936 0.925024 247.742 1.91881 247.742H14.7612V260.584C14.7612 261.578 15.5661 262.383 16.5599 262.383C17.5537 262.383 18.3591 261.578 18.3591 260.584V247.742H31.2098C32.2036 247.742 33.009 246.936 33.009 245.943C33.009 244.949 32.2036 244.143 31.2098 244.143Z"}),r.createElement("path",{d:"M189.299 149.357C189.299 149.357 196.187 135.384 195.347 130.569C193.925 122.422 194.294 112.886 194.294 112.886C194.294 112.886 190.284 105.913 176.063 101.381C175.412 101.149 174.812 100.927 174.281 100.764C173.75 100.584 173.296 100.438 172.919 100.335C172.542 100.224 172.242 100.138 172.045 100.078C171.848 100.027 171.737 100.001 171.737 100.001C171.385 99.9157 171.06 99.7786 170.751 99.5987C170.443 99.4274 170.16 99.2303 169.894 98.9819C169.363 98.4764 168.927 97.8853 168.558 97.1571C168.19 96.4203 167.907 95.6236 167.735 94.724C167.564 93.833 167.496 92.8564 167.607 91.8626C167.718 90.8688 168.001 89.935 168.455 89.1125C168.909 88.2987 169.543 87.5533 170.288 87.0222C171.034 86.4739 171.925 86.0712 172.85 85.8999C173.313 85.8142 173.801 85.7542 174.281 85.7799C174.761 85.7971 175.24 85.8656 175.729 85.9855C175.729 85.9855 175.883 86.0198 176.149 86.0969C176.423 86.174 176.817 86.2854 177.322 86.431C191.535 90.6032 199.879 95.2466 199.879 95.2466C199.879 95.2466 201.422 93.2333 201.55 85.6771C201.73 75.4565 199.117 60.9438 198.577 57.7739C198.517 57.3713 198.457 56.9943 198.397 56.6345C198.329 56.2747 198.269 55.9406 198.209 55.6236C198.089 54.9896 197.986 54.4328 197.909 53.9787C197.823 53.5246 197.763 53.1563 197.703 52.925C197.652 52.6851 197.626 52.5651 197.626 52.5651C197.446 51.7341 197.472 50.9031 197.678 50.0892C197.866 49.3011 198.209 48.5471 198.714 47.8275C199.203 47.1164 199.863 46.431 200.599 45.8827C201.336 45.3259 202.201 44.8461 203.169 44.5291C204.138 44.2121 205.114 44.0922 206.065 44.1693C207.025 44.255 207.898 44.5206 208.712 44.9661C209.517 45.4116 210.246 46.037 210.811 46.7909C212.867 50.2177 214.924 63.274 215.429 67.8318C215.935 72.398 216.765 77.11 216.765 77.11L219.721 64.1393C221.297 50.9031 220.835 37.487 231.047 37.8297C235.048 38.3437 237.781 42.1561 237.155 46.3368L233.077 76.7073L246.134 53.3961C247.65 49.9693 251.882 48.4529 255.575 50.0035C259.276 51.5542 261.04 55.5893 259.516 59.0162L248.455 81.2907C248.455 81.2907 263.602 70.479 264.253 69.8451C264.913 69.2111 265.298 68.8512 265.298 68.8512C266.566 67.669 268.365 67.1978 270.096 67.4805C270.969 67.6262 271.826 67.9603 272.589 68.4572C273.36 68.9627 274.045 69.648 274.619 70.4533C275.193 71.2672 275.621 72.1239 275.93 72.9635C276.238 73.8202 276.427 74.6427 276.495 75.4137C276.632 76.9815 276.273 78.3436 275.245 79.2946C275.245 79.2946 274.927 79.5944 274.379 80.1085C273.831 80.6396 273.051 81.4107 272.109 82.3788C265.469 88.6928 259.978 90.6289 256.971 94.981C250.126 104.885 244.557 126.268 236.316 135.606C232.143 140.335 226.866 158.849 226.866 158.849L189.299 149.331V149.357Z",fill:"white"}),r.createElement("path",{d:"M226.866 161.128C226.686 161.128 226.498 161.102 226.309 161.06L188.742 151.541C188.083 151.379 187.535 150.916 187.252 150.308C186.969 149.691 186.978 148.98 187.277 148.372C190.002 142.837 193.617 133.782 193.129 130.963C191.895 123.921 191.964 116.022 192.024 113.563C190.867 112.047 186.369 107.035 175.386 103.531C175.361 103.523 175.335 103.514 175.309 103.505L175.027 103.403C174.513 103.214 174.033 103.043 173.63 102.923C173.613 102.923 173.596 102.914 173.587 102.906C173.142 102.76 172.679 102.606 172.345 102.512C172.328 102.512 172.319 102.512 172.302 102.503L171.189 102.186C170.657 102.049 170.126 101.835 169.63 101.552C169.158 101.287 168.747 100.978 168.37 100.636C167.625 99.933 167.033 99.1276 166.554 98.1767C166.074 97.2086 165.74 96.2234 165.534 95.1611C165.303 93.9703 165.251 92.7794 165.38 91.6143C165.525 90.3121 165.903 89.1041 166.494 88.0332C167.111 86.9024 167.976 85.9257 168.978 85.1975C170.015 84.435 171.223 83.9124 172.439 83.6811C173.116 83.5526 173.758 83.5012 174.375 83.5183C175.009 83.544 175.643 83.6297 176.26 83.7925C176.32 83.8096 176.492 83.8439 176.757 83.921L177.948 84.2637C188.057 87.2279 195.202 90.4063 198.646 92.0855C198.946 90.7918 199.246 88.7357 199.297 85.6259C199.409 79.3633 198.449 70.3249 196.47 58.7764L195.639 54.0388C195.596 53.799 195.554 53.5591 195.528 53.4477C195.528 53.4306 195.519 53.4049 195.511 53.3877L195.433 53.045C195.176 51.897 195.202 50.7234 195.494 49.5497C195.742 48.4959 196.204 47.485 196.864 46.534C197.498 45.6173 198.329 44.7606 199.254 44.0752C200.24 43.3299 201.328 42.7644 202.467 42.3875C203.718 41.9763 205.012 41.8221 206.254 41.9249C207.513 42.0363 208.696 42.3961 209.792 42.9958C210.897 43.604 211.865 44.4522 212.611 45.4374C212.654 45.4974 212.696 45.5659 212.739 45.6259C214.778 49.0185 216.517 59.3333 217.288 64.7049L217.503 63.7539C217.725 61.8777 217.905 59.9844 218.085 58.151C218.625 52.5481 219.139 47.2536 220.647 43.21C222.54 38.1468 225.907 35.5767 230.662 35.5767C230.816 35.5767 230.961 35.5767 231.115 35.5767C231.184 35.5767 231.261 35.5766 231.33 35.5938C233.806 35.9107 235.999 37.1958 237.515 39.2005C239.109 41.3166 239.769 43.9553 239.366 46.6454L236.864 65.3217L244.112 52.3768C245.577 49.1898 248.875 47.1423 252.568 47.1423C253.896 47.1423 255.198 47.4079 256.44 47.9219C258.839 48.9328 260.749 50.8433 261.683 53.1821C262.557 55.3839 262.523 57.7827 261.572 59.9159C261.555 59.9501 261.546 59.9758 261.529 60.0015L254.487 74.1887C258.522 71.2844 262.189 68.6287 262.729 68.1746L263.748 67.2065C265.187 65.87 267.081 65.1418 269.102 65.1418C269.557 65.1418 270.011 65.1761 270.456 65.2532C271.656 65.4502 272.786 65.8958 273.823 66.5726C274.808 67.2151 275.699 68.0889 276.444 69.1427C277.087 70.0508 277.627 71.0789 278.029 72.1754C278.406 73.2121 278.638 74.223 278.723 75.1997C278.98 78.1982 277.798 79.9716 276.77 80.9311L275.93 81.7364C275.459 82.1905 274.68 82.9615 273.72 83.9381C273.703 83.9552 273.677 83.981 273.66 83.9981C270.473 87.0309 267.594 89.0527 265.059 90.8347C262.351 92.7366 260.21 94.2444 258.822 96.2491C255.935 100.421 253.244 106.838 250.392 113.632C246.682 122.465 242.852 131.589 238.003 137.089C234.859 140.653 230.456 154.446 229.025 159.466C228.742 160.451 227.843 161.102 226.866 161.102V161.128ZM192.504 147.849L225.316 156.168C226.892 150.959 230.97 138.288 234.628 134.142C238.989 129.198 242.673 120.417 246.237 111.918C249.184 104.902 251.96 98.2795 255.112 93.7218C256.954 91.0574 259.507 89.2669 262.463 87.1851C264.862 85.4974 267.577 83.5869 270.516 80.8026C271.493 79.7916 272.298 79.0035 272.803 78.5152L273.677 77.6841C273.857 77.5128 274.354 77.0502 274.234 75.628C274.183 75.0455 274.029 74.4115 273.797 73.7518C273.532 73.0322 273.18 72.3639 272.769 71.7728C272.349 71.1731 271.861 70.7019 271.338 70.3592C270.841 70.0251 270.284 69.8109 269.719 69.7167C268.588 69.5282 267.535 69.8366 266.815 70.5048L265.787 71.4815C265.161 72.0898 256.714 78.1468 249.749 83.1243C248.909 83.724 247.77 83.6726 246.982 83.0043C246.194 82.3361 245.971 81.2138 246.425 80.2886L257.468 58.0654C257.905 57.0545 257.914 55.915 257.494 54.8527C257.005 53.6276 255.986 52.6167 254.692 52.0769C254.007 51.7856 253.287 51.64 252.559 51.64C250.615 51.64 248.892 52.6852 248.173 54.3044C248.147 54.3644 248.113 54.4329 248.079 54.4929L235.022 77.8041C234.491 78.7464 233.369 79.1834 232.35 78.8407C231.321 78.498 230.687 77.4785 230.833 76.4076L234.911 46.0371C234.911 46.0371 234.911 46.0114 234.911 46.0029C235.134 44.5122 234.782 43.0643 233.917 41.9163C233.154 40.9054 232.067 40.2543 230.841 40.0744C230.773 40.0744 230.713 40.0744 230.644 40.0744C224.947 40.0744 223.757 46.0028 222.54 58.5794C222.36 60.4813 222.172 62.4432 221.932 64.405C221.923 64.4822 221.906 64.5593 221.889 64.6364L218.933 77.607C218.693 78.6522 217.751 79.3804 216.689 79.3547C215.618 79.329 214.718 78.5494 214.53 77.5042C214.495 77.3072 213.673 72.6638 213.168 68.0718C212.585 62.7516 210.563 50.9804 208.918 48.0418C208.558 47.5963 208.104 47.2108 207.599 46.9281C207.059 46.6283 206.485 46.4569 205.851 46.4055C205.226 46.3541 204.532 46.4398 203.847 46.6625C203.17 46.8853 202.527 47.2194 201.936 47.6735C201.396 48.0761 200.908 48.5816 200.548 49.1042C200.197 49.601 199.974 50.0979 199.854 50.6034C199.854 50.612 199.854 50.6205 199.854 50.6377C199.726 51.1345 199.717 51.6229 199.82 52.0855L199.897 52.4282C199.948 52.6595 200 52.9166 200.06 53.2507L200.608 56.232C200.608 56.232 200.608 56.2663 200.608 56.2834L200.891 58.0225C201.653 62.4346 203.958 75.8507 203.786 85.7115C203.649 93.4134 202.116 96.0007 201.653 96.6089C200.977 97.4999 199.751 97.7484 198.775 97.2087C198.689 97.1658 190.448 92.6252 176.68 88.5815L175.524 88.2474C175.352 88.2046 175.241 88.1703 175.215 88.1703C175.206 88.1703 175.189 88.1703 175.172 88.1618C174.847 88.0761 174.513 88.0332 174.187 88.0161C174.153 88.0161 174.118 88.0161 174.084 88.0161C173.844 88.0161 173.57 88.0504 173.262 88.1018C172.696 88.2046 172.114 88.4701 171.608 88.83C171.137 89.1726 170.717 89.6524 170.426 90.1922C170.118 90.749 169.921 91.4001 169.835 92.1112C169.758 92.8137 169.783 93.5505 169.929 94.2872C170.058 94.9469 170.263 95.5552 170.563 96.1549C170.803 96.6346 171.086 97.0116 171.437 97.3457C171.54 97.4399 171.677 97.5342 171.857 97.6455C172.002 97.7312 172.131 97.7826 172.268 97.8169L172.594 97.9026C172.594 97.9026 172.636 97.9111 172.662 97.9197L173.519 98.1682C173.956 98.2881 174.453 98.4509 174.967 98.6222C175.464 98.7764 175.986 98.9649 176.543 99.1619L176.783 99.2476C191.63 103.985 196.05 111.439 196.239 111.756C196.453 112.124 196.556 112.544 196.539 112.964C196.539 113.058 196.196 122.362 197.558 130.166C198.295 134.39 194.611 143.231 192.504 147.832V147.849Z",fill:"#030303"}),r.createElement("path",{d:"M223.798 120.246C222.556 120.246 221.553 119.243 221.545 118.001C221.536 112.021 219.763 107.258 216.276 103.84C209.919 97.5942 199.801 97.6628 199.716 97.6713H199.681C198.456 97.6713 197.454 96.6861 197.428 95.461C197.411 94.2188 198.396 93.1993 199.63 93.1736C200.118 93.165 211.667 93.0365 219.395 100.601C223.781 104.902 226.017 110.753 226.034 117.993C226.034 119.235 225.032 120.246 223.79 120.246H223.798Z",fill:"#030303"}),r.createElement("path",{d:"M251.72 87.5706C251.351 87.5706 250.983 87.3992 250.752 87.0737C246.22 80.8454 234.86 79.3118 226.121 79.1148C216.475 78.9006 207.839 80.2542 207.753 80.2628C207.102 80.3656 206.485 79.9201 206.382 79.269C206.28 78.6179 206.725 78.001 207.376 77.8982C208.824 77.6669 243.041 72.3981 252.688 85.6601C253.073 86.1912 252.962 86.9452 252.422 87.3392C252.208 87.4934 251.96 87.5706 251.72 87.5706Z",fill:"#030303"}),r.createElement("path",{d:"M179.953 136.892C179.953 136.892 179.91 137.02 179.833 137.277C179.755 137.517 179.644 137.877 179.498 138.348C179.361 138.811 179.182 139.376 178.985 140.036C178.779 140.704 178.556 141.449 178.316 142.28C178.076 143.111 177.811 144.037 177.511 145.048C177.237 146.041 176.946 147.121 176.629 148.269C175.978 150.573 175.352 153.143 174.624 155.953C171.814 167.194 168.755 182.186 166.571 197.384C165.466 204.975 164.592 212.617 163.941 219.822C163.555 223.411 163.375 226.915 163.144 230.222C163.032 231.875 162.93 233.486 162.818 235.045C162.741 236.613 162.698 238.121 162.638 239.577C162.536 242.482 162.433 245.146 162.347 247.511C162.313 249.875 162.313 251.948 162.304 253.653C162.296 257.063 162.287 259.008 162.287 259.008L222.368 259.419C222.368 259.419 222.368 257.808 222.386 254.998C222.394 253.593 222.386 251.88 222.411 249.918C222.48 247.956 222.566 245.737 222.66 243.313C222.703 242.105 222.737 240.845 222.805 239.534C222.9 238.224 222.985 236.879 223.079 235.491C223.285 232.715 223.414 229.785 223.748 226.761C224.288 220.704 225.033 214.244 225.967 207.81C227.809 194.943 230.413 182.178 232.752 172.856C233.352 170.543 233.866 168.393 234.388 166.56C234.637 165.634 234.877 164.769 235.099 163.972C235.322 163.193 235.536 162.473 235.725 161.831C235.913 161.179 236.076 160.605 236.23 160.134C236.376 159.654 236.504 159.243 236.607 158.918C236.71 158.584 236.787 158.335 236.83 158.19C236.881 158.035 236.907 157.958 236.907 157.958L179.944 136.9L179.953 136.892Z"}),r.createElement("path",{d:"M222.84 262.76C222.685 262.786 222.523 262.794 222.36 262.786C220.595 262.751 219.164 261.209 219.173 259.35L219.19 254.93C219.19 254.407 219.19 253.859 219.19 253.276C219.19 252.248 219.19 251.083 219.216 249.815C219.216 249.789 219.216 249.764 219.216 249.738L219.464 243.133C219.481 242.687 219.498 242.242 219.516 241.788C219.541 240.982 219.567 240.16 219.61 239.32C219.61 239.295 219.61 239.269 219.61 239.252L219.884 235.208C219.944 234.411 219.995 233.615 220.046 232.801C220.184 230.727 220.321 228.594 220.561 226.358C221.135 219.959 221.889 213.525 222.805 207.253C224.493 195.439 226.995 182.572 229.659 171.957C229.847 171.237 230.019 170.56 230.181 169.901C230.576 168.359 230.944 166.894 231.321 165.574L232.023 162.996C232.023 162.996 232.032 162.961 232.04 162.944L232.666 160.802C232.743 160.528 232.82 160.271 232.889 160.031L181.983 141.218C181.786 141.852 181.58 142.546 181.358 143.325L180.561 146.067L179.687 149.262C179.207 150.967 178.736 152.835 178.23 154.814C178.059 155.491 177.879 156.185 177.699 156.896C174.598 169.301 171.685 184.276 169.723 197.95C168.661 205.266 167.787 212.754 167.119 220.198C167.119 220.216 167.119 220.241 167.119 220.258C166.845 222.837 166.673 225.407 166.511 227.892C166.451 228.783 166.391 229.665 166.331 230.53L166.014 235.311C165.962 236.322 165.928 237.316 165.894 238.275C165.876 238.781 165.859 239.286 165.834 239.774L165.551 247.656C165.525 249.215 165.517 250.655 165.517 251.931C165.517 252.574 165.517 253.173 165.517 253.73L165.5 259.068C165.5 260.935 164.052 262.417 162.287 262.383C160.522 262.349 159.092 260.807 159.1 258.948L159.117 253.593C159.117 253.028 159.117 252.437 159.117 251.811C159.117 250.509 159.117 249.027 159.151 247.408C159.151 247.382 159.151 247.356 159.151 247.339L159.443 239.406C159.46 238.909 159.477 238.412 159.503 237.915C159.537 236.913 159.571 235.885 159.631 234.831C159.631 234.805 159.631 234.788 159.631 234.763L159.957 229.939C160.017 229.065 160.077 228.2 160.137 227.326C160.308 224.782 160.479 222.143 160.77 219.427C161.447 211.863 162.339 204.264 163.418 196.827C165.406 182.931 168.37 167.699 171.54 155.054C171.728 154.334 171.899 153.64 172.07 152.972C172.585 150.95 173.073 149.04 173.57 147.275L174.444 144.079C174.444 144.079 174.444 144.045 174.461 144.028L175.258 141.269C175.506 140.421 175.72 139.659 175.943 138.956L176.928 135.786C177.493 134.03 179.31 133.113 180.981 133.73L237.943 154.788C238.749 155.088 239.417 155.705 239.794 156.519C240.171 157.324 240.231 158.258 239.957 159.106L239.88 159.337C239.88 159.337 239.879 159.363 239.871 159.372C239.828 159.5 239.76 159.714 239.674 160.014L239.297 161.239C239.16 161.685 238.997 162.225 238.809 162.884L238.192 165.009L237.489 167.57C237.489 167.57 237.489 167.588 237.489 167.605C237.138 168.838 236.778 170.261 236.401 171.768C236.23 172.437 236.058 173.122 235.879 173.824C233.283 184.199 230.833 196.81 229.171 208.401C228.28 214.57 227.534 220.875 226.978 227.164C226.978 227.189 226.978 227.215 226.978 227.232C226.746 229.314 226.618 231.387 226.481 233.392C226.429 234.223 226.378 235.037 226.318 235.833L226.043 239.826C226.009 240.622 225.975 241.402 225.949 242.165C225.932 242.627 225.915 243.081 225.898 243.535L225.649 250.089C225.632 251.297 225.632 252.419 225.632 253.413C225.632 254.013 225.632 254.578 225.632 255.101L225.615 259.513C225.615 261.201 224.424 262.58 222.882 262.794L222.84 262.76Z"}),r.createElement("path",{d:"M192.169 254.055C192.126 254.055 192.075 254.064 192.023 254.064C191.235 254.09 190.575 253.439 190.541 252.608C190.524 252.256 190.19 243.869 191.715 228.328C193.12 214.03 196.427 190.77 204.266 161.111C204.48 160.314 205.259 159.86 206.013 160.091C206.767 160.322 207.213 161.162 207.007 161.95C199.228 191.404 195.938 214.492 194.542 228.671C193.043 243.989 193.377 252.428 193.377 252.505C193.411 253.284 192.88 253.936 192.16 254.038L192.169 254.055Z",fill:"#030303"}),r.createElement("path",{d:"M173.45 228.782C172.918 228.859 172.361 228.602 172.044 228.088C171.616 227.386 171.813 226.46 172.473 226.024C179.087 221.663 188.185 218.724 199.519 217.302C207.915 216.248 214.297 216.463 214.563 216.471C215.351 216.497 215.977 217.191 215.959 218.022C215.942 218.853 215.3 219.495 214.512 219.47C214.255 219.461 188.973 218.69 174.015 228.568C173.835 228.688 173.647 228.756 173.45 228.782Z",fill:"#030303"}),r.createElement("path",{d:"M215.146 213.508C214.889 213.542 214.615 213.508 214.358 213.379C214.153 213.276 193.283 203.124 175.42 206.885C174.658 207.048 173.895 206.517 173.732 205.703C173.57 204.889 174.058 204.101 174.829 203.938C193.634 199.98 214.658 210.218 215.54 210.655C216.251 211.006 216.568 211.906 216.251 212.651C216.046 213.131 215.626 213.431 215.155 213.499L215.146 213.508Z",fill:"#030303"})));l.displayName="ApplyIllustration";const o=(0,r.forwardRef)((e,t)=>r.createElement("svg",(0,a.A)({width:"362",height:"265",viewBox:"0 0 362 265",fill:"none",xmlns:"http://www.w3.org/2000/svg",ref:t},e),r.createElement("path",{d:"M38.8095 132.88H16.3879C15.6275 132.88 15.0073 133.5 15.0073 134.26C15.0073 135.021 15.6201 135.634 16.3879 135.634H38.8095C39.57 135.634 40.1901 135.021 40.1901 134.26C40.1901 133.5 39.57 132.88 38.8095 132.88Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M59.577 59.7237C59.2743 59.7237 58.9716 59.6055 58.7427 59.3767C58.285 58.9189 58.285 58.1659 58.7427 57.7082L65.0919 51.3589C65.5497 50.9012 66.3027 50.9012 66.7604 51.3589C67.2182 51.8167 67.2182 52.5697 66.7604 53.0274L60.4112 59.3767C60.1824 59.6055 59.8797 59.7237 59.577 59.7237Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M65.9262 59.7237C65.6235 59.7237 65.3208 59.6055 65.0919 59.3767L58.7427 53.0274C58.285 52.5623 58.285 51.8167 58.7427 51.3589C59.2005 50.9012 59.9535 50.9012 60.4112 51.3589L66.7604 57.7082C67.2182 58.1659 67.2182 58.9189 66.7604 59.3767C66.5316 59.6055 66.2289 59.7237 65.9262 59.7237Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M296.603 63.3559L286.378 53.4482L289.973 49.7346L296.574 56.1355L311.339 41.584L314.972 45.268L296.603 63.3559Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M272.52 258.838L262.369 251.721C261.837 251.344 261.121 251.344 260.59 251.721L251.331 258.21L242.073 251.721C241.542 251.344 240.826 251.344 240.294 251.721L231.036 258.21L221.778 251.721C221.246 251.344 220.53 251.344 219.999 251.721L210.741 258.21L201.483 251.721C200.951 251.344 200.235 251.344 199.703 251.721L190.445 258.21L181.187 251.721C180.656 251.344 179.94 251.344 179.408 251.721L169.257 258.838C168.555 259.325 168.385 260.292 168.88 260.994C169.183 261.422 169.663 261.651 170.15 261.651C170.46 261.651 170.77 261.562 171.036 261.37L180.294 254.873L189.552 261.37C190.084 261.747 190.8 261.747 191.331 261.37L200.589 254.873L209.847 261.37C210.379 261.747 211.095 261.747 211.627 261.37L220.885 254.873L230.143 261.37C230.674 261.747 231.39 261.747 231.922 261.37L241.18 254.873L250.438 261.37C250.97 261.747 251.686 261.747 252.217 261.37L261.475 254.873L270.734 261.37C271.435 261.857 272.402 261.695 272.897 260.994C273.391 260.292 273.222 259.325 272.52 258.838Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M329.087 191.153C329.596 190.946 329.966 190.459 330.098 189.802C330.231 189.137 330.15 188.347 329.81 187.624C329.81 187.624 329.67 187.328 329.412 186.775C329.279 186.494 329.124 186.154 328.932 185.756C328.74 185.357 328.504 184.899 328.245 184.39C327.204 182.345 325.632 179.444 323.402 176.151C321.18 172.858 318.315 169.167 314.868 165.623C313.147 163.851 311.302 162.094 309.345 160.433C307.389 158.772 305.344 157.184 303.247 155.708C299.054 152.747 294.668 150.267 290.49 148.258C286.311 146.25 282.346 144.737 278.943 143.585C275.532 142.448 272.675 141.673 270.667 141.171C269.663 140.927 268.873 140.735 268.334 140.617C267.795 140.492 267.507 140.433 267.507 140.433C267.367 140.403 267.234 140.381 267.093 140.366L266.569 140.255C264.214 139.753 261.925 140.152 260.205 141.149C258.478 142.146 257.319 143.748 257.068 145.645C256.942 146.627 257.06 147.601 257.37 148.509L257.164 148.48C255.023 148.185 252.904 148.709 251.294 149.927C249.722 151.108 248.836 152.799 248.747 154.622C248.673 156.077 249.094 157.45 249.803 158.617C250.519 159.783 251.545 160.75 252.756 161.4C252.114 162.315 251.708 163.408 251.589 164.582C251.442 166.118 251.781 167.587 252.431 168.82C253.088 170.06 254.048 171.064 255.222 171.699C254.653 172.563 254.269 173.574 254.114 174.682C253.841 176.572 254.247 178.38 255.037 179.783C255.835 181.193 257.031 182.197 258.492 182.53C258.492 182.53 259.157 182.677 260.139 182.921C261.121 183.164 262.42 183.519 263.69 183.91C264.96 184.301 266.2 184.73 267.116 185.069C267.573 185.239 267.95 185.387 268.216 185.49C268.474 185.601 268.629 185.66 268.629 185.66C268.725 185.697 268.821 185.726 268.917 185.741C268.917 185.741 269.042 185.793 269.271 185.881C269.5 185.977 269.825 186.118 270.246 186.295C271.073 186.664 272.254 187.203 273.583 187.904C274.912 188.606 276.418 189.477 277.909 190.488C279.393 191.507 280.885 192.644 282.228 193.877C283.579 195.102 284.812 196.402 285.868 197.694C286.916 198.986 287.795 200.263 288.504 201.4C289.205 202.537 289.722 203.548 290.076 204.257C290.261 204.612 290.379 204.907 290.475 205.099C290.563 205.291 293.472 211.227 293.472 211.227C293.782 211.928 297.06 209.418 298.116 208.99L329.065 191.167L329.087 191.153Z",fill:"white"}),r.createElement("path",{d:"M294.07 213.375C293.015 213.508 292.055 213.013 291.627 212.097C291.132 211.093 288.843 206.413 288.637 205.984C288.592 205.896 288.548 205.792 288.496 205.674C288.43 205.519 288.356 205.364 288.267 205.194L288.253 205.165C287.861 204.397 287.396 203.489 286.761 202.463C286.008 201.245 285.174 200.071 284.281 198.971C283.277 197.745 282.125 196.534 280.855 195.375C279.674 194.297 278.293 193.22 276.758 192.171C275.48 191.315 274.092 190.481 272.638 189.713C271.375 189.048 270.268 188.539 269.434 188.17L268.334 187.705C268.171 187.668 268.016 187.616 267.869 187.557L267.47 187.394L266.392 186.981C265.381 186.605 264.177 186.198 263.099 185.866C261.66 185.423 260.323 185.076 259.652 184.906C259.12 184.774 258.684 184.67 258.404 184.611L258.049 184.53C256.071 184.087 254.365 182.758 253.251 180.787C252.173 178.882 251.759 176.601 252.077 174.371C252.18 173.662 252.35 172.983 252.594 172.334C251.804 171.625 251.132 170.754 250.608 169.772C249.722 168.096 249.353 166.228 249.537 164.367C249.618 163.57 249.803 162.788 250.083 162.057C249.286 161.385 248.599 160.58 248.046 159.687C247.064 158.085 246.591 156.291 246.68 154.504C246.798 152.06 248.031 149.779 250.047 148.258C251.434 147.21 253.14 146.553 254.941 146.368C254.941 146.029 254.971 145.696 255.015 145.357C255.34 142.876 256.853 140.683 259.164 139.347C260.316 138.675 261.674 138.225 263.085 138.048C264.377 137.885 265.691 137.944 266.997 138.218L267.418 138.306C267.588 138.328 267.765 138.358 267.935 138.395L268.777 138.587C269.308 138.705 270.113 138.897 271.147 139.148C273.923 139.842 276.758 140.669 279.578 141.606C283.816 143.038 287.669 144.596 291.368 146.376C296.064 148.635 300.456 151.197 304.421 153.995C306.577 155.508 308.673 157.14 310.667 158.83C312.535 160.41 314.447 162.204 316.337 164.153C319.504 167.409 322.457 171.049 325.108 174.962C326.931 177.664 328.563 180.432 330.084 183.423L330.305 183.858C330.482 184.212 330.645 184.537 330.792 184.833L331.678 186.723C332.188 187.823 332.35 189.048 332.121 190.185C331.856 191.477 331.088 192.481 330.017 192.976L299.039 210.813L298.906 210.864C298.699 210.953 298.027 211.374 297.585 211.647C296.019 212.629 295.001 213.234 294.063 213.352L294.07 213.375ZM291.929 203.29C292.077 203.563 292.18 203.799 292.261 203.976C292.291 204.043 292.321 204.102 292.35 204.153L292.372 204.19C292.446 204.338 293.546 206.59 294.565 208.679C294.875 208.495 295.178 208.303 295.407 208.162C296.211 207.66 296.75 207.328 297.215 207.114L328.09 189.336C328.12 189.137 328.105 188.812 327.943 188.48L327.064 186.612C326.946 186.353 326.791 186.058 326.629 185.741L326.407 185.298C324.967 182.463 323.424 179.842 321.697 177.28C319.179 173.566 316.389 170.119 313.391 167.04C311.59 165.187 309.781 163.482 308.009 161.983C306.112 160.366 304.111 158.816 302.058 157.376C298.278 154.703 294.085 152.26 289.596 150.096C286.053 148.391 282.354 146.892 278.286 145.519C275.569 144.611 272.837 143.821 270.172 143.157C269.175 142.913 268.408 142.728 267.898 142.618L267.064 142.433C267.027 142.426 266.968 142.418 266.909 142.411H266.791L266.148 142.263C265.299 142.086 264.45 142.042 263.624 142.153C262.76 142.263 261.94 142.529 261.261 142.928C260.05 143.629 259.297 144.685 259.135 145.903C259.054 146.531 259.12 147.18 259.341 147.823L260.442 151.019L256.89 150.517C256.337 150.436 255.768 150.436 255.222 150.503C254.225 150.628 253.31 150.997 252.564 151.558C251.508 152.356 250.896 153.47 250.836 154.703C250.792 155.656 251.051 156.63 251.597 157.516C252.121 158.38 252.874 159.081 253.76 159.554L255.82 160.654L254.484 162.566C254.041 163.201 253.76 163.961 253.686 164.766C253.583 165.822 253.797 166.885 254.299 167.845C254.772 168.731 255.443 169.432 256.248 169.868L258.234 170.938L257.001 172.821C256.595 173.448 256.322 174.172 256.211 174.969C256.019 176.298 256.263 177.649 256.89 178.757C257.26 179.414 257.924 180.241 258.958 180.492C259.268 180.551 259.762 180.669 260.685 180.898C261.401 181.075 262.826 181.444 264.354 181.916C265.506 182.271 266.791 182.706 267.891 183.112L269.367 183.681L269.515 183.703L270.519 184.117L271.139 184.382C272.025 184.781 273.221 185.327 274.602 186.058C276.196 186.9 277.717 187.808 279.12 188.76C280.825 189.927 282.354 191.123 283.675 192.326C285.1 193.618 286.392 194.977 287.522 196.357C288.526 197.59 289.463 198.912 290.312 200.285C291.088 201.54 291.656 202.67 291.966 203.282L291.929 203.29Z",fill:"#030303"}),r.createElement("path",{d:"M33.553 191.153C33.0436 190.946 32.6818 190.459 32.5416 189.802C32.4087 189.137 32.4898 188.347 32.8295 187.624C32.8295 187.624 32.9698 187.328 33.2282 186.775C33.3611 186.494 33.5161 186.154 33.708 185.756C33.9 185.357 34.1362 184.899 34.3946 184.39C35.4356 182.345 37.0082 179.444 39.2378 176.151C41.46 172.858 44.3245 169.167 47.7723 165.623C49.4925 163.851 51.3382 162.094 53.2947 160.433C55.2437 158.772 57.2962 157.184 59.3929 155.708C63.5863 152.747 67.9717 150.267 72.1504 148.258C76.3291 146.25 80.2936 144.737 83.6971 143.585C87.108 142.448 89.9651 141.673 91.9733 141.171C92.9773 140.927 93.7673 140.735 94.3062 140.617C94.8452 140.492 95.1331 140.433 95.1331 140.433C95.2734 140.403 95.4063 140.381 95.5465 140.366L96.0707 140.255C98.4185 139.753 100.707 140.152 102.427 141.149C104.155 142.146 105.314 143.748 105.565 145.645C105.691 146.627 105.572 147.601 105.262 148.509L105.469 148.48C107.61 148.185 109.729 148.709 111.338 149.927C112.904 151.108 113.797 152.799 113.885 154.622C113.959 156.077 113.538 157.45 112.83 158.617C112.114 159.783 111.087 160.75 109.877 161.4C110.519 162.315 110.925 163.408 111.043 164.582C111.191 166.118 110.851 167.587 110.201 168.82C109.544 170.06 108.585 171.064 107.411 171.699C107.979 172.563 108.363 173.574 108.518 174.682C108.791 176.572 108.385 178.38 107.595 179.783C106.798 181.193 105.602 182.197 104.14 182.53C104.14 182.53 103.476 182.677 102.494 182.921C101.512 183.164 100.213 183.519 98.9427 183.91C97.6728 184.301 96.4325 184.73 95.517 185.069C95.0667 185.239 94.6902 185.387 94.417 185.49C94.1586 185.601 94.0036 185.66 94.0036 185.66C93.9076 185.697 93.8116 185.726 93.7156 185.741C93.7156 185.741 93.5901 185.793 93.3686 185.881C93.1397 185.977 92.8149 186.118 92.3941 186.295C91.5672 186.664 90.386 187.203 89.0571 187.904C87.7281 188.606 86.2221 189.477 84.7307 190.488C83.2468 191.507 81.7554 192.644 80.4118 193.877C79.0607 195.102 77.8278 196.402 76.772 197.694C75.7237 198.986 74.8451 200.263 74.1364 201.4C73.435 202.537 72.9182 203.548 72.5638 204.257C72.3792 204.612 72.2611 204.907 72.1652 205.099C72.0766 205.291 69.1677 211.227 69.1677 211.227C68.8577 211.928 65.5797 209.418 64.524 208.99L33.5751 191.167L33.553 191.153Z",fill:"white"}),r.createElement("path",{d:"M65.0479 211.67C64.605 211.396 63.9405 210.976 63.7264 210.887L63.5936 210.835L32.6152 192.998C31.5447 192.504 30.7843 191.492 30.5111 190.208C30.2823 189.071 30.4373 187.845 30.9541 186.745L31.84 184.855C31.9803 184.56 32.1501 184.235 32.3273 183.881L32.5488 183.445C34.0696 180.448 35.7013 177.679 37.5248 174.984C40.1752 171.071 43.1284 167.432 46.2882 164.176C48.1782 162.227 50.0904 160.433 51.9582 158.853C53.9516 157.162 56.0483 155.531 58.2041 154.017C62.1686 151.212 66.5615 148.65 71.2569 146.398C74.9557 144.619 78.8095 143.061 83.0473 141.629C85.8675 140.691 88.7025 139.864 91.4784 139.17C92.512 138.912 93.3168 138.727 93.8483 138.609L94.6974 138.417C94.8672 138.38 95.0443 138.351 95.2141 138.329L95.635 138.24C96.9417 137.967 98.2559 137.908 99.5479 138.07C100.958 138.247 102.309 138.698 103.468 139.37C105.772 140.706 107.285 142.899 107.617 145.379C107.662 145.719 107.684 146.051 107.691 146.391C109.493 146.575 111.198 147.232 112.586 148.281C114.601 149.801 115.834 152.075 115.953 154.526C116.041 156.313 115.569 158.107 114.587 159.709C114.033 160.61 113.346 161.407 112.549 162.079C112.83 162.817 113.014 163.593 113.095 164.39C113.28 166.25 112.911 168.118 112.025 169.794C111.501 170.783 110.829 171.647 110.039 172.356C110.283 172.998 110.46 173.678 110.556 174.394C110.881 176.623 110.46 178.905 109.382 180.809C108.267 182.773 106.562 184.102 104.583 184.552L104.229 184.634C103.948 184.7 103.512 184.796 102.981 184.929C102.309 185.099 100.973 185.446 99.5331 185.889C98.4552 186.221 97.2518 186.627 96.2404 187.003L95.1625 187.417L94.7638 187.579C94.6161 187.638 94.4611 187.69 94.2987 187.727L93.1987 188.192C92.3718 188.561 91.257 189.071 89.9945 189.735C88.5327 190.503 87.1447 191.337 85.8749 192.194C84.3393 193.249 82.9587 194.327 81.7774 195.398C80.5076 196.557 79.3485 197.768 78.3518 198.993C77.4659 200.086 76.6316 201.26 75.8712 202.485C75.2363 203.519 74.7638 204.42 74.3798 205.187L74.3651 205.217C74.2765 205.387 74.2026 205.542 74.1362 205.697C74.0845 205.815 74.0328 205.918 73.9959 206.007C73.7892 206.442 71.5005 211.116 71.0059 212.12C70.5777 213.028 69.6179 213.53 68.5622 213.397C67.6246 213.279 66.6131 212.674 65.0406 211.692L65.0479 211.67ZM72.3643 200.293C73.2134 198.919 74.151 197.598 75.155 196.365C76.292 194.984 77.584 193.626 79.0015 192.334C80.323 191.13 81.8513 189.934 83.5567 188.768C84.9594 187.816 86.4877 186.908 88.075 186.066C89.4556 185.335 90.6442 184.789 91.5375 184.39L92.1577 184.124L93.1617 183.711L93.3094 183.689L94.786 183.12C95.886 182.714 97.1706 182.278 98.3223 181.924C99.8506 181.452 101.275 181.082 101.992 180.905C102.914 180.676 103.409 180.558 103.719 180.499C104.76 180.248 105.417 179.421 105.786 178.764C106.414 177.649 106.658 176.306 106.466 174.977C106.355 174.18 106.082 173.456 105.676 172.828L104.443 170.946L106.429 169.875C107.233 169.447 107.905 168.746 108.378 167.852C108.88 166.893 109.094 165.83 108.991 164.774C108.917 163.969 108.636 163.209 108.193 162.574L106.857 160.662L108.917 159.562C109.803 159.089 110.548 158.38 111.08 157.524C111.626 156.638 111.885 155.663 111.84 154.711C111.781 153.478 111.168 152.356 110.113 151.566C109.367 151.005 108.444 150.636 107.455 150.51C106.909 150.436 106.347 150.444 105.786 150.525L102.235 151.027L103.335 147.83C103.557 147.181 103.623 146.538 103.542 145.911C103.38 144.693 102.627 143.637 101.416 142.935C100.729 142.537 99.917 142.271 99.0532 142.16C98.2263 142.057 97.3773 142.094 96.5283 142.271L95.886 142.411H95.7679C95.7088 142.426 95.6498 142.433 95.6128 142.448L94.7786 142.633C94.2692 142.743 93.5013 142.928 92.5047 143.172C89.8321 143.836 87.1078 144.633 84.3909 145.534C80.323 146.907 76.6242 148.399 73.0805 150.112C68.5917 152.267 64.3983 154.711 60.6183 157.391C58.5658 158.838 56.5651 160.388 54.6677 161.998C52.8958 163.497 51.0871 165.195 49.293 167.055C46.2882 170.134 43.4975 173.582 40.98 177.295C39.2524 179.85 37.7094 182.478 36.2697 185.313L36.0482 185.756C35.8858 186.081 35.7308 186.369 35.6126 186.627L34.7341 188.495C34.579 188.827 34.5569 189.152 34.5938 189.351L65.4614 207.129C65.9265 207.336 66.4728 207.675 67.2702 208.177C67.4991 208.318 67.8018 208.51 68.1118 208.694C69.1307 206.598 70.2307 204.353 70.3045 204.205L70.3193 204.169C70.3488 204.117 70.371 204.058 70.4079 203.991C70.4891 203.814 70.5925 203.578 70.7327 203.305C71.0428 202.692 71.6187 201.57 72.3939 200.307L72.3643 200.293Z",fill:"#030303"}),r.createElement("path",{d:"M275.237 138.513C276.041 133.389 276.41 128.288 276.396 123.26L303.897 117.191L298.411 84.0941L269.264 87.3573C265.454 78.0402 260.205 69.3876 253.76 61.7168L271.117 39.1475L245.639 17.3091L225.307 38.6455C216.661 34.0312 207.174 30.6647 197.045 28.8263L195.834 0.432012L162.279 0.0776367L160.448 29.166C150.408 31.1962 140.862 34.799 132.113 39.7455L113.287 19.1548L87.3586 40.4543L104.265 63.4001C97.9012 71.3219 92.748 80.3215 89.1157 90.1554L62.0797 86.5674L55.9077 119.546L83.1651 126.154C83.4457 136.741 85.4759 146.996 89.0123 156.623L66.192 171.13L82.6631 200.359L107.831 187.874C114.697 195.53 122.811 202.116 131.906 207.291L123.697 233.257L155.096 245.062L166.48 219.03C176.956 220.492 187.278 220.219 197.156 218.425L207.669 243.888L239.319 232.747L231.228 205.209C239.858 199.805 247.61 193.042 254.166 185.18L278.847 198.063L295.923 169.181L271.789 153.131C273.295 148.428 274.461 143.548 275.244 138.513H275.237Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M159.068 144.5C158.042 144.5 157.016 144.116 156.226 143.341L138.522 126.006C137.747 125.246 137.304 124.205 137.304 123.119C137.304 122.034 137.732 120.993 138.5 120.225L156.063 102.75C157.651 101.17 160.22 101.178 161.807 102.765C163.387 104.352 163.38 106.929 161.793 108.509L147.145 123.082L161.911 137.538C163.513 139.103 163.542 141.68 161.97 143.282C161.172 144.094 160.124 144.5 159.068 144.5Z",fill:"#030303"}),r.createElement("path",{d:"M200.198 144.5C199.157 144.5 198.116 144.101 197.318 143.304C195.738 141.717 195.746 139.14 197.333 137.56L211.981 122.987L197.215 108.531C195.613 106.966 195.583 104.389 197.156 102.787C198.728 101.185 201.298 101.156 202.9 102.728L220.604 120.063C221.379 120.823 221.822 121.864 221.822 122.95C221.822 124.035 221.394 125.076 220.626 125.844L203.062 143.319C202.272 144.109 201.231 144.5 200.198 144.5Z",fill:"#030303"}),r.createElement("path",{d:"M171.973 159C171.663 159 171.345 158.963 171.028 158.889C168.843 158.372 167.499 156.18 168.016 154.002L183.202 90.1921C183.719 88.0068 185.912 86.6631 188.09 87.1799C190.268 87.6967 191.619 89.8894 191.102 92.0673L175.915 155.877C175.472 157.745 173.804 159 171.966 159H171.973Z",fill:"#030303"}),r.createElement("path",{d:"M179.563 187.476C144.029 187.476 115.118 158.565 115.118 123.031C115.118 87.4975 144.029 58.5864 179.563 58.5864C215.096 58.5864 244.007 87.4975 244.007 123.031C244.007 158.565 215.096 187.476 179.563 187.476ZM179.563 62.2852C146.067 62.2852 118.81 89.5352 118.81 123.038C118.81 156.542 146.06 183.792 179.563 183.792C213.066 183.792 240.316 156.542 240.316 123.038C240.316 89.5352 213.066 62.2852 179.563 62.2852Z",fill:"#030303"}),r.createElement("path",{d:"M268.29 161.975C279.254 159.067 286.814 157.959 298.36 159.93L303.521 199.273C293.805 195.597 289.877 183.356 292.063 172.363C283.838 171.042 279.039 172.001 271.45 174.216C268.519 175.176 265.647 174.009 264.355 170.141C262.952 165.947 265.3 162.913 268.297 161.968L268.29 161.975Z",fill:"white"}),r.createElement("path",{d:"M303.764 201.2C304.451 201.112 305.071 200.661 305.337 199.96C305.713 198.956 305.211 197.841 304.207 197.464C295.052 194.002 292.092 182.145 293.96 172.739C294.063 172.223 293.952 171.684 293.65 171.255C293.347 170.82 292.882 170.532 292.365 170.451C284.126 169.122 279.083 169.963 270.896 172.363C268.652 173.101 267.042 172.112 266.186 169.535C265.728 168.169 265.765 166.951 266.289 165.925C266.776 164.965 267.707 164.205 268.829 163.843C279.667 160.964 286.806 159.938 298.035 161.842C299.098 162.02 300.088 161.311 300.272 160.255C300.457 159.199 299.741 158.195 298.685 158.018C286.806 155.995 278.965 157.132 267.788 160.1C267.758 160.107 267.729 160.115 267.707 160.122C265.58 160.794 263.801 162.263 262.834 164.153C261.83 166.117 261.719 168.398 262.509 170.753C264.052 175.368 267.795 177.45 272.048 176.054C279.061 174.002 283.395 173.197 289.825 173.994C289.117 179.273 289.707 184.626 291.523 189.269C293.768 194.976 297.784 199.177 302.834 201.082C303.137 201.2 303.454 201.23 303.764 201.193V201.2Z",fill:"#030303"}),r.createElement("path",{d:"M304.813 261.769C304.813 261.769 345.537 257.812 359.106 256.491C355.208 214.003 330.83 182.183 330.83 182.183L286.297 213.678C286.297 213.678 303.026 237.952 304.813 261.769Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M348.009 239.163C348.474 239.163 348.917 238.883 349.109 238.425C349.375 237.805 349.095 237.081 348.474 236.816C342.265 234.136 334.13 232.917 324.296 233.205C317.009 233.419 311.597 234.394 311.376 234.438C310.711 234.556 310.268 235.199 310.394 235.863C310.519 236.528 311.154 236.971 311.819 236.845C312.033 236.808 333.465 232.991 347.507 239.067C347.67 239.134 347.847 239.171 348.017 239.163H348.009Z",fill:"#030303"}),r.createElement("path",{d:"M310.49 232.12C310.719 232.12 310.94 232.046 311.147 231.913C311.31 231.802 327.744 220.987 343.454 221.762C344.126 221.799 344.702 221.275 344.739 220.603C344.769 219.923 344.252 219.355 343.58 219.318C327.042 218.506 310.49 229.41 309.796 229.876C309.235 230.252 309.08 231.012 309.456 231.574C309.7 231.928 310.099 232.127 310.497 232.12H310.49Z",fill:"#030303"}),r.createElement("path",{d:"M332.535 252.282C331.841 252.348 331.213 251.846 331.125 251.152C328.127 226.427 315.104 206.811 314.971 206.619C314.573 206.029 314.735 205.224 315.326 204.825C315.916 204.427 316.721 204.589 317.12 205.18C317.253 205.379 330.623 225.512 333.694 250.842C333.783 251.551 333.273 252.193 332.565 252.282C332.557 252.282 332.542 252.282 332.535 252.282Z",fill:"#030303"}),r.createElement("path",{d:"M305.071 264.405C305.071 264.405 305.027 264.405 305.004 264.405C303.602 264.508 302.384 263.467 302.243 262.079C302.243 262.057 302.243 262.035 302.243 262.013V261.954C300.523 239.141 284.332 215.383 284.17 215.14C283.365 213.98 283.646 212.386 284.805 211.566L329.338 180.071C330.475 179.266 332.04 179.503 332.882 180.61C333.14 180.942 339.202 188.916 345.824 202.249C351.93 214.549 359.63 233.907 361.682 256.247C361.815 257.665 360.774 258.92 359.357 259.06H359.342C357.917 259.193 356.662 258.144 356.529 256.727C354.558 235.228 347.131 216.55 341.247 204.671C336.721 195.538 332.395 188.908 330.224 185.771L289.818 214.342C293.967 220.876 305.853 241.179 307.389 261.57V261.644C307.492 263.047 306.451 264.265 305.063 264.405H305.071Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M94.3504 161.975C83.3869 159.067 75.8269 157.959 64.2802 159.93L59.1196 199.273C68.8354 195.597 72.7631 183.356 70.5851 172.363C78.8022 171.042 83.6084 172.001 91.1979 174.216C94.1289 175.176 97.0009 174.009 98.2929 170.141C99.6956 165.947 97.3479 162.913 94.3504 161.968V161.975Z",fill:"white"}),r.createElement("path",{d:"M58.8758 201.2C58.1892 201.112 57.569 200.661 57.3032 199.96C56.9267 198.956 57.4288 197.841 58.4328 197.464C67.5875 194.002 70.548 182.145 68.6801 172.739C68.5768 172.223 68.6876 171.684 68.9902 171.255C69.2856 170.82 69.7507 170.532 70.2749 170.451C78.5141 169.122 83.5566 169.963 91.7441 172.363C93.9885 173.101 95.5979 172.112 96.4617 169.535C96.9194 168.169 96.8826 166.951 96.3584 165.925C95.8711 164.965 94.9409 164.205 93.8187 163.843C82.9807 160.964 75.8415 159.938 64.6122 161.842C63.5491 162.02 62.5598 161.311 62.3752 160.255C62.1907 159.199 62.9068 158.195 63.9626 158.018C75.8415 155.995 83.682 157.132 94.8522 160.1C94.8818 160.107 94.9113 160.115 94.9334 160.122C97.0671 160.794 98.839 162.263 99.8061 164.153C100.81 166.117 100.921 168.398 100.131 170.753C98.588 175.368 94.8449 177.45 90.5924 176.054C83.5787 174.002 79.245 173.197 72.8145 173.994C73.5233 179.273 72.9401 184.626 71.1165 189.269C68.8721 194.976 64.8559 199.177 59.806 201.082C59.5033 201.2 59.1859 201.23 58.8832 201.193L58.8758 201.2Z",fill:"#030303"}),r.createElement("path",{d:"M57.8275 261.769C57.8275 261.769 17.1112 257.812 3.53418 256.491C7.43231 214.003 31.8104 182.183 31.8104 182.183L76.3436 213.678C76.3436 213.678 59.6141 237.952 57.8201 261.769H57.8275Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M14.6304 239.163C14.1653 239.163 13.7223 238.883 13.5304 238.425C13.2646 237.805 13.5451 237.081 14.1653 236.816C20.3742 234.136 28.5101 232.917 38.344 233.205C45.6308 233.419 51.0351 234.394 51.2639 234.438C51.9284 234.556 52.3714 235.199 52.2459 235.863C52.1277 236.528 51.4854 236.971 50.8209 236.845C50.6068 236.808 29.1745 232.991 15.1324 239.067C14.97 239.134 14.7928 239.171 14.623 239.163H14.6304Z",fill:"#030303"}),r.createElement("path",{d:"M52.15 232.12C51.9285 232.12 51.6997 232.046 51.4929 231.913C51.3305 231.802 34.8964 220.987 19.1857 221.762C18.5139 221.799 17.938 221.275 17.9011 220.603C17.8716 219.923 18.3884 219.355 19.0602 219.318C35.5977 218.506 52.15 229.41 52.844 229.876C53.4051 230.252 53.5601 231.012 53.1836 231.574C52.94 231.928 52.5413 232.127 52.1426 232.12H52.15Z",fill:"#030303"}),r.createElement("path",{d:"M30.1051 252.282C30.7991 252.348 31.4266 251.846 31.5152 251.152C34.5127 226.427 47.536 206.811 47.6688 206.619C48.0675 206.029 47.9051 205.224 47.3144 204.825C46.7238 204.427 45.9191 204.589 45.5204 205.18C45.3875 205.379 32.0172 225.512 28.9534 250.842C28.8648 251.551 29.3742 252.193 30.083 252.282C30.0903 252.282 30.1051 252.282 30.1125 252.282H30.1051Z",fill:"#030303"}),r.createElement("path",{d:"M57.5692 264.405C57.5692 264.405 57.6135 264.405 57.6357 264.405C59.0384 264.508 60.2565 263.467 60.3968 262.079C60.3968 262.057 60.3968 262.035 60.3968 262.013V261.954C62.117 239.141 78.3075 215.383 78.47 215.14C79.2747 213.98 78.9941 212.386 77.835 211.566L33.3019 180.071C32.1649 179.266 30.5998 179.503 29.7581 180.61C29.4997 180.942 23.431 188.916 16.816 202.249C10.7104 214.549 3.01015 233.907 0.957721 256.247C0.82483 257.665 1.86583 258.92 3.28333 259.06H3.29806C4.72295 259.193 5.97802 258.144 6.11092 256.727C8.08213 235.228 15.5093 216.55 21.3934 204.671C25.919 195.538 30.2454 188.908 32.4159 185.771L72.8221 214.342C68.673 220.876 56.7866 241.179 55.251 261.57V261.644C55.1476 263.047 56.1886 264.265 57.5766 264.405H57.5692Z",fill:"#D9D9D9"}),r.createElement("path",{d:"M28.9755 145.467V123.046C28.9755 122.285 28.3553 121.665 27.5949 121.665C26.8344 121.665 26.2217 122.285 26.2217 123.046V145.467C26.2217 146.228 26.8344 146.84 27.5949 146.84C28.3553 146.84 28.9755 146.228 28.9755 145.467Z",fill:"#D9D9D9"})));o.displayName="ErrorIllustration"},71091:(e,t,n)=>{n.d(t,{B:()=>a});const a=e=>e.features?.spontaneousApplication?.active},71804:(e,t,n)=>{n.d(t,{Ay:()=>_,D6:()=>M,J_:()=>f,Kd:()=>x,bd:()=>y});var a=n(14041),r=n(39067),i=n.n(r),l=n(35772),o=n(68153),s=n(47304),A=n(19555),c=n(2345),d=n(23099),p=n(61631),m=n(95600),u=n(45728),g=n(97519),C=n(33515);const f=c.Ay.form`
  position: relative;
  display: flex;
  justify-content: center;
  padding: ${e=>{let{theme:t}=e;return t.template===u.tC.BENTO_2024?"3vh 2vw":"12px"}};
  cursor: pointer;
  transition: all 300ms ease;
  text-align: center;
  border: dashed 2px #d3d6dd;
  border-radius: ${e=>{let{theme:t}=e;return t.template===u.tC.BENTO_2024?"8px":"10px"}};
  width: 100%;

  &.highlight,
  &:hover {
    border-color: ${e=>{let{theme:t}=e;return t.template===u.tC.BENTO_2024?(0,p.x6)(t.palette,p.Fl,p.Xs):"var(--dropzone-border-hover-color)"}};
    background-color: ${e=>{let{theme:t}=e;return t.template===u.tC.BENTO_2024?`${(0,p.x6)(t.palette,p.Fl,p.Xs)}1A`:"#f0f0f0"}};
  }
`,h=c.Ay.input`
  cursor: pointer;
  opacity: 0;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
`,y=c.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0;
`,E=c.Ay.div`
  display: flex;
  flex-direction: row;

  > * {
    margin: 0 5px;
  }

  @media (min-width: 1024px) and (max-height: 830px) {
    display: none;
  }
`,M=c.Ay.div`
  margin-top: ${e=>{let{theme:t}=e;return t.template===u.tC.BENTO_2024?"2vh":"10px"}};
  margin-bottom: 12px;
  font-size: 1.25rem;
  font-weight: 600;
  color: #000000de;

  .lighter {
    font-size: 14px;
  }
`,x=c.Ay.div`
  font-size: 14px;
`,w=c.Ay.p`
  font-size: 12px;
  color: ${e=>{let{theme:t}=e;return t.palette.error.main}};
`,D=c.Ay.div``,b=e=>{let{dropArea:t,highlight:n,highlightDropArea:r,unhighlightDropArea:i,onChange:o,iconColor:A,fileSizeError:c,maxSize:d}=e;return a.createElement(f,{ref:t,action:"#",id:"dropzone-area",className:n?"highlight":"",onMouseEnter:r,onMouseLeave:i},a.createElement(h,{"data-testid":"cvc-resume-upload-input",id:"widget-file-upload",type:"file",onChange:o}),a.createElement(y,null,a.createElement(E,null,a.createElement(l.Ay,{height:"36px",color:A})),a.createElement(D,null,a.createElement(M,{dangerouslySetInnerHTML:{__html:g.A.sanitize(s.Ay.t("widget.file_input.main_text"),{USE_PROFILES:{html:!0}})}}),a.createElement(x,{dangerouslySetInnerHTML:{__html:g.A.sanitize(s.Ay.t("widget.file_input.sub_text"),{USE_PROFILES:{html:!0}})}})),c&&a.createElement(w,null,s.Ay.t("upload_zone.file_size_error",{maxSize:(0,C.M)(d)}))))},L=e=>{let{onFileChange:t}=e;const n=(0,c.DP)(),{config:r}=(0,o._r)(),i=(0,a.useRef)(null),[l,s]=(0,a.useState)(!1),[p,g]=(0,a.useState)(!1),C=e=>{e.preventDefault(),e.stopPropagation()},f=()=>s(!0),h=()=>s(!1),y=e=>{const n=e.dataTransfer.files;t(n)},E=r?.resumeMaxSizeKo&&1024*r.resumeMaxSizeKo||A.we;(0,a.useEffect)(()=>{const e=i.current;return["dragenter","dragover","dragleave","drop"].forEach(t=>{e?.addEventListener(t,C,!1)}),["dragenter","dragover"].forEach(t=>{e?.addEventListener(t,f,!1)}),["dragleave","drop"].forEach(t=>{e?.addEventListener(t,h,!1)}),e?.addEventListener("drop",e=>y(e),!1),()=>{["dragenter","dragover","dragleave","drop"].forEach(t=>{e?.removeEventListener(t,C,!1)}),["dragenter","dragover"].forEach(t=>{e?.removeEventListener(t,f,!1)}),["dragleave","drop"].forEach(t=>{e?.removeEventListener(t,h,!1)}),e?.removeEventListener("drop",e=>y(e),!1)}},[]);const M=r.template===u.tC.BENTO_2024?n.palette.primary.main:n.palette.secondary.main;return a.createElement(m.A,{p:2},a.createElement(b,{fileSizeError:p,onChange:e=>{const n=e.target.files,a=n?n[0]:null;a&&a.size>E?(g(!0),(0,d.Bl)(a.size)):(g(!1),t(n))},dropArea:i,highlightDropArea:f,highlight:l,unhighlightDropArea:h,iconColor:M,maxSize:E}))};L.propTypes={onFileChange:i().func.isRequired};const _=L},75273:(e,t,n)=>{n.d(t,{P:()=>c,q:()=>d});var a=n(14041),r=n(2345),i=n(35057),l=n(58797),o=n(59437);const s=4,A=(0,r.Ay)(o.m)`
  display: flex;
  overflow: hidden;
  padding: 0;
`,c=(0,r.Ay)(l.EA)`
  // Make sure the skeleton's height is around the same as the job offer item.
  height: 174px;
  width: 244px;
  margin-right: 16px;
  flex-shrink: 0;
`,d=e=>{let{skeletonCount:t=s,...n}=e;return a.createElement(A,n,(0,i.A)(t).map(e=>a.createElement(c,{key:e})))}},79015:(e,t,n)=>{n.d(t,{A:()=>R});var a=n(24586),r=n(14041),i=n(38544),l=n(2345),o=n(97434),s=n(47566),A=n(66576),c=n(80503),d=n(17710),p=n(69421),m=n(87961),u=n(82202),g=n(40132),C=n(5369),f=n(33131),h=n(66341),y=n(36080),E=n(75992),M=n(61631);const x=l.Ay.div`
  width: 100%;

  ${e=>{let{isTiny:t}=e;return t?"\n      display: flex;\n      align-items: center;\n\n      h4 {\n        margin: 0 !important;\n      }\n      ":""}}
`,w=l.Ay.div`
  background-color: var(--landing-analyse-background-color);
  border-radius: 5px;
  min-height: 300px;
  padding: 20px;
  font-family: var(--regular-text-font);

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    padding: 30px;
  }
`,D=l.Ay.div`
  display: flex;
  justify-self: center;
  flex-direction: row;
  flex-wrap: wrap;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    display: block;
  }
`,b=l.Ay.div`
  width: 100px;
  margin: 0 auto;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    max-width: 140px;
    float: left;
    margin-right: 40px;

    ${e=>{let{isTiny:t}=e;return t&&"\n    margin: 0;\n    align-self: center;\n    float: none;\n  "}}
  }

  svg {
    fill: ${e=>{let{theme:t}=e;return(0,M.x6)(t.palette,"secondary","light")}};
  }
`,L=l.Ay.div`
  align-self: center;
  font-family: var(--regular-text-font);
  font-size: 20px;
  font-weight: 300;
  margin: 0 auto;
  min-width: 120px;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    ${e=>{let{isTiny:t}=e;return t&&"\n      display: flex;\n      align-self: center;\n      margin: 0 0 0 20px;\n  "}}
  }
  ${e=>{let{err:t}=e;return t&&"display: none;"}}
`,_=l.Ay.div`
  color: #1f3038;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("mobile")}} {
    display: inline-block;
    width: 55%;
    margin-left: 5px;
    ${e=>{let{isTiny:t}=e;return t&&"\n      width: 100%;\n    "}}
  }
`,I=l.Ay.div`
  margin-bottom: 15px;
`,v=l.Ay.div`
  display: flex;
  align-items: center;
`,N=l.Ay.div`
  svg {
    display: flex;
    width: 20px;
  }
`,k=l.Ay.p`
  padding-left: 10px;
  font-size: 14px;
`,j=l.Ay.div`
  font-size: 14px;
  ${e=>{let{err:t}=e;return t&&"\n    display: none;\n  "}}
`,z=l.Ay.div`
  position: relative;
  top: 5px;
  left: 8px;
  padding: 10px 15px;
  border-left: 3px solid rgba(59, 134, 255, 0.1);
`,T=l.Ay.p`
  margin: 0;
  font-size: 12px;
  color: #7d8397;
  & > strong {
    font-family: var(--regular-text-font);
    font-size: 14px;
    font-weight: bold;
  }
`,O=l.Ay.span`
  font-family: var(--regular-text-font);
  font-size: 16px;
  font-weight: bold;
`,Q=l.Ay.div`
  padding-left: 30px;
  font-family: var(--regular-text-font);
`,S=l.Ay.p`
  margin: 0 0 20px 0;
  font-style: italic;
  font-size: 12px;
  ${e=>{let{color:t}=e;return`\n    color: ${t}\n  `}}
`,P=l.Ay.button`
  background-color: var(--button-background-color);
  color: #ffffff;
  font-size: 14px;
  font-weight: 600;
  padding: 13px 19px;
  border-radius: 2px;
  cursor: pointer;
  transition: background-color 0.4s;
  &:hover {
    filter: var(--button-background-color-on-hover);
  }
`,B=(0,l.Ay)(s.A)`
  color: ${y.wV[500]};
`,V=()=>{const e=(0,i.d4)(e=>e.profile.isFetching),t=(0,i.d4)(e=>e.profile.err),n=(0,i.d4)(e=>e.profile.identity);return t?r.createElement(f.A,{View:h.cZ,fill:y.$D[500],style:{height:"fit-content"}}):e?r.createElement(B,{size:20}):(0,E.A)(n)?r.createElement(f.A,{View:h.cZ,fill:y.N5[500],style:{height:"fit-content"}}):r.createElement(f.A,{View:h.KD,fill:y.wV[500],style:{height:"fit-content"}})},$=()=>{const{t:e}=(0,o.Bd)(),t=(0,i.d4)(e=>e.profile.isFetching),n=(0,i.d4)(e=>e.profile.err);return r.createElement(A.A,{in:!t&&!n},r.createElement(k,null,e("profile_analysis.degraded_mode")))},F=e=>{let{onEndTransition:t}=e;const{t:n}=(0,o.Bd)(),a=(0,i.d4)(e=>e.profile);return r.createElement(A.A,{in:!a.isFetching&&!a.err,addEndListener:t},r.createElement(z,null,a&&r.createElement(T,null,r.createElement("span",null,n("profile_analysis.hello")),a.identity.first_name&&r.createElement(O,null," ",a.identity.first_name),","),a&&r.createElement(T,null,n("profile_analysis.found")," ",r.createElement("strong",null,n("profile_analysis.skills_with_count",{count:a.skills.length}))," ",n("profile_analysis.and")," ",r.createElement("strong",null,n("profile_analysis.jobs_with_count",{count:a.jobs_and_sought_positions_v3.length}))," ",n("profile_analysis.inside_cv"))))},Z=e=>{let{onEndTransition:t}=e;const n=(0,i.d4)(e=>e.profile.attachment_file_name),a=(0,i.d4)(e=>e.profile.identity);return n?(0,E.A)(a)?r.createElement($,null):r.createElement(F,{onEndTransition:t}):null};class G extends r.Component{constructor(e){super(e),(0,a.A)(this,"onEndTransition",(e,t)=>{this.nextStep(t)}),(0,a.A)(this,"nextStep",e=>{const{profile:t}=this.props;t.id&&setTimeout(()=>{this.setState({nextStep:!0}),this.setState({isFetchingAds:!0}),e()},1e3)}),(0,a.A)(this,"renderRetryAfterError",()=>{const{config:e}=this.context,{t}=this.props;return!0===e.analytics?.at_internet&&g.A.sendPage({name:"echec_analyse_cv",chapter1:"cv_catcher",chapter2:"parcours_web",level2:"1"}),this.props.err&&400===this.props.err.statusCode?r.createElement(Q,null,r.createElement(S,null,t("profile_analysis.error_file")),r.createElement(P,{onClick:()=>this.props.tryAgainAnalyse()},t("profile_analysis.retry"))):r.createElement(Q,null,r.createElement(S,{color:y.$D[500]},t("profile_analysis.error_analyse")),r.createElement(P,{onClick:()=>this.props.tryAgainAnalyse()},t("profile_analysis.retry")))}),(0,a.A)(this,"renderAdsCheckmark",()=>this.state.isFetchingAds?r.createElement(B,{size:20}):this.state.isFetchingAds||this.props.adsErr?this.props.adsErr?r.createElement(f.A,{View:h.cZ,fill:y.$D[500],style:{height:"fit-content"}}):void 0:r.createElement(f.A,{View:h.KD,fill:y.wV[500],style:{height:"fit-content"}})),this.state={nextStep:!1,isFetchingAds:!1,isTiny:!1},this.nodeRef=(0,r.createRef)()}componentDidMount(){this.nodeRef.current.clientWidth<=390&&this.setState({isTiny:!0})}componentDidUpdate(e){e.isFetchingAds&&!this.props.isFetchingAds&&this.setState({isFetchingAds:!1})}render(){const{t:e}=this.props;return r.createElement(w,{ref:this.nodeRef},r.createElement(D,null,r.createElement(x,{isTiny:this.state.isTiny},this.props.err&&400===this.props.err.statusCode?r.createElement(m.G,{isTiny:this.state.isTiny}):r.createElement(b,{isTiny:this.state.isTiny},r.createElement(p.MH,{height:"100%",width:"100%"})),r.createElement(L,{err:this.props.err,isTiny:this.state.isTiny},e("profile_analysis.title"))),r.createElement(_,{isTiny:this.state.isTiny},r.createElement(I,null,r.createElement(v,null,r.createElement(N,null,r.createElement(d.A,null,r.createElement(c.A,{key:!this.props.isFetchingProfile,addEndListener:(e,t)=>e.addEventListener("transitionend",t,!1),classNames:"checkmark"},r.createElement("div",null,r.createElement(V,null))))),r.createElement(k,null,e("profile_analysis.profile_and_skills_analysis"))),!this.props.isFetchingProfile&&this.props.err&&this.renderRetryAfterError(),r.createElement(Z,{onEndTransition:this.onEndTransition})),r.createElement(A.A,{in:this.state.nextStep},r.createElement(j,null,r.createElement(v,null,r.createElement(N,null,r.createElement(d.A,null,r.createElement(c.A,{key:this.props.isFetchingAds,addEndListener:(e,t)=>e.addEventListener("transitionend",t,!1),classNames:"checkmark"},r.createElement("div",null,this.renderAdsCheckmark())))),r.createElement(k,null,e("profile_analysis.matching"))),0===this.props.jobAds&&this.props.adsErr&&this.renderRetryAfterError())))))}}(0,a.A)(G,"contextType",C.Qj);const R=(0,i.Ng)(e=>({isFetchingProfile:e.profile.isFetching,isFetchingAds:e.search.isFetching,profile:e.profile,jobAds:e.search.total,err:e.profile.err,adsErr:e.search.err}),(e,t)=>({tryAgainAnalyse:()=>{e((0,u.sb)()),t.startAnalysis(!1),t.termsOfService&&t.termsOfService(!1)}}))((0,o.CI)()(G))},79273:(e,t,n)=>{n.d(t,{d:()=>s});var a=n(14041);var r=n(2345),i=n(33131),l=n(66341);const o=r.Ay.img`
  width: 24px;
`,s=e=>{let{lang:t}=e;switch(t){case"de":return a.createElement(o,{src:"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6IzQ2NDY1NTsiIGQ9Ik00NzMuNjU1LDg4LjI3NkgzOC4zNDVDMTcuMTY3LDg4LjI3NiwwLDEwNS40NDMsMCwxMjYuNjIxdjczLjQ3MWg1MTJ2LTczLjQ3MQoJQzUxMiwxMDUuNDQzLDQ5NC44MzMsODguMjc2LDQ3My42NTUsODguMjc2eiIvPgo8cGF0aCBzdHlsZT0iZmlsbDojRkZFMTVBOyIgZD0iTTAsMzg1LjM3OWMwLDIxLjE3NywxNy4xNjcsMzguMzQ1LDM4LjM0NSwzOC4zNDVoNDM1LjMxYzIxLjE3NywwLDM4LjM0NS0xNy4xNjcsMzguMzQ1LTM4LjM0NQoJdi03My40NzFIMFYzODUuMzc5eiIvPgo8cmVjdCB5PSIyMDAuMDkiIHN0eWxlPSJmaWxsOiNGRjRCNTU7IiB3aWR0aD0iNTEyIiBoZWlnaHQ9IjExMS44MSIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K",alt:"flags de"});case"en":return a.createElement(o,{src:"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6IzQxNDc5QjsiIGQ9Ik00NzMuNjU1LDg4LjI3NkgzOC4zNDVDMTcuMTY3LDg4LjI3NiwwLDEwNS40NDMsMCwxMjYuNjIxVjM4NS4zOAoJYzAsMjEuMTc3LDE3LjE2NywzOC4zNDUsMzguMzQ1LDM4LjM0NWg0MzUuMzFjMjEuMTc3LDAsMzguMzQ1LTE3LjE2NywzOC4zNDUtMzguMzQ1VjEyNi42MjEKCUM1MTIsMTA1LjQ0Myw0OTQuODMzLDg4LjI3Niw0NzMuNjU1LDg4LjI3NnoiLz4KPHBhdGggc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIGQ9Ik01MTEuNDY5LDEyMC4yODJjLTMuMDIyLTE4LjE1OS0xOC43OTctMzIuMDA3LTM3LjgxNC0zMi4wMDdoLTkuOTc3bC0xNjMuNTQsMTA3LjE0N1Y4OC4yNzZoLTg4LjI3NgoJdjEwNy4xNDdMNDguMzIyLDg4LjI3NmgtOS45NzdjLTE5LjAxNywwLTM0Ljc5MiwxMy44NDctMzcuODE0LDMyLjAwN2wxMzkuNzc4LDkxLjU4SDB2ODguMjc2aDE0MC4zMDlMMC41MzEsMzkxLjcxNwoJYzMuMDIyLDE4LjE1OSwxOC43OTcsMzIuMDA3LDM3LjgxNCwzMi4wMDdoOS45NzdsMTYzLjU0LTEwNy4xNDd2MTA3LjE0N2g4OC4yNzZWMzE2LjU3N2wxNjMuNTQsMTA3LjE0N2g5Ljk3NwoJYzE5LjAxNywwLDM0Ljc5Mi0xMy44NDcsMzcuODE0LTMyLjAwN2wtMTM5Ljc3OC05MS41OEg1MTJ2LTg4LjI3NkgzNzEuNjkxTDUxMS40NjksMTIwLjI4MnoiLz4KPGc+Cgk8cG9seWdvbiBzdHlsZT0iZmlsbDojRkY0QjU1OyIgcG9pbnRzPSIyODIuNDgzLDg4LjI3NiAyMjkuNTE3LDg4LjI3NiAyMjkuNTE3LDIyOS41MTcgMCwyMjkuNTE3IDAsMjgyLjQ4MyAyMjkuNTE3LDI4Mi40ODMgCgkJMjI5LjUxNyw0MjMuNzI0IDI4Mi40ODMsNDIzLjcyNCAyODIuNDgzLDI4Mi40ODMgNTEyLDI4Mi40ODMgNTEyLDIyOS41MTcgMjgyLjQ4MywyMjkuNTE3IAkiLz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNGRjRCNTU7IiBkPSJNMjQuNzkzLDQyMS4yNTJsMTg2LjU4My0xMjEuMTE0aC0zMi40MjhMOS4yMjQsNDEwLjMxCgkJQzEzLjM3Nyw0MTUuMTU3LDE4LjcxNCw0MTguOTU1LDI0Ljc5Myw0MjEuMjUyeiIvPgoJPHBhdGggc3R5bGU9ImZpbGw6I0ZGNEI1NTsiIGQ9Ik0zNDYuMzg4LDMwMC4xMzhIMzEzLjk2bDE4MC43MTYsMTE3LjMwNWM1LjA1Ny0zLjMyMSw5LjI3Ny03LjgwNywxMi4yODctMTMuMDc1TDM0Ni4zODgsMzAwLjEzOHoiCgkJLz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNGRjRCNTU7IiBkPSJNNC4wNDksMTA5LjQ3NWwxNTcuNzMsMTAyLjM4N2gzMi40MjhMMTUuNDc1LDk1Ljg0MkMxMC42NzYsOTkuNDE0LDYuNzQ5LDEwNC4wODQsNC4wNDksMTA5LjQ3NXoiLz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNGRjRCNTU7IiBkPSJNMzMyLjU2NiwyMTEuODYybDE3MC4wMzUtMTEwLjM3NWMtNC4xOTktNC44MzEtOS41NzgtOC42MDctMTUuNjk5LTEwLjg2TDMwMC4xMzgsMjExLjg2MkgzMzIuNTY2eiIKCQkvPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+CjxnPgo8L2c+Cjwvc3ZnPgo=",alt:"flags en"});case"es":return a.createElement(o,{src:"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGc+Cgk8cGF0aCBzdHlsZT0iZmlsbDojQzg0MTRCOyIgZD0iTTAsMzg1LjM3OWMwLDIxLjE3NywxNy4xNjcsMzguMzQ1LDM4LjM0NSwzOC4zNDVoNDM1LjMxYzIxLjE3NywwLDM4LjM0NS0xNy4xNjcsMzguMzQ1LTM4LjM0NQoJCXYtMzIuMjc2SDBWMzg1LjM3OXoiLz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNDODQxNEI7IiBkPSJNNDczLjY1NSw4OC4yNzZIMzguMzQ1QzE3LjE2Nyw4OC4yNzYsMCwxMDUuNDQzLDAsMTI2LjYyMXYzMi4yNzZoNTEydi0zMi4yNzYKCQlDNTEyLDEwNS40NDMsNDk0LjgzMyw4OC4yNzYsNDczLjY1NSw4OC4yNzZ6Ii8+CjwvZz4KPHJlY3QgeT0iMTU4LjkiIHN0eWxlPSJmaWxsOiNGRkQyNTA7IiB3aWR0aD0iNTEyIiBoZWlnaHQ9IjE5NC4yMSIvPgo8cGF0aCBzdHlsZT0iZmlsbDojQzg0MTRCOyIgZD0iTTIxNi4yNzYsMjU2bDcuNDg1LTMzLjY4MWMwLjY5LTMuMTAyLTEuNjcxLTYuMDQ0LTQuODQ5LTYuMDQ0aC01LjI3MgoJYy0zLjE3NywwLTUuNTM3LDIuOTQzLTQuODQ5LDYuMDQ0TDIxNi4yNzYsMjU2eiIvPgo8cmVjdCB4PSIyMDcuNDUiIHk9IjIzOC4zNCIgc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIHdpZHRoPSIxNy42NTUiIGhlaWdodD0iNzUuMDMiLz4KPHJlY3QgeD0iMjAzLjAzIiB5PSIyMjkuNTIiIHN0eWxlPSJmaWxsOiNGQUI0NDY7IiB3aWR0aD0iMjYuNDgzIiBoZWlnaHQ9IjguODI4Ii8+CjxnPgoJPHJlY3QgeD0iMTg1LjM4IiB5PSIyNTYiIHN0eWxlPSJmaWxsOiNDODQxNEI7IiB3aWR0aD0iNDQuMTQiIGhlaWdodD0iOC44MjgiLz4KCTxwb2x5Z29uIHN0eWxlPSJmaWxsOiNDODQxNEI7IiBwb2ludHM9IjIyOS41MTcsMjkxLjMxIDIwMy4wMzQsMjgyLjQ4MyAyMDMuMDM0LDI3My42NTUgMjI5LjUxNywyODIuNDgzIAkiLz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNDODQxNEI7IiBkPSJNODMuODYyLDI1Nmw3LjQ4NS0zMy42ODFjMC42OS0zLjEwMi0xLjY3MS02LjA0NC00Ljg0OS02LjA0NGgtNS4yNzIKCQljLTMuMTc3LDAtNS41MzcsMi45NDMtNC44NDksNi4wNDRMODMuODYyLDI1NnoiLz4KPC9nPgo8cGF0aCBzdHlsZT0iZmlsbDojRjVGNUY1OyIgZD0iTTExNC43NTksMjI5LjUxN2MtNC44NzUsMC04LjgyOCwzLjk1My04LjgyOCw4LjgyOHY1Ny4zNzljMCwxMC43MjUsMTAuMDEsMzAuODk3LDQ0LjEzOCwzMC44OTcKCXM0NC4xMzgtMjAuMTcxLDQ0LjEzOC0zMC44OTd2LTU3LjM3OWMwLTQuODc1LTMuOTUzLTguODI4LTguODI4LTguODI4SDExNC43NTl6Ii8+CjxnPgoJPHBhdGggc3R5bGU9ImZpbGw6I0M4NDE0QjsiIGQ9Ik0xNTAuMDY5LDI3My42NTVoLTQ0LjEzOHYtMzUuMzFjMC00Ljg3NSwzLjk1My04LjgyOCw4LjgyOC04LjgyOGgzNS4zMVYyNzMuNjU1eiIvPgoJPHBhdGggc3R5bGU9ImZpbGw6I0M4NDE0QjsiIGQ9Ik0xNTAuMDY5LDI3My42NTVoNDQuMTM4djIyLjA2OWMwLDEyLjE4OS05Ljg4LDIyLjA2OS0yMi4wNjksMjIuMDY5bDAsMAoJCWMtMTIuMTg5LDAtMjIuMDY5LTkuODgtMjIuMDY5LTIyLjA2OVYyNzMuNjU1eiIvPgo8L2c+CjxwYXRoIHN0eWxlPSJmaWxsOiNGQUI0NDY7IiBkPSJNMTA1LjkzMSwyNzMuNjU1aDQ0LjEzOHYyMi4wNjljMCwxMi4xODktOS44OCwyMi4wNjktMjIuMDY5LDIyLjA2OWwwLDAKCWMtMTIuMTg5LDAtMjIuMDY5LTkuODgtMjIuMDY5LTIyLjA2OVYyNzMuNjU1eiIvPgo8Zz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNDODQxNEI7IiBkPSJNMTQxLjI0MSwzMTMuMjh2LTM5LjYyNWgtOC44Mjh2NDMuNjkzQzEzNS42OTcsMzE2LjY4MiwxMzguNjY0LDMxNS4yMjgsMTQxLjI0MSwzMTMuMjh6Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojQzg0MTRCOyIgZD0iTTEyMy41ODYsMzE3LjM0OHYtNDMuNjkzaC04LjgyOHYzOS42MjVDMTE3LjMzNiwzMTUuMjI4LDEyMC4zMDMsMzE2LjY4MiwxMjMuNTg2LDMxNy4zNDh6Ii8+CjwvZz4KPHJlY3QgeD0iMTE0Ljc2IiB5PSIyNTYiIHN0eWxlPSJmaWxsOiNGRkI0NDE7IiB3aWR0aD0iMjYuNDgzIiBoZWlnaHQ9IjguODI4Ii8+CjxnPgoJPHJlY3QgeD0iMTE0Ljc2IiB5PSIyMzguMzQiIHN0eWxlPSJmaWxsOiNGQUI0NDY7IiB3aWR0aD0iMjYuNDgzIiBoZWlnaHQ9IjguODI4Ii8+Cgk8cmVjdCB4PSIxMTkuMTciIHk9IjI0My41OSIgc3R5bGU9ImZpbGw6I0ZBQjQ0NjsiIHdpZHRoPSIxNy42NTUiIGhlaWdodD0iMTUuOTkyIi8+CjwvZz4KPHJlY3QgeD0iNzUuMDMiIHk9IjIzOC4zNCIgc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIHdpZHRoPSIxNy42NTUiIGhlaWdodD0iNzUuMDMiLz4KPGc+Cgk8cmVjdCB4PSI3MC42MiIgeT0iMzA4Ljk3IiBzdHlsZT0iZmlsbDojRkFCNDQ2OyIgd2lkdGg9IjI2LjQ4MyIgaGVpZ2h0PSI4LjgyOCIvPgoJPHJlY3QgeD0iNzAuNjIiIHk9IjIyOS41MiIgc3R5bGU9ImZpbGw6I0ZBQjQ0NjsiIHdpZHRoPSIyNi40ODMiIGhlaWdodD0iOC44MjgiLz4KPC9nPgo8cmVjdCB4PSI2Ni4yMSIgeT0iMzE3Ljc5IiBzdHlsZT0iZmlsbDojNTA2NEFBOyIgd2lkdGg9IjM1LjMxIiBoZWlnaHQ9IjguODI4Ii8+CjxyZWN0IHg9IjIwNy40NSIgeT0iMzA4Ljk3IiBzdHlsZT0iZmlsbDojRkFCNDQ2OyIgd2lkdGg9IjI2LjQ4MyIgaGVpZ2h0PSI4LjgyOCIvPgo8cmVjdCB4PSIxOTguNjIiIHk9IjMxNy43OSIgc3R5bGU9ImZpbGw6IzUwNjRBQTsiIHdpZHRoPSIzNS4zMSIgaGVpZ2h0PSI4LjgyOCIvPgo8cmVjdCB4PSIxMjMuNTkiIHk9IjIyMC42OSIgc3R5bGU9ImZpbGw6I0ZBQjQ0NjsiIHdpZHRoPSI1Mi45NjYiIGhlaWdodD0iOC44MjgiLz4KPHJlY3QgeD0iMTQ1LjY2IiB5PSIxOTQuMjEiIHN0eWxlPSJmaWxsOiNGRkI0NDE7IiB3aWR0aD0iOC44MjgiIGhlaWdodD0iMjYuNDgzIi8+CjxnPgoJPHBhdGggc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIGQ9Ik0xNDEuMjQxLDIwNy40NDhjLTcuMzAyLDAtMTMuMjQxLTUuOTQtMTMuMjQxLTEzLjI0MWMwLTcuMzAyLDUuOTQtMTMuMjQxLDEzLjI0MS0xMy4yNDEKCQljNy4zMDIsMCwxMy4yNDEsNS45NCwxMy4yNDEsMTMuMjQxQzE1NC40ODMsMjAxLjUwOCwxNDguNTQzLDIwNy40NDgsMTQxLjI0MSwyMDcuNDQ4eiBNMTQxLjI0MSwxODkuNzkzCgkJYy0yLjQzNSwwLTQuNDE0LDEuOTc4LTQuNDE0LDQuNDE0YzAsMi40MzUsMS45NzgsNC40MTQsNC40MTQsNC40MTRzNC40MTQtMS45NzgsNC40MTQtNC40MTQKCQlDMTQ1LjY1NSwxOTEuNzcyLDE0My42NzcsMTg5Ljc5MywxNDEuMjQxLDE4OS43OTN6Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojRjVGNUY1OyIgZD0iTTE1OC44OTcsMjA3LjQ0OGMtNy4zMDIsMC0xMy4yNDEtNS45NC0xMy4yNDEtMTMuMjQxYzAtNy4zMDIsNS45NC0xMy4yNDEsMTMuMjQxLTEzLjI0MQoJCWM3LjMwMiwwLDEzLjI0MSw1Ljk0LDEzLjI0MSwxMy4yNDFTMTY2LjE5OCwyMDcuNDQ4LDE1OC44OTcsMjA3LjQ0OHogTTE1OC44OTcsMTg5Ljc5M2MtMi40MzUsMC00LjQxNCwxLjk3OC00LjQxNCw0LjQxNAoJCWMwLDIuNDM1LDEuOTc4LDQuNDE0LDQuNDE0LDQuNDE0YzIuNDM1LDAsNC40MTQtMS45NzgsNC40MTQtNC40MTRDMTYzLjMxLDE5MS43NzIsMTYxLjMzMiwxODkuNzkzLDE1OC44OTcsMTg5Ljc5M3oiLz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNGNUY1RjU7IiBkPSJNMTc2LjU1MiwyMTYuMjc2Yy03LjMwMiwwLTEzLjI0MS01Ljk0LTEzLjI0MS0xMy4yNDFjMC03LjMwMiw1Ljk0LTEzLjI0MSwxMy4yNDEtMTMuMjQxCgkJYzcuMzAyLDAsMTMuMjQxLDUuOTQsMTMuMjQxLDEzLjI0MVMxODMuODUzLDIxNi4yNzYsMTc2LjU1MiwyMTYuMjc2eiBNMTc2LjU1MiwxOTguNjIxYy0yLjQzNSwwLTQuNDE0LDEuOTc4LTQuNDE0LDQuNDE0CgkJYzAsMi40MzUsMS45NzgsNC40MTQsNC40MTQsNC40MTRjMi40MzUsMCw0LjQxNC0xLjk3OCw0LjQxNC00LjQxNFMxNzguOTg3LDE5OC42MjEsMTc2LjU1MiwxOTguNjIxeiIvPgoJPHBhdGggc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIGQ9Ik0xMjMuNTg2LDIxNi4yNzZjLTcuMzAyLDAtMTMuMjQxLTUuOTQtMTMuMjQxLTEzLjI0MWMwLTcuMzAyLDUuOTQtMTMuMjQxLDEzLjI0MS0xMy4yNDEKCQljNy4zMDIsMCwxMy4yNDEsNS45NCwxMy4yNDEsMTMuMjQxQzEzNi44MjgsMjEwLjMzNiwxMzAuODg4LDIxNi4yNzYsMTIzLjU4NiwyMTYuMjc2eiBNMTIzLjU4NiwxOTguNjIxCgkJYy0yLjQzNSwwLTQuNDE0LDEuOTc4LTQuNDE0LDQuNDE0YzAsMi40MzUsMS45NzgsNC40MTQsNC40MTQsNC40MTRTMTI4LDIwNS40NywxMjgsMjAzLjAzNAoJCUMxMjgsMjAwLjU5OSwxMjYuMDIyLDE5OC42MjEsMTIzLjU4NiwxOTguNjIxeiIvPgo8L2c+CjxwYXRoIHN0eWxlPSJmaWxsOiNGQUI0NDY7IiBkPSJNMTc2LjU1MiwyOTEuMzF2NC40MTRjMCwyLjQzNC0xLjk4LDQuNDE0LTQuNDE0LDQuNDE0cy00LjQxNC0xLjk4LTQuNDE0LTQuNDE0di00LjQxNEgxNzYuNTUyCgkgTTE4NS4zNzksMjgyLjQ4M2gtMjYuNDgzdjEzLjI0MWMwLDcuMzAyLDUuOTQsMTMuMjQxLDEzLjI0MSwxMy4yNDFjNy4zMDIsMCwxMy4yNDEtNS45NCwxMy4yNDEtMTMuMjQxdi0xMy4yNDFIMTg1LjM3OXoiLz4KPHBhdGggc3R5bGU9ImZpbGw6I0ZGQTBEMjsiIGQ9Ik0xNzIuMTM4LDI2NC44MjhMMTcyLjEzOCwyNjQuODI4Yy00Ljg3NSwwLTguODI4LTMuOTUzLTguODI4LTguODI4di04LjgyOAoJYzAtNC44NzUsMy45NTMtOC44MjgsOC44MjgtOC44MjhsMCwwYzQuODc1LDAsOC44MjgsMy45NTMsOC44MjgsOC44MjhWMjU2QzE4MC45NjYsMjYwLjg3NSwxNzcuMDEzLDI2NC44MjgsMTcyLjEzOCwyNjQuODI4eiIvPgo8Y2lyY2xlIHN0eWxlPSJmaWxsOiM1MDY0QUE7IiBjeD0iMTUwLjA3IiBjeT0iMjczLjY1IiByPSIxMy4yNDEiLz4KPHJlY3QgeD0iMTQ1LjY2IiB5PSIxNzYuNTUiIHN0eWxlPSJmaWxsOiNGQUI0NDY7IiB3aWR0aD0iOC44MjgiIGhlaWdodD0iMjYuNDgzIi8+CjxwYXRoIHN0eWxlPSJmaWxsOiNDODQxNEI7IiBkPSJNMTIzLjU4NiwyMjAuNjlsLTguODI4LTguODI4bDUuMTcxLTUuMTcxYzcuOTkzLTcuOTkzLDE4LjgzNS0xMi40ODQsMzAuMTQtMTIuNDg0bDAsMAoJYzExLjMwNSwwLDIyLjE0Niw0LjQ5MSwzMC4xNCwxMi40ODRsNS4xNzEsNS4xNzFsLTguODI4LDguODI4SDEyMy41ODZ6Ii8+CjxnPgoJPGNpcmNsZSBzdHlsZT0iZmlsbDojRkZEMjUwOyIgY3g9IjE1MC4wNyIgY3k9IjIxMS44NiIgcj0iNC40MTQiLz4KCTxjaXJjbGUgc3R5bGU9ImZpbGw6I0ZGRDI1MDsiIGN4PSIxMzIuNDEiIGN5PSIyMTEuODYiIHI9IjQuNDE0Ii8+Cgk8Y2lyY2xlIHN0eWxlPSJmaWxsOiNGRkQyNTA7IiBjeD0iMTY3LjcyIiBjeT0iMjExLjg2IiByPSI0LjQxNCIvPgo8L2c+CjxnPgoJPHJlY3QgeD0iNzAuNjIiIHk9IjI1NiIgc3R5bGU9ImZpbGw6I0M4NDE0QjsiIHdpZHRoPSI0NC4xNCIgaGVpZ2h0PSI4LjgyOCIvPgoJPHBvbHlnb24gc3R5bGU9ImZpbGw6I0M4NDE0QjsiIHBvaW50cz0iNzAuNjIxLDI5MS4zMSA5Ny4xMDMsMjgyLjQ4MyA5Ny4xMDMsMjczLjY1NSA3MC42MjEsMjgyLjQ4MyAJIi8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==",alt:"flags es"});case"fr":return a.createElement(o,{src:"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6IzQxNDc5QjsiIGQ9Ik0zOC4zNDUsODguMjczQzE3LjE2Nyw4OC4yNzMsMCwxMDUuNDQsMCwxMjYuNjE4djI1OC43NTljMCwyMS4xNzcsMTcuMTY3LDM4LjM0NSwzOC4zNDUsMzguMzQ1CgloMTMyLjMyMlY4OC4yNzNIMzguMzQ1eiIvPgo8cmVjdCB4PSIxNzAuNjciIHk9Ijg4LjI3NyIgc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIHdpZHRoPSIxNzAuNjciIGhlaWdodD0iMzM1LjQ1Ii8+CjxwYXRoIHN0eWxlPSJmaWxsOiNGRjRCNTU7IiBkPSJNNDczLjY1NSw4OC4yNzNIMzQxLjMzM3YzMzUuNDQ4aDEzMi4zMjJjMjEuMTc3LDAsMzguMzQ1LTE3LjE2NywzOC4zNDUtMzguMzQ1VjEyNi42MTgKCUM1MTIsMTA1LjQ0LDQ5NC44MzMsODguMjczLDQ3My42NTUsODguMjczeiIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K",alt:"flags fr"});case"it":return a.createElement(o,{src:"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6IzczQUYwMDsiIGQ9Ik0zOC4zNDUsODguMjczQzE3LjE2Nyw4OC4yNzMsMCwxMDUuNDQsMCwxMjYuNjE4djI1OC43NTljMCwyMS4xNzcsMTcuMTY3LDM4LjM0NSwzOC4zNDUsMzguMzQ1CgloMTMyLjMyMlY4OC4yNzNIMzguMzQ1eiIvPgo8cmVjdCB4PSIxNzAuNjciIHk9Ijg4LjI3NyIgc3R5bGU9ImZpbGw6I0Y1RjVGNTsiIHdpZHRoPSIxNzAuNjciIGhlaWdodD0iMzM1LjQ1Ii8+CjxwYXRoIHN0eWxlPSJmaWxsOiNGRjRCNTU7IiBkPSJNNDczLjY1NSw4OC4yNzNIMzQxLjMzM3YzMzUuNDQ4aDEzMi4zMjJjMjEuMTc3LDAsMzguMzQ1LTE3LjE2NywzOC4zNDUtMzguMzQ1VjEyNi42MTgKCUM1MTIsMTA1LjQ0LDQ5NC44MzMsODguMjczLDQ3My42NTUsODguMjczeiIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K",alt:"flags it"});case"nl":return a.createElement(o,{src:"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6I0ZGNEI1NTsiIGQ9Ik00NzMuNjU1LDg4LjI3NkgzOC4zNDVDMTcuMTY3LDg4LjI3NiwwLDEwNS40NDMsMCwxMjYuNjIxdjczLjQ3MWg1MTJ2LTczLjQ3MQoJQzUxMiwxMDUuNDQzLDQ5NC44MzMsODguMjc2LDQ3My42NTUsODguMjc2eiIvPgo8cGF0aCBzdHlsZT0iZmlsbDojNDE0NzlCOyIgZD0iTTAsMzg1LjM3OWMwLDIxLjE3NywxNy4xNjcsMzguMzQ1LDM4LjM0NSwzOC4zNDVoNDM1LjMxYzIxLjE3NywwLDM4LjM0NS0xNy4xNjcsMzguMzQ1LTM4LjM0NQoJdi03My40NzFIMFYzODUuMzc5eiIvPgo8cmVjdCB5PSIyMDAuMDkiIHN0eWxlPSJmaWxsOiNGNUY1RjU7IiB3aWR0aD0iNTEyIiBoZWlnaHQ9IjExMS44MSIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K",alt:"flags nl"});case"pt":return a.createElement(o,{src:"data:image/svg+xml;base64,//48AHMAdgBnACAAdwBpAGQAdABoAD0AIgA1ADEAMgAiACAAaABlAGkAZwBoAHQAPQAiADUAMQAyACIAIAB2AGkAZQB3AEIAbwB4AD0AIgAwACAAMAAgADIANAAgADIANAAiACAAZgBpAGwAbAA9ACIAbgBvAG4AZQAiACAAeABtAGwAbgBzAD0AIgBoAHQAdABwADoALwAvAHcAdwB3AC4AdwAzAC4AbwByAGcALwAyADAAMAAwAC8AcwB2AGcAIgA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADIAMgAuADIAMAAyADYAIAAxADkALgA4ADYAMgA4AEgAMQAuADcAOQA3ADQAMgBDADAALgA4ADAANAA3ADAAMwAgADEAOQAuADgANgAyADgAIAAwACAAMQA5AC4AMAA1ADgAMQAgADAAIAAxADgALgAwADYANQA0AFYANQAuADkAMwA2ADAAOQBDADAAIAA0AC4AOQA0ADMANAAyACAAMAAuADgAMAA0ADcAMAAzACAANAAuADEAMwA4ADYANwAgADEALgA3ADkANwA0ADIAIAA0AC4AMQAzADgANgA3AEgAMgAyAC4AMgAwADIANgBDADIAMwAuADEAOQA1ADIAIAA0AC4AMQAzADgANgA3ACAAMgA0ACAANAAuADkANAAzADMAOAAgADIANAAgADUALgA5ADMANgAwADkAVgAxADgALgAwADYANQA1AEMAMgA0ACAAMQA5AC4AMAA1ADgAMQAgADIAMwAuADEAOQA1ADMAIAAxADkALgA4ADYAMgA4ACAAMgAyAC4AMgAwADIANgAgADEAOQAuADgANgAyADgAWgAiACAAZgBpAGwAbAA9ACIAIwBGAEYANABCADUANQAiAC8APgAKACAAIAAgACAAPABwAGEAdABoACAAZAA9ACIATQAxAC4ANwA5ADcANAAyACAANAAuADEAMwA4ADYANwBDADAALgA4ADAANAA3ADAAMwAgADQALgAxADMAOAA2ADcAIAAwACAANAAuADkANAAzADMAOAAgADAAIAA1AC4AOQAzADYAMAA5AFYAMQA4AC4AMAA2ADUANQBDADAAIAAxADkALgAwADUAOAAxACAAMAAuADgAMAA0ADcAMAAzACAAMQA5AC4AOAA2ADIAOQAgADEALgA3ADkANwA0ADIAIAAxADkALgA4ADYAMgA5AEgAOAAuADYAOAA5ADYANABWADQALgAxADMAOAA2ADcASAAxAC4ANwA5ADcANAAyAFoAIgAgAGYAaQBsAGwAPQAiACMANwAzAEEARgAwADAAIgAvAD4ACgAgACAAIAAgADwAcABhAHQAaAAgAGQAPQAiAE0AOAAuADYAOQAzADEAMQAgADEANQAuADcAMgAxADIAQwAxADAALgA3ADQAOAAxACAAMQA1AC4ANwAyADEAMgAgADEAMgAuADQAMQA0ACAAMQA0AC4AMAA1ADUAMwAgADEAMgAuADQAMQA0ACAAMQAyAC4AMAAwADAAMgBDADEAMgAuADQAMQA0ACAAOQAuADkANAA1ADIAMgAgADEAMAAuADcANAA4ADEAIAA4AC4AMgA3ADkAMwAgADgALgA2ADkAMwAxADEAIAA4AC4AMgA3ADkAMwBDADYALgA2ADMAOAAwADkAIAA4AC4AMgA3ADkAMwAgADQALgA5ADcAMgAxADcAIAA5AC4AOQA0ADUAMgAyACAANAAuADkANwAyADEANwAgADEAMgAuADAAMAAwADIAQwA0AC4AOQA3ADIAMQA3ACAAMQA0AC4AMAA1ADUAMwAgADYALgA2ADMAOAAwADkAIAAxADUALgA3ADIAMQAyACAAOAAuADYAOQAzADEAMQAgADEANQAuADcAMgAxADIAWgAiACAAZgBpAGwAbAA9ACIAIwBGAEYARQAxADUAQQAiAC8APgAKACAAIAAgACAAPABwAGEAdABoACAAZAA9ACIATQA5AC4AOQAzADQANAAzACAAMQAwAC4ANwA1ADkAMgBWADEAMgAuADQAMQA0ADQAQwA5AC4AOQAzADQANAAzACAAMQAzAC4AMAA5ADgAOQAgADkALgAzADcANwA1ADYAIAAxADMALgA2ADUANQA4ACAAOAAuADYAOQAzADAANAAgADEAMwAuADYANQA1ADgAQwA4AC4AMAAwADgANQAyACAAMQAzAC4ANgA1ADUAOAAgADcALgA0ADUAMQA2ADUAIAAxADMALgAwADkAOAA5ACAANwAuADQANQAxADYANQAgADEAMgAuADQAMQA0ADQAVgAxADAALgA3ADUAOQAyAEgAOQAuADkAMwA0ADQAMwBaAE0AMQAwAC4AMwA0ADgAMgAgADkALgA5ADMAMQA2ADQASAA3AC4AMAAzADcAOAA0AEMANgAuADgAMAA5ADMAMgAgADkALgA5ADMAMQA2ADQAIAA2AC4ANgAyADQAMAAyACAAMQAwAC4AMQAxADYAOQAgADYALgA2ADIANAAwADIAIAAxADAALgAzADQANQA1AFYAMQAyAC4ANAAxADQANABDADYALgA2ADIANAAwADIAIAAxADMALgA1ADUANwAgADcALgA1ADUAMAAzADcAIAAxADQALgA0ADgAMwA0ACAAOAAuADYAOQAyADkAOQAgADEANAAuADQAOAAzADQAQwA5AC4AOAAzADUANgAyACAAMQA0AC4ANAA4ADMANAAgADEAMAAuADcANgAyACAAMQAzAC4ANQA1ADcAIAAxADAALgA3ADYAMgAgADEAMgAuADQAMQA0ADQAVgAxADAALgAzADQANQA1AEMAMQAwAC4ANwA2ADIAIAAxADAALgAxADEANgA5ACAAMQAwAC4ANQA3ADYANwAgADkALgA5ADMAMQA2ADQAIAAxADAALgAzADQAOAAyACAAOQAuADkAMwAxADYANABaACIAIABmAGkAbABsAD0AIgAjAEYARgA0AEIANQA1ACIALwA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADkALgA5ADMANAA0ADQAIAAxADAALgA3ADUANwA4AFYAMQAyAC4ANAAxADMAQwA5AC4AOQAzADQANAA0ACAAMQAzAC4AMAA5ADcANQAgADkALgAzADcANwA1ADcAIAAxADMALgA2ADUANAA0ACAAOAAuADYAOQAzADAANQAgADEAMwAuADYANQA0ADQAQwA4AC4AMAAwADgANQA0ACAAMQAzAC4ANgA1ADQANAAgADcALgA0ADUAMQA2ADYAIAAxADMALgAwADkANwA1ACAANwAuADQANQAxADYANgAgADEAMgAuADQAMQAzAFYAMQAwAC4ANwA1ADcAOABIADkALgA5ADMANAA0ADQAWgAiACAAZgBpAGwAbAA9ACIAIwBGADUARgA1AEYANQAiAC8APgAKACAAIAAgACAAPABwAGEAdABoACAAZAA9ACIATQA3AC4AMAAzADQANQA0ACAAMQAwAC4ANQA1ADIANQBDADcALgAxADQAOAA4ADEAIAAxADAALgA1ADUAMgA1ACAANwAuADIANAAxADQANQAgADEAMAAuADQANQA5ADgAIAA3AC4AMgA0ADEANAA1ACAAMQAwAC4AMwA0ADUANgBDADcALgAyADQAMQA0ADUAIAAxADAALgAyADMAMQAzACAANwAuADEANAA4ADgAMQAgADEAMAAuADEAMwA4ADcAIAA3AC4AMAAzADQANQA0ACAAMQAwAC4AMQAzADgANwBDADYALgA5ADIAMAAyADcAIAAxADAALgAxADMAOAA3ACAANgAuADgAMgA3ADYANAAgADEAMAAuADIAMwAxADMAIAA2AC4AOAAyADcANgA0ACAAMQAwAC4AMwA0ADUANgBDADYALgA4ADIANwA2ADQAIAAxADAALgA0ADUAOQA4ACAANgAuADkAMgAwADIANwAgADEAMAAuADUANQAyADUAIAA3AC4AMAAzADQANQA0ACAAMQAwAC4ANQA1ADIANQBaACIAIABmAGkAbABsAD0AIgAjAEYARgBFADEANQBBACIALwA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADEAMAAuADMANAA1ADEAIAAxADAALgA1ADUAMgA1AEMAMQAwAC4ANAA1ADkANAAgADEAMAAuADUANQAyADUAIAAxADAALgA1ADUAMgAgADEAMAAuADQANQA5ADgAIAAxADAALgA1ADUAMgAgADEAMAAuADMANAA1ADYAQwAxADAALgA1ADUAMgAgADEAMAAuADIAMwAxADMAIAAxADAALgA0ADUAOQA0ACAAMQAwAC4AMQAzADgANwAgADEAMAAuADMANAA1ADEAIAAxADAALgAxADMAOAA3AEMAMQAwAC4AMgAzADAAOAAgADEAMAAuADEAMwA4ADcAIAAxADAALgAxADMAOAAyACAAMQAwAC4AMgAzADEAMwAgADEAMAAuADEAMwA4ADIAIAAxADAALgAzADQANQA2AEMAMQAwAC4AMQAzADgAMgAgADEAMAAuADQANQA5ADgAIAAxADAALgAyADMAMAA4ACAAMQAwAC4ANQA1ADIANQAgADEAMAAuADMANAA1ADEAIAAxADAALgA1ADUAMgA1AFoAIgAgAGYAaQBsAGwAPQAiACMARgBGAEUAMQA1AEEAIgAvAD4ACgAgACAAIAAgADwAcABhAHQAaAAgAGQAPQAiAE0ANwAuADAAMwA0ADUANAAgADEAMgAuADIAMAA2ADgAQwA3AC4AMQA0ADgAOAAxACAAMQAyAC4AMgAwADYAOAAgADcALgAyADQAMQA0ADUAIAAxADIALgAxADEANAAxACAANwAuADIANAAxADQANQAgADEAMQAuADkAOQA5ADkAQwA3AC4AMgA0ADEANAA1ACAAMQAxAC4AOAA4ADUANgAgADcALgAxADQAOAA4ADEAIAAxADEALgA3ADkAMwAgADcALgAwADMANAA1ADQAIAAxADEALgA3ADkAMwBDADYALgA5ADIAMAAyADcAIAAxADEALgA3ADkAMwAgADYALgA4ADIANwA2ADQAIAAxADEALgA4ADgANQA2ACAANgAuADgAMgA3ADYANAAgADEAMQAuADkAOQA5ADkAQwA2AC4AOAAyADcANgA0ACAAMQAyAC4AMQAxADQAMQAgADYALgA5ADIAMAAyADcAIAAxADIALgAyADAANgA4ACAANwAuADAAMwA0ADUANAAgADEAMgAuADIAMAA2ADgAWgAiACAAZgBpAGwAbAA9ACIAIwBGAEYARQAxADUAQQAiAC8APgAKACAAIAAgACAAPABwAGEAdABoACAAZAA9ACIATQAxADAALgAzADQANQAxACAAMQAyAC4AMgAwADYAOABDADEAMAAuADQANQA5ADQAIAAxADIALgAyADAANgA4ACAAMQAwAC4ANQA1ADIAIAAxADIALgAxADEANAAxACAAMQAwAC4ANQA1ADIAIAAxADEALgA5ADkAOQA5AEMAMQAwAC4ANQA1ADIAIAAxADEALgA4ADgANQA2ACAAMQAwAC4ANAA1ADkANAAgADEAMQAuADcAOQAzACAAMQAwAC4AMwA0ADUAMQAgADEAMQAuADcAOQAzAEMAMQAwAC4AMgAzADAAOAAgADEAMQAuADcAOQAzACAAMQAwAC4AMQAzADgAMgAgADEAMQAuADgAOAA1ADYAIAAxADAALgAxADMAOAAyACAAMQAxAC4AOQA5ADkAOQBDADEAMAAuADEAMwA4ADIAIAAxADIALgAxADEANAAxACAAMQAwAC4AMgAzADAAOAAgADEAMgAuADIAMAA2ADgAIAAxADAALgAzADQANQAxACAAMQAyAC4AMgAwADYAOABaACIAIABmAGkAbABsAD0AIgAjAEYARgBFADEANQBBACIALwA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADgALgA2ADgAOQA4ADIAIAAxADAALgA1ADUAMgA1AEMAOAAuADgAMAA0ADAAOQAgADEAMAAuADUANQAyADUAIAA4AC4AOAA5ADYANwAyACAAMQAwAC4ANAA1ADkAOAAgADgALgA4ADkANgA3ADIAIAAxADAALgAzADQANQA2AEMAOAAuADgAOQA2ADcAMgAgADEAMAAuADIAMwAxADMAIAA4AC4AOAAwADQAMAA5ACAAMQAwAC4AMQAzADgANwAgADgALgA2ADgAOQA4ADIAIAAxADAALgAxADMAOAA3AEMAOAAuADUANwA1ADUANQAgADEAMAAuADEAMwA4ADcAIAA4AC4ANAA4ADIAOQAxACAAMQAwAC4AMgAzADEAMwAgADgALgA0ADgAMgA5ADEAIAAxADAALgAzADQANQA2AEMAOAAuADQAOAAyADkAMQAgADEAMAAuADQANQA5ADgAIAA4AC4ANQA3ADUANQA1ACAAMQAwAC4ANQA1ADIANQAgADgALgA2ADgAOQA4ADIAIAAxADAALgA1ADUAMgA1AFoAIgAgAGYAaQBsAGwAPQAiACMARgBGAEUAMQA1AEEAIgAvAD4ACgAgACAAIAAgADwAcABhAHQAaAAgAGQAPQAiAE0AOQAuADkAMwAyACAAMQAzAC4ANwAzADQAMQBDADEAMAAuADAANAA2ADMAIAAxADMALgA3ADMANAAxACAAMQAwAC4AMQAzADgAOQAgADEAMwAuADYANAAxADUAIAAxADAALgAxADMAOAA5ACAAMQAzAC4ANQAyADcAMgBDADEAMAAuADEAMwA4ADkAIAAxADMALgA0ADEAMgA5ACAAMQAwAC4AMAA0ADYAMwAgADEAMwAuADMAMgAwADMAIAA5AC4AOQAzADIAIAAxADMALgAzADIAMAAzAEMAOQAuADgAMQA3ADcAMwAgADEAMwAuADMAMgAwADMAIAA5AC4ANwAyADUAMQAgADEAMwAuADQAMQAyADkAIAA5AC4ANwAyADUAMQAgADEAMwAuADUAMgA3ADIAQwA5AC4ANwAyADUAMQAgADEAMwAuADYANAAxADUAIAA5AC4AOAAxADcANwAzACAAMQAzAC4ANwAzADQAMQAgADkALgA5ADMAMgAgADEAMwAuADcAMwA0ADEAWgAiACAAZgBpAGwAbAA9ACIAIwBGAEYARQAxADUAQQAiAC8APgAKACAAIAAgACAAPABwAGEAdABoACAAZAA9ACIATQA3AC4ANAA3ADIAMAA0ACAAMQAzAC4ANwAzADQAMQBDADcALgA1ADgANgAzADEAIAAxADMALgA3ADMANAAxACAANwAuADYANwA4ADkANQAgADEAMwAuADYANAAxADUAIAA3AC4ANgA3ADgAOQA1ACAAMQAzAC4ANQAyADcAMgBDADcALgA2ADcAOAA5ADUAIAAxADMALgA0ADEAMgA5ACAANwAuADUAOAA2ADMAMQAgADEAMwAuADMAMgAwADMAIAA3AC4ANAA3ADIAMAA0ACAAMQAzAC4AMwAyADAAMwBDADcALgAzADUANwA3ADcAIAAxADMALgAzADIAMAAzACAANwAuADIANgA1ADEANAAgADEAMwAuADQAMQAyADkAIAA3AC4AMgA2ADUAMQA0ACAAMQAzAC4ANQAyADcAMgBDADcALgAyADYANQAxADQAIAAxADMALgA2ADQAMQA1ACAANwAuADMANQA3ADcANwAgADEAMwAuADcAMwA0ADEAIAA3AC4ANAA3ADIAMAA0ACAAMQAzAC4ANwAzADQAMQBaACIAIABmAGkAbABsAD0AIgAjAEYARgBFADEANQBBACIALwA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADgALgA5ADUAOQA4ADYAIAAxADEALgA4ADkANgA1AFYAMQAyAC4AMgA1ADIAOABDADgALgA5ADUAOQA4ADYAIAAxADIALgA0ADAAMAAyACAAOAAuADgAMwA5ADkANQAgADEAMgAuADUAMgAwADEAIAA4AC4ANgA5ADIANQA3ACAAMQAyAC4ANQAyADAAMQBDADgALgA1ADQANQAyACAAMQAyAC4ANQAyADAAMQAgADgALgA0ADIANQAyADkAIAAxADIALgA0ADAAMAAyACAAOAAuADQAMgA1ADIAOQAgADEAMgAuADIANQAyADgAVgAxADEALgA4ADkANgA1AEgAOAAuADkANQA5ADgANgBaACIAIABmAGkAbABsAD0AIgAjADQAMQA0ADcAOQBCACIALwA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADgALgA5ADUAOQA4ADYAIAAxADEALgAwADUAMAA4AFYAMQAxAC4ANAAwADcAMQBDADgALgA5ADUAOQA4ADYAIAAxADEALgA1ADUANAA1ACAAOAAuADgAMwA5ADkANQAgADEAMQAuADYANwA0ADQAIAA4AC4ANgA5ADIANQA3ACAAMQAxAC4ANgA3ADQANABDADgALgA1ADQANQAyACAAMQAxAC4ANgA3ADQANAAgADgALgA0ADIANQAyADkAIAAxADEALgA1ADUANAA1ACAAOAAuADQAMgA1ADIAOQAgADEAMQAuADQAMAA3ADEAVgAxADEALgAwADUAMAA4AEgAOAAuADkANQA5ADgANgBaACIAIABmAGkAbABsAD0AIgAjADQAMQA0ADcAOQBCACIALwA+AAoAIAAgACAAIAA8AHAAYQB0AGgAIABkAD0AIgBNADgALgA5ADUAOQA4ADYAIAAxADIALgA3ADQAOABWADEAMwAuADEAMAA0ADQAQwA4AC4AOQA1ADkAOAA2ACAAMQAzAC4AMgA1ADEAOAAgADgALgA4ADMAOQA5ADUAIAAxADMALgAzADcAMQA3ACAAOAAuADYAOQAyADUANwAgADEAMwAuADMANwAxADcAQwA4AC4ANQA0ADUAMgAgADEAMwAuADMANwAxADcAIAA4AC4ANAAyADUAMgA5ACAAMQAzAC4AMgA1ADEAOAAgADgALgA0ADIANQAyADkAIAAxADMALgAxADAANAA0AFYAMQAyAC4ANwA0ADgASAA4AC4AOQA1ADkAOAA2AFoAIgAgAGYAaQBsAGwAPQAiACMANAAxADQANwA5AEIAIgAvAD4ACgAgACAAIAAgADwAcABhAHQAaAAgAGQAPQAiAE0AOQAuADYANwA5ADUAOAAgADEAMQAuADgAOQA2ADUAVgAxADIALgAyADUAMgA4AEMAOQAuADYANwA5ADUAOAAgADEAMgAuADQAMAAwADIAIAA5AC4ANQA1ADkANgA4ACAAMQAyAC4ANQAyADAAMQAgADkALgA0ADEAMgAzACAAMQAyAC4ANQAyADAAMQBDADkALgAyADYANAA5ADMAIAAxADIALgA1ADIAMAAxACAAOQAuADEANAA1ADAAMgAgADEAMgAuADQAMAAwADIAIAA5AC4AMQA0ADUAMAAyACAAMQAyAC4AMgA1ADIAOABWADEAMQAuADgAOQA2ADUASAA5AC4ANgA3ADkANQA4AFoAIgAgAGYAaQBsAGwAPQAiACMANAAxADQANwA5AEIAIgAvAD4ACgAgACAAIAAgADwAcABhAHQAaAAgAGQAPQAiAE0AOAAuADIANAAwADEAMwAgADEAMQAuADgAOQA2ADUAVgAxADIALgAyADUAMgA4AEMAOAAuADIANAAwADEAMwAgADEAMgAuADQAMAAwADIAIAA4AC4AMQAyADAAMgAyACAAMQAyAC4ANQAyADAAMQAgADcALgA5ADcAMgA4ADUAIAAxADIALgA1ADIAMAAxAEMANwAuADgAMgA1ADQANwAgADEAMgAuADUAMgAwADEAIAA3AC4ANwAwADUANQA3ACAAMQAyAC4ANAAwADAAMgAgADcALgA3ADAANQA1ADcAIAAxADIALgAyADUAMgA4AFYAMQAxAC4AOAA5ADYANQBIADgALgAyADQAMAAxADMAWgAiACAAZgBpAGwAbAA9ACIAIwA0ADEANAA3ADkAQgAiAC8APgAKADwALwBzAHYAZwA+AAoA",alt:"flags pt"});default:return a.createElement(i.A,{View:l.zL,size:24,withContrast:!0})}}},82202:(e,t,n)=>{n.d(t,{Bs:()=>A,Fi:()=>s,GP:()=>o,Nj:()=>d,Z2:()=>l,eT:()=>r,sb:()=>c,xS:()=>i});var a=n(66192);const r=e=>({type:a.Am,payload:{isFetching:!0,attachment_file_name:e,err:null}}),i=(e,t)=>({type:a.rg,payload:{isFetching:!1,id:e.id,profile:e.profile,setContracts:t.search_request.preselect_contracts}}),l=e=>({type:a.NF,payload:{isFetching:!1,err:{name:e.name,message:e.message,errorCode:e.errorCode,statusCode:e.statusCode}}}),o=(e,t)=>{let{max_distance:n,max_distance_filter:r}=t;return{type:a.ql,payload:{isFetching:!0,profileId:e,maxDistance:n,maxDistanceFilter:r}}},s=(e,t)=>({type:a.rG,payload:{isFetching:!1,id:e.id,profile:e.profile,attachment_file_name:e.attachment_file_name,setContracts:t.search_request.preselect_contracts}}),A=e=>({type:a.xf,payload:{isFetching:!1,err:{name:e.name,message:e.message,errorCode:e.errorCode,statusCode:e.statusCode}}}),c=()=>({type:a.Qg,payload:{profileId:null,isFetching:!1,err:null}}),d=(e,t)=>({type:a.HF,payload:{profileId:e,profileIdentity:t}})},83609:(e,t,n)=>{n.d(t,{a:()=>g});var a=n(89575),r=n(27502),i=n(53834),l=n(14041),o=n(97434),s=n(2345),A=n(66341),c=n(58797),d=n(8877),p=n(61631),m=n(65563);const u=s.Ay.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  max-width: 520px;
  min-width: 250px;
  outline: 0;
  background-color: #fff;
  border-radius: 16px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    width: 90vw;
  }
`,g=e=>{let{children:t,className:n,onClose:r,open:o,...s}=e;return l.createElement(i.A,(0,a.A)({open:o,onClose:r},s),l.createElement(u,{className:n},t))},C=s.Ay.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px;
`,f=s.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  flex-grow: 1;
  padding: 12px 35px;
`,h=(0,s.Ay)(c.o5)`
  font-size: 18px;
  font-weight: 700;
  line-height: 24px;
`,y=(0,s.Ay)(c.o5)`
  font-size: 18px;
  font-weight: 400;
  line-height: 20px;
`,E=(0,s.Ay)(m._s)`
  padding: 12px 16px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.mobile}px`}}) {
    padding: 12px;
    min-width: auto;
  }
`,M=(0,s.Ay)(c.o5)`
  font-weight: 400;
  line-height: 1;
`,x=s.Ay.div`
  padding: 48px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    padding: 32px 24px;
  }
`,w=s.Ay.div`
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding: 24px;

  & > *:only-child {
    margin-left: auto;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    justify-content: stretch;
  }
`;g.Content=e=>{let{children:t,...n}=e;return l.createElement(x,n,t)},g.Header=e=>{let{onClose:t,title:n,subtitle:a}=e;const{t:i}=(0,o.Bd)();return l.createElement(l.Fragment,null,l.createElement(C,null,l.createElement(f,null,l.createElement(h,{variant:"span"},n),a&&l.createElement(y,{variant:"span"},a)),t&&l.createElement(E,{colorName:p.QZ,icon:A.MR,iconPosition:"left",onClick:t,"data-testid":"modal-close-button"},l.createElement(d.jp,{up:!0},l.createElement(M,{variant:"span"},i("modal.close"))))),l.createElement(r.A,null))},g.Footer=e=>{let{children:t,...n}=e;return l.createElement(l.Fragment,null,l.createElement(r.A,null),l.createElement(w,n,t))}},84595:(e,t,n)=>{n.d(t,{mc:()=>a.m,C8:()=>Zn,aF:()=>Kn.a,NA:()=>jr,H1:()=>Zr,yP:()=>Hr,hE:()=>Mt.h});var a=n(59437),r=(n(8667),n(14041)),i=n(2345),l=n(89575),o=n(97434),s=n(86090),A=n(85423),c=n(96362),d=n(16600),p=n(58797),m=n(93444),u=n(65563);const g=(0,i.Ay)(p.o5)`
  margin-right: 16px;
  font-size: 1rem;
  font-weight: 600;
`,C=i.Ay.div`
  flex: 1;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  padding: 4px 0px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    flex-direction: column;
    align-items: flex-start;

    ${g} {
      margin-bottom: 16px;
    }
  }
`,f=e=>{let{children:t}=e;const{t:n}=(0,o.Bd)(),a=(0,A.jL)(),i=(0,s.zy)(),l=(0,s.W6)();return r.createElement(C,null,r.createElement(g,{variant:"span",autoContrast:!0},t),r.createElement(u.xy,{onClick:()=>{(0,d.ei)(l,i),a((0,c.G1)())},withUnderline:!0,bold:!0},r.createElement(p.o5,{autoContrast:!0,variant:"span"},n("reset_filters"))))},h=e=>r.createElement(m.mi,(0,l.A)({view:f},e));var y=n(43895),E=n(81868),M=n(99142),x=n(59044),w=n(45728),D=n(31048),b=n(68153),L=n(68145),_=n(66341),I=n(76073),v=n(68382),N=n(18307);const k=(0,r.memo)(e=>{let{view:t,...n}=e;const a=(0,A.jL)(),i=(0,N.Gb)(),{t:s}=(0,o.Bd)(),d=(0,A.oT)(),p=s("remote_work_type_filter.label"),m=s("remote_work_type_filter.label"),u=(0,A.GV)(e=>e.search.aggregations.remote_work_types),g=(0,A.GV)(D.zG),C=u.map(e=>({key:e.key,label:s(`job_offers.remote_work_types.${(0,L.L6)(e.key)}`),total:e.total})),f=(0,r.useCallback)((e,t)=>{a((0,c.yW)(e.map(e=>e.value),t)),a((0,v.uI)(v.M$.FILTER_CLICK_REMOTE_WORK_TYPES,e)),i&&a((0,I.nD)())},[i,a]),h="remote";return(0,r.useEffect)(()=>{d(h,g)},[g]),r.createElement(t,(0,l.A)({aggregations:C,dataTestId:"cvc-remote-work-types-filter",dispatchFunction:f,filterName:h,icon:_.Ho,label:p,placeholder:m,selectedFields:g},n))});k.displayName="JobOffersRemoteWorkTypeFilterCore";var j=n(81554),z=n(80012),T=n(113),O=n(41289),Q=n(32673),S=n(1961),P=n(82633),B=n(29187),V=n(40285),$=n(36080),F=n(61631);const Z=(0,i.Ay)(p.h_)`
  ${e=>{let{open:t,theme:n}=e;return`\n    transition: all ${n.transitions.duration.short}ms ease;\n    ${t&&"transform: rotateZ(180deg);"}\n  `}}
`,G=i.Ay.button`
  border: 1px solid ${$.c3[200]};
  border-radius: 50px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
  line-height: 20px;
  padding: 8px 16px;
  transition: ${e=>{let{theme:t}=e;return`all ${t.transitions.duration.shorter}ms ease`}};

  ${e=>{let{theme:t}=e;const n=t.palette.background.default,a=t.palette.getContrastText(n);return i.AH`
      color: ${a};
      background-color: ${n};

      & > svg {
        fill: ${a};
      }
    `}}

  &:focus-visible,
  &[data-active="true"] {
    ${e=>{let{theme:t}=e;const n=t.palette.common.white,a=t.palette.getContrastText(n);return i.AH`
        color: ${a};
        background-color: ${n};

        & > svg {
          fill: ${a};
        }
      `}}
  }
`,R=(0,i.Ay)(j.Ay)`
  & > .MuiPaper-root {
    border-radius: 0 0 8px 8px;
    border: 1px solid ${$.c3[200]};
    box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
    margin-top: 4px;
    max-height: 300px;
    min-width: 300px;
  }
`,H=i.Ay.div`
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 4px;
`,U=(0,i.Ay)(p.Li)`
  cursor: pointer;
  display: flex;
  align-items: center;
  border-radius: 4px;
  gap: 8px;
  user-select: none;
  padding: 12px 16px;
  transition: ${e=>{let{theme:t}=e;return`all ${t.transitions.duration.shorter}ms ease`}};

  &:hover {
    background-color: ${e=>{let{theme:t}=e;const n=t.palette.primary.main;return(0,z.X4)(n,.2)}};
  }
`,Y=i.Ay.div`
  font-weight: 500;
`,W=i.Ay.span`
  font-size: 11px;
  line-height: 15px;
`,J=(0,i.Ay)(T.A)`
  height: 20px;
  width: 20px;
  background-color: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,"secondary","main")}};
  cursor: pointer;

  .MuiChip-label {
    display: flex;
    height: 100%;
    align-items: center;
    padding: 0;
    color: ${e=>{let{theme:t}=e;const n=(0,F.x6)(t.palette,"secondary","main");return t.palette.getContrastText(n)}};
  }
`,K=i.Ay.div`
  display: flex;
  align-items: center;
  position: relative;
  overflow: visible;
  padding: 0 8px;
`,X=(0,i.Ay)(O.A)`
  padding: 0;

  & > svg {
    font-size: 1rem;
  }
`,q=i.Ay.div`
  width: 100%;
  padding: 18px 18px 0 18px;
`,ee=(0,r.memo)(e=>{let{option:t,onSelectOption:n,onUnselectOption:a,isOptionSelected:i,style:l}=e;const{label:o,total:s,value:A}=t;return r.createElement(U,{value:A,onClick:()=>{i?a(t):n(t)},style:l},r.createElement(X,{size:"small",checked:i,"aria-selected":i}),r.createElement(Y,null,o),r.createElement(W,null,s))}),te=(0,r.memo)(e=>{let{dataTestId:t,disabled:n,fetchJobOffers:a,icon:i,id:l,includeFilter:o,label:s,onChange:c,options:d,placeholder:m,selectedOptions:u,...g}=e;const[C,f]=(0,r.useState)(null),[h,y]=(0,r.useState)([]),E=(0,A.d7)(),M=(0,r.useRef)(),x=Boolean(C),w=(0,r.useMemo)(()=>(0,P.A)(u,e=>e.value),[u]),D=(0,r.useMemo)(()=>new S.A(d,{threshold:.2,keys:["label"]}),[d]),b=(0,r.useCallback)(()=>{f(null),a(M.current),M.current=!1},[a]);(0,r.useEffect)(()=>(document.addEventListener("scroll",b),()=>document.removeEventListener("scroll",b)),[b]),(0,r.useEffect)(()=>{y(d)},[d]);const L=(0,r.useCallback)(e=>{const t=[...u,e];M.current=!0,c(t,!1)},[c,u]),I=(0,r.useCallback)(e=>{const t=(0,B.A)(u,t=>{let{value:n}=t;return n!==e.value});M.current=!0,c(t,!1)},[c,u]);return r.createElement(K,g,r.createElement(G,{disabled:n,onClick:e=>{f(e.currentTarget)},"data-active":x||!!w.length,"data-testid":t},i&&r.createElement(p.h_,{size:16,View:i}),r.createElement("span",null,s),w.length?r.createElement(J,{"data-testid":`${t}-count`,label:w.length}):null,r.createElement(Z,{View:_.rI,size:16,open:x})),r.createElement(R,{"data-testid":"cvc-contract-types-filter-2022",id:l,open:x,anchorEl:C,onClose:b,disableScrollLock:!0,keepMounted:!0,anchorOrigin:{vertical:"bottom",horizontal:"left"}},o?r.createElement(q,null,r.createElement(Q.A,{fullWidth:!0,id:`${l}-search`,label:m,onChange:e=>{const t=e.target.value;E(()=>(e=>{if(e){const t=D.search(e),n=(0,P.A)(t,e=>{let{item:t}=e;return t});y(n)}else y(d)})(t),500)},size:"small",variant:"outlined"})):null,r.createElement(H,null,h.map((e,t)=>r.createElement(ee,{option:e,key:t,onSelectOption:L,onUnselectOption:I,isOptionSelected:(0,V.A)(w,e.value)})))),r.createElement(p.t$,{id:l?`${l}-input`:void 0,defaultValue:w.join(","),"aria-hidden":"true",tabindex:"-1"}))});ee.displayName="FilterItem",te.displayName="JobOffersFilterView";const ne=(0,i.Ay)(e=>r.createElement(m.go,(0,l.A)({view:te},e)))``,ae=(0,i.Ay)(x.RC)`
  &.swiper {
    // Compensate the padding-left of the Filter Button.
    margin: 0 0 0 -12px;
  }

  .swiper-wrapper {
    display: flex;
  }

  .swiper-slide {
    height: auto;
    width: auto;
    display: flex;
    align-items: center;
    justify-content: center;
  }
`,re={[w.Ou.City]:m.By,[w.Ou.Company]:m.$I,[w.Ou.Country]:m.yV,[w.Ou.JobSector]:m.kV,[w.Ou.RemoteWork]:k},ie=(0,i.Ay)(e=>{const t=(0,A.Ek)(),{config:n}=(0,b._r)(),{i18n:a}=(0,o.Bd)(),i=(0,A.GV)(D.rk),s=(0,A.GV)(D.o_),c=(0,A.tk)(),d=(0,A.qx)(),p=a.language,u=e=>{switch(e.type){case w.Ou.Company:return e.active||!!t.length;case w.Ou.JobSector:return e.active&&(c||d)&&"fr"===p;case w.Ou.RemoteWork:return e.active&&(0,L.Wr)(i);default:return e.active}},g=(0,E.A)((n.filters??[]).map(e=>{if(w.Ko.isCustomFilter(e)){if(!e.request_field)return;const t=n[p]?.serp?.customFiltersTrads?.find(t=>t.key===e.request_field)?.label;if(!t)return;return{component:m.jT,isDisplayed:e.active,props:{filter:e,label:t}}}return{id:`${e.type}-filter`,component:re[e.type],isDisplayed:u(e)}}));return r.createElement(ae,(0,l.A)({keyboard:!0,modules:[M.s3],slidesPerView:"auto"},e),g.map((e,t)=>{let{component:n,id:a,isDisplayed:i,props:o}=e;return i&&r.createElement(x.qr,{key:t},r.createElement(n,(0,l.A)({id:a,view:ne},o)))}),!!s.length&&r.createElement(x.qr,null,r.createElement(m.ob,{id:"contract-filter",view:ne})))})``,le=i.Ay.div`
  width: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    order: 2; // Display filters and map below profile
  }
`,oe=i.Ay.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 16px;
  width: 100%;
  margin: 8px 0px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.mobile}px`}}) {
    margin-top: 0px;
    margin-bottom: 8px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.tablet}px`}}) {
    align-items: flex-start;
  }
`,se=i.Ay.div`
  display: flex;
  align-items: flex-start;
  justify-content: flex-end;
  margin-top: 16px;
  width: 100%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.mobile}px`}}) {
    align-items: stretch;
    flex-direction: column;
  }
`,Ae=e=>{let{id:t}=e;return r.createElement(le,null,r.createElement(oe,{id:t},r.createElement(ie,null),r.createElement(y.Q,null)),r.createElement(se,null,r.createElement(h,null)))};var ce=n(38544),de=n(25044),pe=n(63466),me=n(83992),ue=n(23099),ge=n(33131),Ce=n(24586),fe=n(76902),he=n(42853),ye=n(43322),Ee=n(47056),Me=n(45193),xe=n(63878),we=n(32279),De=n(68756),be=n(83878),Le=n(71716),_e=n(26270);const Ie="mapViewport",ve=e=>{const t=e.getCenter(),n=e.getZoom();return`${t.lat},${t.lng},${n}`},Ne=(e,t)=>{const n=t.map(t=>{try{const n=t.coordinates.split(",");return{...t,isVisible:e.getBounds().contains({lat:n[0],lng:n[1]})}}catch(e){return t}});return((e,t)=>{const n=[],a=[];return t.forEach(e=>{e.isVisible?n.push(e):a.push(e)}),n.sort((t,n)=>{try{const a=e.getCenter(),r=t.coordinates.split(","),i=n.coordinates.split(",");return Math.sqrt(Math.pow(a.lat-r[0],2)+Math.pow(a.lng-r[1],2))-Math.sqrt(Math.pow(a.lat-i[0],2)+Math.pow(a.lng-i[1],2))}catch(e){return 0}}).concat(a)})(e,n)},ke="mapListScroll",je=e=>{const t=new URL(window.location.href);t.searchParams.set(ke,String(e||0)),window.history.replaceState(null,null,t)};var ze=n(39067),Te=n.n(ze),Oe=n(40931),Qe=n(96138),Se=n(18136),Pe=n(61501),Be=n(63511),Ve=n(33664),$e=n(85426),Fe=n.n($e),Ze=n(5369),Ge=n(8049);const Re={id:Te().string.isRequired,index:Te().number.isRequired,trackingCallback:Te().func.isRequired,partner:Te().string.isRequired,dataTestDomLocation:Te().string.isRequired},He=e=>{let{children:t,id:n,index:a,trackingCallback:i,partner:l,dataTestDomLocation:o}=e;const{config:s}=(0,r.useContext)(Ze.Qj),A=(0,ce.wA)(),c=v.M$.SEE_JOB_OFFER_DETAILS_PAGE,d=(0,ce.d4)(e=>e.search.pageOffersRange).firstOfferPosition+a,p=(0,ce.d4)(e=>e.jobOffers)[n];return r.createElement(Ve.N_,{"data-testid":"cvc-job-offer-internal-redirection","data-test-advertiser":l,"data-test-position":`cvc-job-offer-${d}`,"data-test-dom-location":o,to:(0,Ge.X2)(window.location,n),onClick:()=>{i(),s.analytics?.google_tag_manager?.active&&Fe().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Results Job Offer With Internal Redirection",EventAction:"Voir details offre",EventLibelle:"[RP] - Lire la suite"}}),(0,ue.oU)("product.click",{product_data:[(0,ue.h6)(p,d)]}),A((0,v.Iy)(c,n,(0,Be.Dq)(o),d))}},t)};He.propTypes=Re;var Ue=n(40132),Ye=n(26532),We=n.n(Ye);const Je=i.Ay.a`
  display: block;
  position: relative;
`,Ke=()=>(0,be.Mz)(e=>e.jobOffers,(e,t)=>t,(e,t)=>e[t]&&e[t].link),Xe=()=>(0,be.Mz)(e=>e.jobOffers,(e,t)=>t,(e,t)=>e[t]&&e[t].reference),qe=e=>{let{children:t,id:n,index:a,trackingCallback:i,partner:l,dataTestDomLocation:o}=e;const{config:c}=(0,r.useContext)(Ze.Qj),d=(0,ce.wA)(),p=(0,r.useMemo)(Ke,[]),m=(0,r.useMemo)(Xe,[]),u=(0,ce.d4)(e=>p(e,n)),g=(0,s.zy)(),C=(0,ce.d4)(e=>m(e,n)),f=r.createRef(),h=v.M$.SEE_JOB_OFFER_DETAILS_REDIRECT,y=(0,ce.d4)(e=>e.search.pageOffersRange).firstOfferPosition+a;let E=u;c.features?.forward_query_params_to_job_offer_link&&(E=((e,t)=>{const n=new URLSearchParams(t.search),a=new URL(e),r=new URLSearchParams(a.search);return n.has("from")&&r.append("from",n.get("from")),n.has("id_candidat")&&r.append("id_candidat",n.get("id_candidat")),a.search=r.toString(),a.toString()})(u,g));const M=(0,A.GV)(e=>(0,D.Cp)(e,n));return r.createElement(Je,{"data-test-advertiser":l,"data-test-position":`cvc-job-offer-${y}`,"data-testid":"cvc-job-offer-external-redirection","data-test-dom-location":o,target:"_blank",rel:"noopener noreferrer",href:E,ref:f,onClick:()=>{i(),c.analytics?.google_tag_manager?.active&&Fe().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Results Job Offer With External Redirection",EventAction:"Voir details offre",EventLibelle:"[RP] - Lire la suite"}}),!0===c.analytics?.at_internet&&((e,t)=>{Ue.A.sendClick({elem:e.current,name:t,chapter1:"cv_catcher",chapter2:"parcours_web",level2:"Recrutement",type:"navigation"})})(f,C),d((0,v.Iy)(h,n,(0,Be.Dq)(o),y));const e={transaction_id:We()(),product_data:[(0,ue.h6)(M)]};(0,ue.oU)("product.purchased",e)}},t)};qe.propTypes=Re;var et=n(7398);const tt=i.Ay.div`
  width: 100%;
`,nt=e=>{let{id:t,index:n,trackingCallback:a,partner:i,dataTestDomLocation:l,children:o}=e;const s=(0,ce.wA)(),{config:A}=(0,r.useContext)(b.Qj),{workflow:c}=(0,et._Z)(A,i),d=(0,ce.d4)(e=>e.search.pageOffersRange),p={partner:i,dataTestDomLocation:l,id:t,index:n,trackingCallback:a};let m;return m=c===w.Yn.DETAILS_REDIRECTION||c===w.Yn.IN_APP?r.createElement(He,p,o):r.createElement(qe,p,o),r.createElement(tt,{onClick:()=>{const e=d.firstOfferPosition+n;s((0,_e.XV)(e))}},m)};nt.propTypes=Re;const at=()=>(0,be.Mz)(e=>e.jobOffers,(e,t)=>t,(e,t)=>({id:t,title:e[t].title,localities:e[t].localities,contractType:e[t].contract_type,remoteWorkType:e[t].remote_work_type,partner:e[t].partner})),rt=e=>{let{id:t,index:n}=e;const{t:a,i18n:i}=(0,o.Bd)(),{config:l}=(0,b._r)(),s=(0,r.useMemo)(at,[]),A=(0,ce.d4)(e=>s(e,t)),{remoteWorkType:c}=A,d=(0,ce.wA)(),p=(0,xe.ko)(),m=(0,Pe.r9)(A),u=m?.coordinates||null,g=m?.city_label||null,C=(e=>{let t="";return e&&e.length>0&&(t+=" - ",t+=e.map((t,n)=>n===e.length-1?`${t}`:`${t} • `).join("")),t})(A.contractType),f=new fe.DivIcon({className:"cc-map-marker-icon-wrapper",html:Oe.renderToStaticMarkup((h=A.partner,r.createElement("div",{"data-testid":"cvc-map-marker-icon","data-test-advertiser":h,"data-test-dom-location":"cvc-job-offer-results-map",className:"cc-map-marker-icon"},"1"))),iconSize:[30,30],popupAnchor:[0,-15]});var h;return u?r.createElement(Qe.p,{position:u.split(","),icon:f,eventHandlers:{click:e=>{e?.latlng?.lat&&e?.latlng?.lng&&p.setView([e.latlng.lat,e.latlng.lng])}}},r.createElement(Se.z,{className:"cc-leaflet-popup-container",maxWidth:250,autoPan:!1},r.createElement("div",{className:"cc-leaflet-popup-title"},A.title),r.createElement("div",{className:"cc-leaflet-popup-subtitle"},g,C,(0,L.zl)(c,l)&&` - ${(0,L._6)(c,i.language)}`),r.createElement(nt,{id:A.id,index:n,dataTestDomLocation:"cvc-job-offer-map-markers",partner:A.partner,trackingCallback:()=>(e=>{d((0,v.Iy)(v.M$.JOB_REDIRECTIONS,e,Be.Et))})(A.id)},r.createElement("span",{"data-testid":"cvc-btn-redirection-from-map",id:"redirection-from-map",className:"cc-leaflet-popup-link"},a("job_offers.button"))))):r.createElement(r.Fragment,null)};rt.propTypes={jobOffer:Te().shape({contract_type:Te().arrayOf(Te().string),id:Te().string.isRequired,localities:Te().arrayOf(Te().shape({coordinates:Te().string})),title:Te().string.isRequired,partner:Te().string.isRequired})};var it=n(80503),lt=n(56415);const ot=i.Ay.div`
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  z-index: 2;
  background-color: rgba(220, 220, 220, 0.3);
  background-size: cover;
  display: flex;
  align-items: center;
  justify-content: center;
`,st=()=>{const e=(0,ce.d4)(e=>e.jobOffersMapMarkers.isFetching);return r.createElement(it.A,{in:e,timeout:0,classNames:"cc-toggle-fade",mountOnEnter:!0,unmountOnExit:!0},r.createElement(ot,null,r.createElement(lt.A,null)))},At=i.Ay.div`
  position: relative;
  height: 100%;
  z-index: 1;
  transition: filter 300ms ease;
  ${e=>{let{isFetching:t}=e;return t&&"filter: blur(3px);"}}
`,ct=(0,i.Ay)(Me.W)`
  height: inherit;
  .leaflet-control-zoom {
    background-color: white;
  }

  .cc-leaflet-popup-container {
    .leaflet-popup-content-wrapper {
      border-radius: 2px;

      .leaflet-popup-content {
        font-family: var(--map-popup-content-font);

        .cc-leaflet-popup-title {
          margin-bottom: 5px;
          font-size: 16px;
          font-weight: 600;
        }

        .cc-leaflet-popup-subtitle {
          margin-bottom: 10px;
          color: #666;
          font-size: 14px;
          font-weight: 600;
        }

        .cc-leaflet-popup-link {
          color: var(--primary-color);
          font-size: 14px;

          &:hover {
            text-decoration: underline !important;
          }

          &:visited {
            filter: brightness(80%);
          }
        }
      }
    }
  }

  .cc-marker-cluster {
    display: flex;
    align-items: center;
    justify-content: center;
    background-clip: padding-box;
    font-family: var(--primary-font);

    > div {
      transition: 200ms ease all;
    }

    &.cc-marker-cluster-small,
    &.cc-marker-cluster-medium,
    &.cc-marker-cluster-large {
      background-color: rgba(115, 115, 115, 0.5);

      > div {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        font-weight: 500;
        color: white;
        background-color: var(--primary-color);

        &:hover {
          transform: scale(1.4);
        }
      }
    }

    &.cc-marker-cluster-small {
      border-radius: 20px;

      > div {
        width: 30px;
        height: 30px;
        border-radius: 15px;
      }
    }

    &.cc-marker-cluster-medium {
      border-radius: 25px;

      > div {
        width: 40px;
        height: 40px;
        border-radius: 20px;
      }
    }

    &.cc-marker-cluster-large {
      border-radius: 30px;

      > div {
        width: 50px;
        height: 50px;
        border-radius: 25px;
      }
    }
  }

  .cc-map-marker-icon-wrapper {
    .cc-map-marker-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 30px;
      width: 30px;
      font-family: var(--primary-font);
      font-size: 14px;
      font-weight: 500;
      background-color: var(--primary-color);
      color: white;
      border-radius: 15px;
      transition: 200ms ease all;

      &:hover {
        background-color: var(--primary-color);
        filter: brightness(0.8);
      }
    }
  }

  .cc-fixed-container {
    position: fixed;
    bottom: 0;
    z-index: 999999999;
    height: 100%;
    width: 100%;
    background-color: #ffffff;

    .cc-content-wrapper {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .cc-button-wrapper {
      background-color: var(--primary-color);
    }
  }
`,dt=(0,be.Mz)(e=>e.jobOffersMapMarkers,e=>({list:e.list,isUpdatingList:e.isUpdatingList}));function pt(){const e=(0,ce.wA)(),t=(0,A.d7)(),{list:n,isUpdatingList:a}=(0,A.GV)(dt),r=(0,A.GV)(D.Fy),i=(n,a)=>{(e=>{const t=new URL(window.location.href);t.searchParams.set(Ie,ve(e)),window.history.replaceState(null,null,t)})(n);const r=Ne(n,a);(0,he.A)(a,r)||(je(0),e((0,_e.Fq)()),t(()=>{e((0,_e.NO)(r))},1e3))},l=(0,xe.Po)({move:()=>{r&&!a&&t(()=>{i(l,n)},250)}});return null}class mt extends r.Component{constructor(e){super(e),(0,Ce.A)(this,"mapDidMount",e=>{let{target:t}=e;const{isFetching:n,isMatching:a}=this.props;if(this.setState({mapInstance:t}),new URL(window.location.href).searchParams.has(Ie)){const e=(()=>{const e=new URL(window.location.href).searchParams.get(Ie),[t,n,a]=e.split(",");return{coordinates:{lat:t,lng:n},zoom:a}})();t.setView(e.coordinates,e.zoom)}else n||a||!this.props.jobOffersList.length||this.computeAndFitViewBounds(t,this.props.jobOffersList);Ee.xl||t.attributionControl.setPosition("topright")}),(0,Ce.A)(this,"populatePartners",()=>{for(const e of Object.values(this.props.jobOffers))this.e2ePartners.includes(e.partner)||this.e2ePartners.push(e.partner)}),(0,Ce.A)(this,"computeAndFitViewBounds",(e,t)=>{const n=[];t.forEach(e=>{e.coordinates&&e.isVisible&&n.push(e.coordinates.split(",").map(Number))}),n.length>0&&e.fitBounds(n,{maxZoom:11,padding:[20,20]})}),(0,Ce.A)(this,"createClusterCustomIcon",e=>{const t=this.e2ePartners,n=this.e2eClustersId,a=e.getChildCount(),r=e._leaflet_id;let i=[];if(this.isBrowserAutomated)if(t.length>1){const l=n.find(e=>e.id===r);if(void 0===l){const l=e.getAllChildMarkers();let o=0;for(;o<a&&i.length!==t.length;){const e=l[o].options.children.props.children[2].props.partner;i.includes(e)||i.push(e),o++}n.push({id:r,advertisers:i})}else i=(0,ye.A)(l.advertisers)}else i=(0,ye.A)(t);let l,o=" cc-marker-cluster-";a<10?(o+="small",l=40):a<100?(o+="medium",l=50):(o+="large",l=60);const s=i.join(" ");return new fe.DivIcon({html:'<div data-testid="cvc-marker-cluster" data-test-dom-location="cvc-job-offer-results-map" data-test-advertisers="'+s+'"><span>'+a+"</span></div>",className:"cc-marker-cluster"+o,iconSize:new fe.Point(l,l)})}),this.e2ePartners=[],this.e2eClustersId=[],this.isBrowserAutomated=!!navigator.webdriver,this.state={mapInstance:null}}componentDidMount(){this.props.toggleMapIsMounted(!0),this.isBrowserAutomated&&this.populatePartners(),this.props.jobOffersList.length&&this.props.jobOffersList.length===this.props.searchResultsCount||this.props.getJobOffersMapMarkers()}shouldComponentUpdate(e,t){const{isFetching:n,isMatching:a}=e,{isFetching:r,isMatching:i}=this.props,{mapInstance:l}=t,{mapInstance:o}=this.state;return r!==n||i!==a||null===o&&l}componentDidUpdate(e){const{mapInstance:t}=this.state;if(this.isBrowserAutomated&&this.populatePartners(),t&&!(0,he.A)(e.jobOffersListIds,this.props.jobOffersListIds)){this.props.jobOffersList.length&&this.computeAndFitViewBounds(t,this.props.jobOffersList);const e=Ne(t,this.props.jobOffersList);this.props.updateJobOffersVisibility(e)}}componentWillUnmount(){this.props.toggleMapIsMounted(!1)}render(){const{jobOffersList:e,isFetching:t}=this.props,{mapInstance:n}=this.state,a=!this.isBrowserAutomated;return r.createElement(r.Fragment,null,r.createElement(At,{isFetching:t,"data-testid":"cvc-job-offers-map-wrapper"},r.createElement(ct,{zoom:2,center:[0,0],whenReady:this.mapDidMount,zoomControl:a,maxZoom:13},r.createElement(pt,null),r.createElement(we.e,{attribution:'Maps © <a href="https://www.maptiler.com">Maptiler</a>, Data © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>',url:"https://api.maptiler.com/maps/streets/256/{z}/{x}/{y}@2x.png?key=amFwVxgziMyjBirmgTpe"}),n&&r.createElement(De.A,{chunkedLoading:!0,showCoverageOnHover:!1,removeOutsideVisibleBounds:!0,iconCreateFunction:this.createClusterCustomIcon,zoomToBoundsOnClick:!1,spiderfyOnMaxZoom:!1,onClick:e=>{e.layer.zoomToBounds({padding:[40,40]})}},e.map((e,t)=>r.createElement(rt,{key:e.id,id:e.id,index:t}))))),r.createElement(st,null))}}(0,Ce.A)(mt,"contextType",b.Qj);const ut=(0,ce.Ng)(e=>({isMatching:e.isMatching,isFetching:e.jobOffersMapMarkers.isFetching,jobOffersList:e.jobOffersMapMarkers.list,jobOffersListIds:e.jobOffersMapMarkers.list.map(e=>e.id),jobOffers:e.jobOffers,searchResultsCount:e.search.total}),e=>({getJobOffersMapMarkers:()=>{e((0,Le.u9)())},updateJobOffersVisibility:t=>{e((0,_e.NO)(t))},toggleMapIsMounted:t=>{e((0,me.Hw)(t))}}))(mt);var gt=n(66576),Ct=n(37028),ft=n(83205),ht=n.n(ft),yt=n(70130),Et=n(33106),Mt=n(30534),xt=n(20385);const wt=e=>{let{remoteWorkType:t,view:n}=e;const{i18n:a}=(0,o.Bd)();return r.createElement(n,{text:(0,L._6)(t,a.language)})};wt.propTypes={remoteWorkType:Te().string};var Dt=n(47132),bt=n(93368),Lt=n(52519);const _t=i.Ay.div`
  background-color: white;
  padding: 32px;
  margin-bottom: 24px;
  border-radius: 5px;
  overflow: auto;

  ${p.wv} {
    margin-top: 12px;
    margin-bottom: 18px;
  }

  ${e=>{let{alreadyApplied:t,theme:n}=e;return`\n    box-shadow: ${n.shadows[2]};\n    transition: all ${n.transitions.duration.short}ms ease;\n    border-left: ${t?`6px solid ${n.palette.success.light}`:"none"};\n\n    &:hover {\n      box-shadow: ${n.shadows[8]};\n    }\n\n    @media (max-width: ${n.breakpoints.mobile}px) {\n      padding: 32px 16px;\n    }\n  `}}
`,It=(0,i.Ay)(p.fz)`
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: normal;
  max-width: 80vw;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
`,vt=(0,i.Ay)(Mt.h)`
  margin: 0px;
  font-size: 1.188rem;
`,Nt=i.Ay.div`
  display: flex;
  flex-wrap: nowrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px 0;
  margin-bottom: 20px;

  ${e=>{let{theme:t}=e;return`\n    @media (max-width: ${t.breakpoints.tablet}px) {\n      flex-direction: column;\n\n      ${Ot} {\n        margin-bottom: 16px;\n      }\n    }\n  `}}
`,kt=i.Ay.div`
  display: flex;
  align-items: flex-start;
  gap: 16px;
  flex: 1;

  ${e=>{let{theme:t}=e;return`\n    @media (max-width: ${t.breakpoints.laptop}px) {\n      flex-wrap: wrap;\n    }\n  `}}
`,jt=i.Ay.div`
  display: flex;
  flex-wrap: nowrap;
  gap: 16px;
  justify-content: space-between;
  align-items: flex-start;
  ${e=>{let{theme:t}=e;return`\n    @media (max-width: ${t.breakpoints.mobile}px) {\n      flex-direction: column;\n    }\n  `}}
`,zt=i.Ay.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  flex: 1;
`,Tt=i.Ay.span`
  display: flex;
  font-size: 0.875rem;
  align-items: center;
  margin-top: 8px;
  svg {
    margin-right: 4px;
  }

  ${e=>{let{theme:t}=e;return`\n    color: ${t.palette.success.light} !important;\n    fill: ${t.palette.success.light} !important;\n  `}}
`,Ot=i.Ay.div`
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  padding-right: 24px;

  ${e=>{let{theme:t}=e;return`\n    @media (max-width: ${t.breakpoints.tablet}px) {\n      flex-direction: column;\n      align-items: flex-start;\n\n      ${Tt} {\n        margin-top: 8px;\n        margin-left: 0px;\n      }\n    }\n  `}}
`,Qt=(0,i.Ay)(bt.w)`
  ${e=>{let{theme:t}=e;return`\n    &:hover, &:focus, &:active {\n      filter: brightness(85%);\n      background-color: ${t.palette.primary.main}; \n    }\n  `}}
`,St=(0,i.Ay)(p.vw)`
  white-space: nowrap;
`,Pt=e=>{let{title:t,alreadyApplied:n}=e;const{t:a}=(0,o.Bd)();return r.createElement(Ot,null,r.createElement(vt,{variant:"h2"},t),n&&r.createElement(Tt,null,r.createElement(ge.A,{View:_._$,size:20})," ",a("application.application_succeeded")))},Bt=e=>{let{text:t}=e;return r.createElement(St,{mode:"secondary"},r.createElement(ge.A,{View:_.ft,size:16}),r.createElement("span",null,t))},Vt=e=>{let{text:t}=e;return r.createElement(St,{mode:"secondary"},r.createElement(ge.A,{View:_.nR,size:16}),r.createElement("span",null,t))},$t=e=>{let{text:t}=e;return r.createElement(St,{mode:"secondary"},r.createElement(ge.A,{View:_.Ho,size:16}),r.createElement("span",null,t))},Ft=e=>{let{jobOffer:t}=e;const{config:n}=(0,b._r)();return Pe.wl.getCustomFilters(n).map((e,n)=>{const a=(0,xt.A)(t,e.response_field);return a&&r.createElement(St,{key:n,mode:"secondary"},r.createElement(ge.A,{View:_.cD,size:16}),r.createElement("span",null,a))})},Zt=e=>{let{company:t}=e;const n=!!(0,A.Ek)().length;return t&&n?r.createElement(St,{mode:"secondary"},r.createElement(ge.A,{View:_.A9,size:16}),r.createElement("span",null,t)):null},Gt=e=>{let{salary:t}=e;const n=(0,A.ii)()(t);return n?r.createElement(St,{mode:"secondary"},r.createElement(ge.A,{View:_.UT,size:16}),r.createElement("span",null,n)):null},Rt=e=>{let{isoDate:t}=e;const{config:n}=(0,b._r)(),{i18n:a}=(0,o.Bd)(),i=n.features.display_job_offer_publication_date,l=(0,Dt.JJ)(a.language),s=(0,r.useMemo)(()=>(0,et.Yq)(t,a.language,l),[l,a.language,t]);return i?r.createElement(St,{mode:"secondary"},r.createElement("span",null,s)):null},Ht=(0,r.memo)(e=>{let{id:t,index:n,trackingCallback:a,jobOffer:i,alreadyApplied:l=!1,showJobOfferDescription:s=!0,dataTestDomLocation:A}=e;const{config:c}=(0,b._r)(),{t:d}=(0,o.Bd)();return r.createElement(nt,{id:t,index:n,trackingCallback:a,partner:i.partner,dataTestDomLocation:A},r.createElement(_t,{alreadyApplied:l},r.createElement(Nt,null,r.createElement(kt,null,i.company_logo_url&&r.createElement(Lt.X,{src:i.company_logo_url,alt:"Entity logo"}),r.createElement(Pt,{title:i.title,alreadyApplied:l})),r.createElement(Rt,{isoDate:i.publication_date})),s&&r.createElement(r.Fragment,null,r.createElement(It,null,c.features.use_split_description_fields?i.mission_description:i.description),r.createElement(p.wv,null)),r.createElement(jt,null,r.createElement(zt,null,r.createElement(m.sK,{offer:i,view:Bt}),r.createElement(m.Pz,{view:Vt,contractTypes:i.contract_type}),(0,L.zl)(i.remote_work_type,c)&&r.createElement(wt,{view:$t,remoteWorkType:i.remote_work_type}),r.createElement(Gt,{salary:i.salary}),r.createElement(Ft,{jobOffer:i}),r.createElement(Zt,{company:i.company})),r.createElement(Qt,null,d("job_offers.button")))))}),Ut=(0,r.memo)(e=>{let{id:t,index:n,showJobOfferDescription:a,dataTestDomLocation:i}=e;return r.createElement(m.fg,{view:Ht,id:t,index:n,showJobOfferDescription:a,dataTestDomLocation:i})});Ht.displayName="JobOffersListItemView",Ut.displayName="JobOffersListItem";var Yt=n(35057);const Wt=(0,i.Ay)(p.EA)`
  // Make sure the skeleton's height is around the same as the job offer item.
  height: ${e=>{let{tiny:t}=e;return t?"176px":"246px"}};
  margin-bottom: 24px;
`,Jt=e=>{let{tiny:t=!1}=e;const n=(0,ce.d4)(e=>e.search.total||0),a=0===n?1:n>10?10:n;return r.createElement(r.Fragment,null,(0,Yt.A)(a).map(e=>r.createElement(Wt,{key:e,tiny:t})))},Kt=i.Ay.div`
  height: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    height: calc(100% + 10vh);
    margin-top: -10vh;
  }
`,Xt=i.Ay.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  margin-bottom: 24px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    display: none;
  }
`,qt=i.Ay.img`
  display: block;
  height: auto;
  max-width: 128px;
  max-height: 80px;
  object-fit: contain;
`,en=i.Ay.div`
  display: block;
  width: 2px;
  height: 30px;
  border-radius: 4px;
  background-color: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,F.ll,F.Xs)}};
  margin: auto 16px;
`,tn=i.Ay.div`
  height: calc(100% - 64px);
  border-radius: 5px;
  overflow: hidden;

  .simplebar-track {
    border-radius: 7px;
    background-color: rgba(0, 0, 0, 0.05);

    &.simplebar-vertical {
      visibility: ${e=>{let{showScrollbar:t}=e;return t?"visible":"hidden"}} !important;
      height: calc(100% - 64px);

      ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
        height: calc(100% - 24px);
      }
    }
  }

  .simplebar-scrollbar::before {
    background-color: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,F.ll,F.Xs)}};
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    height: 100%;
  }
`,nn=i.i7`
  0% {
    transform: rotate(0deg);
  }
  10% {
    transform: rotate(190deg);
  }
  20% {
    transform: rotate(180deg);
  }
  30% {
    transform: rotate(210deg);
  }
  50% {
    transform: rotate(90deg);
  }
  100% {
    transform: rotate(-45deg);
  }`,an=i.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  background-color: #ffffff;
  padding: 32px;
  border-radius: 5px;
  box-shadow: ${e=>{let{theme:t}=e;return t.shadows[2]}};

  svg {
    display: block;
    animation: ${nn} 2s infinite ease;
    margin-bottom: 24px;
    fill: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,F.ll,F.Xs)}};
  }

  strong {
    font-size: 20px;
  }

  p {
    size: 16px;
    white-space: pre-line;
    margin: 0;
    margin-top: 8px;
    line-height: 28.51px;
  }
`,rn=i.Ay.p`
  font-size: 1rem;
  margin: 0 0 0 auto;
  font-weight: bold;
  color: ${e=>{let{theme:t}=e;const n=t.palette.secondary.main,a=(0,F.x6)(t.palette,F.o1,F.Xs);return(0,F.PM)(a,n,t.palette.contrastThreshold)}};
`,ln=(0,be.Mz)(D.HG,e=>({visibleJobOffers:on(e.list),isUpdatingList:e.isUpdatingList,isFetching:e.isFetching})),on=e=>{try{return e.filter(e=>e.isVisible)}catch(e){return[]}},sn=(0,r.memo)(()=>{const e=(0,r.useRef)(null),{config:t}=(0,b._r)(),{t:n}=(0,o.Bd)(),{visibleJobOffers:a,isUpdatingList:i,isFetching:l}=(0,A.GV)(ln),s=(0,A.GV)(D.qP),c=(()=>{try{const e=new URL(window.location.href);return Number(e.searchParams.get(ke))||0}catch(e){return 0}})(),d=s||l||i;return(0,r.useEffect)(()=>{e.current&&e.current.addEventListener("scroll",(0,Ct.A)(e=>{e.target&&je(e.target.scrollTop)},250))},[e]),r.createElement(Kt,null,r.createElement(Xt,null,r.createElement(qt,{src:(0,Et.y4)(t),alt:n("seo_markup.career_site_home_page.title",{clientName:t.company_name})}),r.createElement(en,null),r.createElement(Mt.h,{autoContrast:!0,variant:"h3",noMargin:!0},n("map.title")),r.createElement(rn,null,n("map.count",{postProcess:"interval",count:a.length}))),r.createElement(tn,{showScrollbar:!!a.length||i},r.createElement(yt.A,{"data-testid":"cvc-job-offer-map-list",style:{height:"100%",paddingRight:Ee.xl&&(a.length||i)?35:0},autoHide:!1,scrollableNodeProps:{ref:e}},d?r.createElement(gt.A,{in:!0},r.createElement("div",null,r.createElement(Jt,{tiny:!0}))):a.length?r.createElement(ht(),{viewportRef:e,items:a,initialIndex:0,initialOffset:c},(e,t)=>r.createElement(gt.A,{in:!0,key:e.id},r.createElement("div",null,r.createElement(Ut,{id:e.id,index:t,showJobOfferDescription:!1,dataTestDomLocation:"cvc-job-offer-map-list"})))):r.createElement(gt.A,{in:!0},r.createElement(an,null,r.createElement(ge.A,{View:_.wh,size:48}),r.createElement(p.o5,{variant:"strong",autoContrast:!0},n("map.empty_zone.title")),r.createElement(p.o5,{autoContrast:!0},n("map.empty_zone.text")))))))});sn.displayName="JobOffersList";const An=i.DU`
  html {
    overflow: ${e=>{let{isMapDisplayed:t}=e;return t?"hidden":"auto"}};;
  }
`,cn=i.Ay.div`
  position: fixed;
  z-index: 3;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  display: flex;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}}) {
    flex-direction: column;
  }
`,dn=i.Ay.div`
  position: relative;
  width: 40%;
  min-width: 600px;
  height: 100%;
  background-color: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,F.o1,F.qf)}};
  padding: 32px 32px 0 32px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}}) {
    width: 100%;
    height: 45%;
    min-width: initial;
    order: 2;
    padding: 16px 16px 0 16px;
    z-index: 2;
  }
`,pn=i.Ay.div`
  position: relative;
  width: 60%;
  height: 100%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}}) {
    width: 100%;
    height: 55%;
    order: 1;
  }
`,mn=i.Ay.button`
  position: absolute;
  z-index: 2;
  top: 24px;
  right: 24px;
  background-color: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,F.Fl,F.Xs)}};
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  width: 38px;
  height: 38px;
  border: 2px solid ${F.QZ};
  cursor: pointer;
`,un=e=>{let{onClick:t,...n}=e;return r.createElement(mn,(0,l.A)({onClick:t},n),r.createElement(ge.A,{View:_.MR,size:24,withContrast:!0}))},gn=()=>(0,ce.d4)(e=>e.jobOffers)?r.createElement(ut,null):null,Cn=()=>{const{config:e}=(0,b._r)(),t=(0,ce.wA)(),n=(0,A.GV)(D.Fy),a=(0,A.GV)(D.Ut),i=()=>{t((0,me.hW)(!n))};return(0,r.useEffect)(()=>{n&&(0,ue.oU)("page.display",{page_category:"List",page_subject:"Offer",page_type:"LO-Map",page_hostname:window.location.hostname,site_name:e.company_name,search_remote:a.remote_work_types?.map(e=>e.split("/").pop()).join("|")})},[n]),r.createElement(r.Fragment,null,r.createElement(m.OJ,{view:u.R2,onClick:i,isMapDisplayed:n}),r.createElement(pe.A,{in:n,direction:"left",appear:!1,mountOnEnter:!0},r.createElement(cn,null,r.createElement(An,{isMapDisplayed:n}),r.createElement(m.OJ,{view:un,onClick:i,isMapDisplayed:n}),r.createElement(dn,null,r.createElement(sn,null)),r.createElement(pn,null,r.createElement(gn,null)))))},fn=(0,i.Ay)(p.o5)`
  font-size: 20px;
  font-weight: 700;
  margin: 0;
`,hn=e=>{let{i18nKey:t}=e;const{t:n}=(0,o.Bd)(),a=(0,A.GV)(D.bl);return r.createElement(r.Fragment,null,r.createElement("span",{hidden:!0,"data-testid":"cvc-job-total-number-offers"},a),r.createElement(fn,{autoContrast:!0},n(t,{postProcess:"interval",count:a,nbOffers:a})))},yn=i.Ay.div`
  display: flex;
  height: 48px;
  align-items: center;
  justify-content: center;
  gap: 16px;
  font-size: 19px;
  font-weight: 700;
  margin-bottom: 32px;
  padding: 0;

  svg {
    min-width: 48px;
  }
`,En=i.Ay.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    width: 100%;
    justify-content: flex-end;
  }
`,Mn=i.Ay.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 16px;
  gap: 24px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    flex-direction: column;
    font-size: 16px;
    gap: 16px;
    align-items: flex-start;
    word-wrap: break-word;
    overflow-wrap: break-word;
    white-space: normal;
  }
`,xn=(0,r.memo)(e=>{let{isFetching:t}=e;const{t:n}=(0,o.Bd)(),a=(0,ce.d4)(e=>e.search.results||[]),l=(0,i.DP)(),{config:s}=(0,b._r)(),c=(0,A.GV)(D.vH),d=(0,de.g)(c,s.features?.display_job_offers_maps);return r.createElement(r.Fragment,null,t?r.createElement(Jt,null):r.createElement(r.Fragment,null,0===a.length?r.createElement(yn,null,r.createElement(p.h_,{View:_.Eg,mode:"primary",theme:l,size:48}),r.createElement(p.o5,null,n("result_page.no_results"))):r.createElement(r.Fragment,null,r.createElement(Mn,null,r.createElement(m.GI,{view:hn}),d&&r.createElement(En,null,r.createElement(Cn,null))),a.map((e,t)=>r.createElement(Ut,{id:e,index:t,key:e,dataTestDomLocation:"cvc-job-offer-results-list"})))))});xn.displayName="JobOffersListView";const wn=()=>r.createElement(m.CQ,{view:xn});var Dn=n(70488),bn=n.n(Dn);const Ln=i.AH`
  ${e=>{let{theme:t}=e;return`\n    font-size: 1rem;\n    font-weight: 600;\n    border: 1px solid ${t.palette.primary.main};\n    border-radius: 50%;\n    color: ${t.palette.primary.main};\n    cursor: pointer;\n    user-select: none;\n    width: 2.5rem;\n    height: 2.5rem;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    transition: all ${t.transitions.duration.short}ms ease;\n\n    svg {\n      fill: ${t.palette.primary.main};\n    }\n  \n    &:hover {\n      background-color: ${t.palette.primary.main};\n      color: ${(0,F.Vh)(t.palette.primary.main,t.palette)};\n      \n      svg {\n        fill: ${(0,F.Vh)(t.palette.primary.main,t.palette)};\n      }\n    }\n  `}}
`,_n=i.Ay.div`
  margin: 1em 0;

  .page-link,
  .cvcatcher-arrow,
  .break-link {
    ${Ln};
  }

  &,
  .cvc-pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin: 0;
  }

  .cvc-pagination {
    padding: 0;
  }

  li {
    list-style: none;
  }

  .active-link {
    background-color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
    color: ${e=>{let{theme:t}=e;return(0,F.Vh)(t.palette.primary.main,t.palette)}};
  }

  .disabled {
    display: none;
  }
`,In=e=>{let{currentPage:t,onPageChange:n,pageCount:a,...i}=e;const l=1===t,o=t===a;return r.createElement(_n,i,r.createElement("button",{className:`${l&&"disabled"} cvcatcher-arrow`,"data-testid":"cvc-job-offers-pagination-first",onClick:()=>n({selected:0})},r.createElement(ge.A,{View:_.Bp,size:24})),r.createElement(bn(),{previousLabel:r.createElement(ge.A,{View:_.gu,size:24}),nextLabel:r.createElement(ge.A,{View:_.Vj,size:24}),selectedPageRel:null,pageCount:a,marginPagesDisplayed:0,pageRangeDisplayed:Ee.Fr?1:3,forcePage:t-1,disableInitialCallback:!0,onPageChange:n,hrefBuilder:Ge.M_,containerClassName:"cvc-pagination",pageLinkClassName:"page-link",previousLinkClassName:"cvcatcher-arrow cvcatcher-pagination-prev",nextLinkClassName:"cvcatcher-arrow cvcatcher-pagination-next",breakLinkClassName:"break-link",activeLinkClassName:"active-link",breakLabel:!1}),r.createElement("button",{className:`${o&&"disabled"} cvcatcher-arrow`,"data-testid":"cvc-job-offers-pagination-last",onClick:()=>n({selected:a-1})},r.createElement(ge.A,{View:_.B1,size:24})))},vn=e=>r.createElement(m.O2,(0,l.A)({view:In},e));var Nn=n(97134),kn=n(35133),jn=n(29285),zn=n(37529),Tn=n(95600),On=n(47566),Qn=n(59193);const Sn=(0,Qn.Ay)(Nn.A)`
  background-color: ${e=>{let{theme:t}=e;return t.template!==w.tC.HORIZONTAL_BAR_2022?"#ffffff":"#f0f0f0"}};
  border: 1px solid ${$.c3[200]};
  border-right: none;
`,Pn=(0,Qn.Ay)(kn.A,{shouldForwardProp:e=>"smallSearchBar"!==e})`
  ${Sn} {
    border-radius: ${e=>{let{options:t,open:n}=e;return n&&t.length?"8px 0 0 0":"8px 0 0 8px"}};
    padding: ${e=>{let{smallSearchBar:t}=e;return t?"2px 16px 20px":"10px 16px 28px"}};
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    ${Sn} {
      border-radius: 8px 8px 0px 0px;
    }
  }

  .MuiTextField-root {
    height: 40px;
  }

  .MuiInput-root {
    &::before,
    &::after {
      display: none;
    }
  }

  .MuiInput-input,
  .MuiInputLabel-root {
    font-family: var(--secondary-font);
  }

  .MuiInputLabel-root {
    &:not(.Mui-focused) {
      color: ${$.c3[400]};
    }
  }
`,Bn=(0,Qn.Ay)(jn.A)`
  .MuiAutocomplete-paper {
    border-radius: 0 0 8px 8px;
    box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
  }

  .MuiAutocomplete-listbox {
    border: 1px solid ${$.c3[200]};
    border-radius: 0 0 8px 8px;
    padding: 16px;
  }

  .MuiAutocomplete-option {
    border-radius: 4px;
    padding: 12px 16px;
    transition: ${e=>{let{theme:t}=e;return`all ${t.transitions.duration.shorter}ms ease`}};

    &.Mui-focused {
      background-color: ${e=>{let{theme:t}=e;const n=t.palette.primary.main;return(0,z.X4)(n,.2)}};
    }
  }
`,Vn=(0,Qn.Ay)(zn.A,{shouldForwardProp:e=>"bgColorName"!==e&&"smallSearchBar"!==e})`
  &.MuiButton-root {
    box-shadow: none;
    border-radius: 0 8px 8px 0;
    margin-left: 0;
    min-height: 56px;
    min-width: ${e=>{let{smallSearchBar:t}=e;return t?void 0:"80px"}};
    background-color: ${e=>{let{theme:t,bgColorName:n}=e;return n===F.Fl?(0,F.x6)(t.palette,F.ll,F.Xs):(0,F.x6)(t.palette,F.Fl,F.Xs)}};
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    &.MuiButton-root {
      width: 100%;
      border-radius: 0px 0px 8px 8px;
      font-size: 16px;
      font-weight: 600;
      line-height: 24px;
      min-width: 64px;
      padding: 16px;
    }
  }

  &:hover {
    background-color: ${e=>{let{theme:t,bgColorName:n}=e;if(n===F.Fl){const e=(0,F.x6)(t.palette,F.ll,F.Xs);return(0,F.Po)(e)}return(0,F.Po)((0,F.x6)(t.palette,F.Fl,F.Xs))}};
  }
`,$n=(0,Qn.Ay)(Nn.A,{shouldForwardProp:e=>"smallSearchBar"!==e})`
  width: 100%;
  min-height: ${e=>{let{smallSearchBar:t}=e;return t?"62px":"80px"}};
  max-width: ${e=>{let{theme:t}=e;return t.breakpoints.laptop}}px;
  border-radius: 8px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    min-height: 62px;
    max-width: ${e=>{let{theme:t}=e;return t.breakpoints.tablet}}px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    flex-direction: column;
    max-width: ${e=>{let{theme:t}=e;return t.breakpoints.mobile}}px;
  }
`;function Fn(e){let{bgColorName:t,smallSearchBar:n,inputValue:a,loading:i,onChange:s,onClick:c,onInputChange:d,options:p}=e;const{t:m}=(0,o.Bd)(),[u,g]=(0,r.useState)(!1),{isAboveBreakpoint:C}=(0,A.dv)();return r.createElement($n,{smallSearchBar:n,spacing:2,direction:"row"},r.createElement(Pn,{"data-testid":"job-offers-search-bar",smallSearchBar:n,fullWidth:!0,freeSolo:!0,onChange:s,onInputChange:d,onOpen:()=>g(!0),onClose:()=>g(!1),open:u,inputValue:a,isOptionEqualToValue:(e,t)=>e.label===t,options:p,loading:!1,clearText:m("job_offers.search_bar.clear_text"),PopperComponent:Bn,renderInput:e=>{let{InputProps:{ref:t,...n},...a}=e;return r.createElement(Sn,{direction:"row",alignItems:"flex-end",ref:t,spacing:1},r.createElement(Tn.A,{height:16,mb:"2px"},r.createElement(ge.A,{size:16,View:_.C0})),r.createElement(Q.A,(0,l.A)({},a,{label:m("job_offers.search_bar.placeholder_2022"),InputProps:{...n,endAdornment:r.createElement(r.Fragment,null,i?r.createElement(On.A,{color:"inherit",size:20}):null,n.endAdornment)},variant:"standard"})))}}),r.createElement(Vn,{"data-testid":"job-offers-search-btn",bgColorName:t,smallSearchBar:n,variant:"contained",onClick:c,type:"button",title:m("job_offers.search_bar.button_text"),size:"medium"},C("mobile")?r.createElement(ge.A,{fill:"#ffffff",View:_.C0,withContrast:!0}):m("job_offers.search_bar.button_text")))}const Zn=e=>{let{bgColorName:t,smallSearchBar:n}=e;return r.createElement(m.Rq,{smallSearchBar:n,bgColorName:t,view:Fn})};n(94721);var Gn=n(13805),Rn=n(20877),Hn=n(76772);const Un=(0,i.Ay)(Hn._)`
  position: fixed;
  right: 16px;
  bottom: 16px;
  z-index: 2;
  max-width: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px 32px;
`,Yn=i.Ay.input`
  position: absolute;
  opacity: 0;
  height: 100%;
  width: 100%;
  left: 0;
  cursor: pointer;
`,Wn=(0,i.Ay)(Gn.A)`
  padding: 16px;
  svg {
    margin-right: 8px;
  }
`,Jn=e=>{let{children:t,onFileChange:n}=e;const{t:a}=(0,o.Bd)(),l=(0,i.DP)(),[s,A]=r.useState(null),c=!!s;return r.createElement(r.Fragment,null,r.createElement(Un,{colorName:"secondary",onClick:e=>{A(e.currentTarget)}},t),r.createElement(Rn.A,{id:"upload-your-cv-menu",anchorEl:s,open:c,onClose:()=>{A(null)},MenuListProps:{"aria-labelledby":"basic-button",sx:{width:s&&s.offsetWidth}},anchorOrigin:{vertical:"top",horizontal:"left"},transformOrigin:{vertical:"bottom",horizontal:"left"}},r.createElement(Wn,null,r.createElement(Yn,{"data-testid":"cvc-resume-upload-input",type:"file",accept:"image/*",capture:!0,onChange:e=>{n(e.target.files)}}),r.createElement(ge.A,{View:_.PE,size:32,theme:l,mode:"secondary"}),a("widget.take_picture_short")),r.createElement(Wn,null,r.createElement(Yn,{"data-testid":"cvc-resume-upload-input",type:"file",onChange:e=>{n(e.target.files)}}),r.createElement(ge.A,{View:_.nr,size:32,theme:l,mode:"secondary"}),a("widget.upload_file_short"))))};var Kn=n(83609),Xn=n(492),qn=n(71091),ea=n(30547),ta=n(27502);const na=i.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 16px;

  ${e=>{let{theme:t}=e;return t.breakpoints.between("mobile","tablet")}} {
    flex-direction: row;
    justify-content: space-between;
  }
`,aa=(0,i.Ay)(Mt.h)`
  margin: 0;
`,ra=(0,i.Ay)(p.EA)`
  height: 30px;
  width: 150px;
`,ia=(0,i.Ay)(p.o5)`
  font-weight: 600;
  line-height: 1.25;
  margin: 0;
`,la=()=>{const{t:e}=(0,o.Bd)(),{first_name:t,last_name:n}=(0,A.GV)(D.AR),a=(0,A.GV)(D.EC);return r.createElement(na,null,a?r.createElement(ra,null):r.createElement(aa,{variant:"h3",autoContrast:!0,"data-testid":"cvc-hello-2022"},e("profile_identity.hello_2022",{name:t||n})),r.createElement(ia,null,e("profile_identity.cv_detect")))},oa=(0,r.createContext)({inputLabel:""}),sa=(0,Qn.Ay)(kn.A)`
  margin-top: 8px;
`,Aa=(0,Qn.Ay)(Q.A)`
  .MuiInputBase-root {
    border-radius: 5px;

    &::before {
      border: none;
    }
    
  }
`,ca=e=>{let{suggestions:t,getSuggestionValue:n,onSelectSuggestion:a,onSuggestionsFetchRequested:i,onSuggestionsClearRequested:o}=e;const{inputLabel:s}=(0,r.useContext)(oa),[A,c]=(0,r.useState)(""),[d,p]=(0,r.useState)(null);return r.createElement(sa,{onInputChange:(e,t,a)=>{c(t),i({value:t??n(t),reason:a})},onChange:(e,t,n)=>{"selectOption"===n&&(a(e,{suggestion:t}),o()),p(null),c("")},value:d,inputValue:A,freeSolo:!0,options:t,renderInput:e=>r.createElement(Aa,(0,l.A)({},e,{label:s,color:F.ll,variant:"filled"}))})},da=e=>r.createElement(m.kw,(0,l.A)({view:ca},e)),pa=()=>{const{t:e}=(0,o.Bd)();return r.createElement(oa.Provider,{value:{inputLabel:e("profile_identity.place_of_residence_placeholder")}},r.createElement(m.v3,{view:da}))},ma=()=>{const{t:e}=(0,o.Bd)();return r.createElement(oa.Provider,{value:{inputLabel:e("profile_jobs.placeholder")}},r.createElement(m.ys,{view:da}))},ua=()=>{const{t:e}=(0,o.Bd)();return r.createElement(oa.Provider,{value:{inputLabel:e("profile_skills.placeholder")}},r.createElement(m.kI,{view:da}))},ga=e=>{let{children:t}=e;const{expanded:n}=(0,b.nw)(),{isBelowBreakpoint:a}=(0,A.dv)(),i=a("laptop");return r.createElement(ea.A,{orientation:"vertical",unmountOnExit:!0,in:!i||n},t)},Ca=i.Ay.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,fa=(0,i.Ay)(Mt.h)`
  color: ${$.c3[800]};
  font-size: 1em;
  font-weight: 600;
  line-height: 20px;
  margin: 0 auto 0 0;
`,ha=(0,i.Ay)(p.o5)`
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  border-radius: 50%;
  padding: 4px;
  background-color: ${e=>{let{theme:t}=e;return t.palette.primary.light}};
  font-size: 0.85rem;
  font-weight: 600;
  line-height: 0.85rem;
  width: calc(1rem + 8px);

  &::before {
    content: "";
    display: block;
    padding-bottom: 100%;
  }
`,ya=(0,i.Ay)(zn.A)`
  color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};

  ${e=>{let{theme:t}=e;return t.breakpoints.up("laptop")}} {
    display: none;
  }
`,Ea=(0,i.Ay)(u.K0)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    display: none;
  }
`,Ma=e=>{let{count:t,desktopCollapsible:n=!1,title:a}=e;const{t:i}=(0,o.Bd)(),{expanded:l,setExpanded:s}=(0,b.nw)(),A=()=>{s(!l)};return r.createElement(Ca,null,r.createElement(ha,{variant:"div",autoContrast:!0},t),r.createElement(fa,{variant:"h4",autoContrast:!0},a),r.createElement(ya,{endIcon:r.createElement(p.h_,{View:l?_.ow:_.rI,size:16}),onClick:A,size:"small"},i(l?"common.close":"common.see")),n&&r.createElement(Ea,{colorName:F.QZ,fill:$.c3[800],Icon:l?_.jx:_.z1,onClick:A,size:24}))},xa=i.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 24px;
  position: relative;

  &:not(:last-child)::after {
    content: "";
    background-color: rgba(0, 0, 0, 0.06);
    position: absolute;
    bottom: 0;
    left: 0;
    height: 1px;
    width: calc(100% - 48px);
    margin: 0 24px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: 16px 24px;
  }
`,wa=e=>{let{children:t,...n}=e;return r.createElement(b.vk,null,r.createElement(xa,null,r.createElement(Ma,n),r.createElement(ga,null,t)))};var Da=n(87046),ba=n(81380),La=n(56550),_a=n(17678),Ia=n(30798),va=n(1675);const Na=(0,i.Ay)(va.A)`
  display: flex;
  align-items: flex-start;
  flex-direction: row;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 8px;
`,ka=e=>{let{item:t,onRemoveItem:n}=e;const a=(0,_a.NB)(t),{attributes:i,listeners:o,setNodeRef:s,transform:A,transition:c}=(0,Da.gl)({id:a}),d={transform:La.Ks.Translate.toString(A),transition:c};return r.createElement(bt.w,(0,l.A)({icon:_.MR,onClick:()=>n(t.id),ref:s,style:d},i,o),t.label)},ja=e=>{let{items:t,onRemoveItem:n,onDragEnd:a}=e;const i=(0,ba.FR)((0,ba.MS)(ba.AN,{activationConstraint:{distance:5}}));return void 0!==a?r.createElement(ba.Mp,{collisionDetection:ba.fp,onDragEnd:a,sensors:i},r.createElement(Da.gB,{items:t.map(e=>(0,_a.NB)(e))},r.createElement(Na,null,t.map(e=>r.createElement(ea.A,{in:!0,key:(0,_a.NB)(e)},r.createElement(ka,{item:e,onRemoveItem:n})))))):r.createElement(Na,null,t.map(e=>r.createElement(Ia.A,{in:!0,key:(0,_a.NB)(e)},r.createElement(bt.w,{icon:_.MR,onClick:()=>n(e.id)},r.createElement("span",null,e.label)))))};ja.propTypes={items:Te().array.isRequired,onRemoveItem:Te().func.isRequired,onDragEnd:Te().func};const za=()=>r.createElement(m.n6,{view:ja}),Ta=()=>r.createElement(m.pp,{view:ja}),Oa=()=>r.createElement(m.jX,{view:ja}),Qa=(0,i.Ay)(p.o5)`
  margin: 0;
`,Sa=()=>{const{t:e}=(0,o.Bd)(),t=(0,A.GV)(D.pU).length;return r.createElement(wa,{title:e("profile_jobs.title"),count:t},r.createElement(Qa,{autoContrast:!0},e("profile_jobs.drag_and_drop_info")),r.createElement(Ta,null),r.createElement(ma,null))},Pa=e=>{let{items:t,onAddItem:n}=e;return r.createElement(Na,null,t.map(e=>r.createElement(Ia.A,{in:!0,key:(0,_a.NB)(e)},r.createElement(bt.w,{onClick:()=>n(e),icon:_.uI,variant:"outlined"},r.createElement("span",null,e.label)))))},Ba=()=>r.createElement(m.mP,{view:Pa}),Va=(0,i.Ay)(p.o5)`
  margin: 16px 0 0 0;
`,$a=e=>{let{skillsCount:t}=e;const{t:n}=(0,o.Bd)(),{expanded:a,setExpanded:i}=(0,b.nw)();return(0,r.useEffect)(()=>{i(!0)},[t]),r.createElement(r.Fragment,null,r.createElement(ea.A,{in:a,collapsedSize:t>=5?180:36},r.createElement(Oa,null)),r.createElement(ua,null),r.createElement(Va,{autoContrast:!0},n("profile_skills.suggested_skills_text")),r.createElement(Ba,null))},Fa=()=>{const{t:e}=(0,o.Bd)(),t=(0,A.GV)(D.af).length;return r.createElement(wa,{count:t,desktopCollapsible:!0,title:e("profile_skills.title")},r.createElement($a,{skillsCount:t}))};var Za=n(46329),Ga=n(33976);const Ra=(0,Qn.Ay)(p.fz)`
  margin-bottom: 0;
`,Ha=(0,Qn.Ay)(Za.Ay)`
  height: 12px;

  .MuiSlider-mark {
    width: 4px;
    height: 4px;
    border-radius: 50%;
    opacity: 1;

    &[data-index="0"],
    &:not(.MuiSlider-markActive) {
      opacity: 0;
    }
  }

  .MuiSlider-thumb {
    height: 18px;
    width: 18px;
    box-shadow: none;
    border: 2px solid #ffffff;
  }
`,Ua=(0,Qn.Ay)(Tn.A)`
  width: 100%;
  padding: 0 16px 0 4px;
`,Ya=null,Wa=[{value:0,scaledValue:"0.01km",label:"0"},{value:10,scaledValue:"10km",label:"10"},{value:20,scaledValue:"30km",label:"30"},{value:30,scaledValue:"50km",label:"50"},{value:40,scaledValue:"100km",label:"100"},{value:50,scaledValue:"150km",label:"150"},{value:60,scaledValue:Ya,label:"Illimitée"}],Ja=()=>{const{t:e}=(0,o.Bd)();return(0,P.A)(Wa,t=>60===t.value?{...t,label:e("profile_workplace.unlimited")}:t)},Ka=(0,r.memo)(e=>{const t=Ja(),n=(0,ce.wA)(),a=(0,A.pp)(),{t:i}=(0,o.Bd)(),{config:s}=(0,b._r)(),d=(0,ce.d4)(e=>e.search.max_distance_filter)||Ya,[p,m]=(0,r.useState)(d);if(!d&&d!==Ya)throw new Error("Invalid config.jobOfferRequest.max_distance_filter property. Please check the config.json file of the partner. It should either be null or a string.");const u=(g=p,(0,Ga.A)(t,{scaledValue:g}));var g;const C=60===u.value?i("profile_workplace.unlimited"):`${u.label} km`;return r.createElement(r.Fragment,null,r.createElement(Ra,null,i("profile_workplace.max_distance",{distance:C})),r.createElement(Ua,null,r.createElement(Ha,(0,l.A)({"aria-label":"distance autour des villes","data-testid":"profile-city-slider",value:u.value,marks:t,max:60,min:0,onChange:(e,n)=>{const a=(e=>(0,Ga.A)(t,{value:e}))(n);a&&m(a.scaledValue)},onChangeCommitted:()=>{var e;n((0,c.Zp)(p)),e=p,a(w.mu.sZ.MAX_DISTANCE_FILTER,{new_distance:e,initial_distance:(0,xt.A)(s,"jobOfferRequest.max_distance_filter",null)})},step:null,valueLabelDisplay:"auto",valueLabelFormat:C},e))))});Ka.displayName="ProfileCitySlider";const Xa=(0,i.Ay)(p.o5)`
  margin: 0;
`,qa=()=>{const{t:e}=(0,o.Bd)(),t=(0,A.GV)(D.vp).length;return r.createElement(wa,{title:e("profile_workplace.title"),count:t},r.createElement(Xa,{autoContrast:!0},e("profile_identity.place_of_work")),r.createElement(ea.A,{orientation:"vertical",unmountOnExit:!0,in:t>0},r.createElement("div",null,r.createElement(za,null),r.createElement(Ka,null))),r.createElement(pa,null))};var er=n(14779),tr=n(21598);const nr=i.Ay.div`
  padding: 24px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: 16px 24px;
  }
`,ar=(0,i.Ay)(er.A)`
  .MuiFormControlLabel-label {
    font-size: 1rem;
  }
`,rr=e=>{let{isChecked:t,toggleSwitch:n}=e;const{t:a}=(0,o.Bd)();return r.createElement(nr,null,r.createElement(ar,{control:r.createElement(tr.A,{color:"primary",checked:t,onChange:e=>n(e.target.checked)}),label:a("profile_identity.display_only_customized_jobs")}))},ir=()=>r.createElement(m.Z,{view:rr});var lr=n(59123);const or=i.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px;
`,sr=()=>{const{t:e}=(0,o.Bd)(),t=(0,A.GV)(D.EC),[n,a]=(0,r.useState)(!1),i=(0,A.jL)(),l=(0,s.zy)(),p=(0,s.W6)();return r.createElement(or,null,r.createElement(u.$n,{colorName:F.FV,disabled:t,icon:_.ug,iconPosition:"left",onClick:async()=>{a(!0);try{await(0,lr.TL)(),Xn.A.removeResumeId(),Xn.A.removeSessionKey(),Xn.A.removeAttachmentFilename(),(0,d.ei)(p,l),i((0,c.G1)()),window.location.reload()}finally{a(!1)}},loading:n,size:"small",variant:"text"},e("profile_identity.delete_resume")))},Ar=(0,i.Ay)(ea.A)`
  flex: 0 1 400px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    flex: 1;

    &,
    & .MuiCollapse-wrapper,
    & .MuiCollapse-wrapperInner {
      width: 100%;
    }
  }
`,cr=i.Ay.div`
  background-color: #ffffff;
  border-radius: 5px;
  box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.12);

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    order: 1; // Display profile above filters and map
  }
`,dr=(0,i.Ay)(Nn.A)`
  border-radius: 5px;
  overflow: hidden; // Hide content not rounded corners
`,pr=i.Ay.div`
  ${e=>{let{disableContent:t}=e;return t?"\n    opacity: 0.3;\n    user-select: none;\n    pointer-events: none;\n  ":""}}
`,mr=(0,r.memo)(()=>r.createElement(r.Fragment,null,r.createElement(qa,null),r.createElement(Sa,null),r.createElement(Fa,null))),ur=()=>{const e=Xn.A.getResumeId(),t=(0,A.GV)(D.JT),n=(0,A.GV)(e=>e.search.useProfile),a=!(!e&&!t);return r.createElement(Ar,{orientation:"horizontal",in:a,unmountOnExit:!0},r.createElement(cr,null,r.createElement(dr,{direction:"column",divider:r.createElement(ta.A,null),"data-testid":"cvc-profile-wrapper"},r.createElement(la,null),r.createElement(ir,null),r.createElement(pr,{disableContent:!n},r.createElement(mr,null)),r.createElement(sr,null))))};mr.displayName="ProfileBlocks";var gr=n(58793),Cr=n(35560),fr=n(63991),hr=n(23158),yr=n(65886),Er=n(69421),Mr=n(74798),xr=n(8877),wr=n(6989);const Dr=(0,i.Ay)(yr.v)`
  display: flex;
  padding: 48px;
  margin-top: 32px;
  gap: 48px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: 24px;
  }
`,br=i.Ay.div`
  flex: 3;
  height: fit-content;

  svg {
    fill: ${e=>{let{theme:t}=e;return(0,F.x6)(t.palette,"secondary","light")}};
  }
`,Lr=i.Ay.div`
  flex: 10;
`,_r=(0,i.Ay)(Mt.h)`
  font-size: 2rem;
  margin: 0;
`,Ir=(0,i.Ay)(Mr.A)`
  margin-bottom: 32px;
`,vr=e=>{let{spontaneousApplicationBoxRef:t}=e;const n="spontaneous-application",{t:a}=(0,o.Bd)(),i=(0,r.useRef)(!1),l=(0,ce.d4)(e=>e.profile.id),s=(0,ce.d4)(e=>e.profile.isFetching),A=(0,ce.d4)(e=>e.search.results||null),c=(0,ce.d4)(e=>e.search.isFetching);return(0,r.useEffect)(()=>{if(!c&&null!==A&&!i.current){new URL(window.location.href).hash===`#${n}`&&(setTimeout(()=>{document.getElementById(n).scrollIntoView({behavior:"smooth"})},500),i.current=!0)}},[c,A]),r.createElement(Dr,{"data-print-hidden":!0,ref:t},r.createElement(xr.rb,{up:!0},!s&&!l&&r.createElement(br,null,r.createElement(Er.F2,{height:"auto",width:"auto"}))),r.createElement(Lr,null,r.createElement("a",{href:`#${n}`},r.createElement(_r,{id:n,autoContrast:!0,variant:"h2"},a("result_page.spontaneous_application.title"))),r.createElement(Ir,{autoContrast:!0},a("result_page.spontaneous_application.subtitle")),r.createElement(gr.N,{isSpontaneousForm:!0,views:{uploadView:Cr.K,formView:wr.h,successView:fr.D,errorView:hr.V}})))},Nr=i.Ay.div`
  display: flex;
  flex-wrap: wrap;
  gap: ${e=>{let{isProfileSectionDisplayed:t}=e;return t?"16px 32px":"16px 0px"}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    gap: ${e=>{let{isProfileSectionDisplayed:t}=e;return t?"24px":"24px 0px"}};
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    margin-top: 0px;
  }
`,kr=i.Ay.div`
  display: flex;
  flex-direction: column;
  flex: 1 1 500px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    order: 3; // Display job offers below filters and map
  }
`,jr=()=>{const e=Xn.A.getResumeId(),t=(0,r.useRef)(),n=(0,A.GV)(D.JT),{config:a}=(0,b._r)(),i=!(!e&&!n);return r.createElement(Nr,{isProfileSectionDisplayed:i},r.createElement(Ae,{id:"result-page-top-anchor"}),r.createElement(ur,null),r.createElement(kr,{"data-testid":"cvc-job-offers-list"},r.createElement(wn,null),r.createElement(vn,null),(0,qn.B)(a)&&r.createElement(vr,{spontaneousApplicationBoxRef:t})))};var zr=n(49617),Tr=n(80379),Or=n(5246),Qr=n(39234),Sr=n(58482),Pr=n(61361);const Br=i.Ay.div`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 24px;
  background-size: cover;
  background-repeat: no-repeat;
  text-align: center;
  min-height: ${e=>{let{displayHeader:t}=e;return t?"64vh":"50vh"}};

  & > * {
    z-index: 1;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    padding-bottom: 68px;
  }
`,Vr=(0,i.Ay)(p.o5)`
  font-size: 2.85rem;
  font-weight: 700;
  line-height: 1.5;
  margin: 0;
  padding-top: 48px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    font-size: 2em;
  }
`,$r=(0,i.Ay)(Sr.o)`
  position: absolute;
  z-index: 2;
  left: 64px;
  top: 64px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    left: 16px;
    top: 38px;
    z-index: 5;
  }
`,Fr=(0,i.Ay)(zr.A)`
  display: flex;
  justify-content: center;
`,Zr=()=>{const{config:e}=(0,b._r)(),{t,i18n:n}=(0,o.Bd)(),{display_page_header:a}=(0,A.Jr)(),i=(0,A.yM)(),l=(0,A.NB)(),s=(0,A.qx)(),c=i||l,d=(0,A.Ee)(),m={...e[n.language].serp?.coverImage,src:e[n.language].serp?.coverImage?.src||Or.l.RESULT_PAGE_COVER},u=(0,Qr.W)(m,Ee.Fr),g=(0,Qr.c)(m,Ee.Fr,!1),C=a||!c;return r.createElement(Br,{displayHeader:C},r.createElement(p.DN,{alt:"photo de couverture",src:u,bgPosition:g||"50% 25%"}),!l&&!(s&&!e.company_url)&&r.createElement($r,{fallbackRoute:Tr.J.HOME}),C&&r.createElement(Pr.Y,{position:"absolute",transparent:!0}),r.createElement(Vr,{light:!0,variant:"p"},t("result_page.cover.title")),d&&r.createElement(Fr,null,r.createElement(p.tm,null)))};var Gr=n(29298);const Rr=e=>{const{t}=(0,o.Bd)();return r.createElement(Jn,e,t("widget.file_input.main_text"))},Hr=()=>{const e=Xn.A.getResumeId(),[t,n]=(0,r.useState)(!e);return t?r.createElement(Gr.A,{mobileUploadZoneView:Rr,postAnalysisCallback:()=>{n(!1)},displayMobileAnalysisInModal:!0}):null}},85561:(e,t,n)=>{n.d(t,{C:()=>m});var a=n(14041),r=n(85426),i=n.n(r),l=n(38544),o=n(61160),s=n(306),A=n(68382),c=n(68153),d=n(85423),p=n(31048);const m=e=>{let{view:t,isSpontaneousForm:n}=e;const{config:r}=(0,c._r)(),m=(0,l.wA)(),u=(0,d.GV)(p.rX),g=(0,d.GV)(p.Ht),C=(0,d.GV)(p.aD),f=g?.errorCode,h=C?.errorCode,y=(0,d.GV)(p.JT),E=(0,d.GV)(e=>e.profile.isFileUploaded);(0,a.useEffect)(()=>{if(r.analytics?.google_tag_manager?.active&&i().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Bloc",EventAction:"Visible",EventLibelle:"[DO] - Candidature échec"}}),"virus_found_in_resume_file"===f){const e=A.M$.DISPLAYED_APPLICATION_FAILED_VIRUS_FOUND_ERROR,t={resumeId:y};(0,A.Wf)(e,t)}},[r.analytics?.google_tag_manager?.active,f,h,y]);return a.createElement(t,{retry:()=>{m(n?(0,s.T$)():(0,s.mN)(u.id)),E||m((0,o.z)(!1))},showDirectLink:!n&&(e=>{let t;try{t=new URL(e)}catch(e){return!1}return!t.hostname.startsWith("api.cvcatcher.io")})(u.link),isSpontaneousForm:n})}},87433:(e,t,n)=>{n.d(t,{p:()=>i});var a=n(14041),r=n(86090);const i=e=>{let{children:t}=e;const n=(0,r.zy)();return(0,a.useEffect)(()=>{if(!n.hash)return;const e=document.getElementById(n.hash.substring(1));e&&e.scrollIntoView({behavior:"smooth"})},[n.hash]),a.createElement(a.Fragment,null,t)}},87448:(e,t,n)=>{n.d(t,{A:()=>u});var a=n(14041),r=n(30038),i=n(13674),l=n(97434),o=n(2345),s=n(36080),A=n(66341),c=n(68153),d=n(61501);const p=(0,o.Ay)(r.A)`
  color: ${s.c3[900]};
  font-size: 1rem;
  font-weight: 600;
  line-height: 1.25;

  &:hover {
    text-decoration: underline !important;
  }

  svg {
    margin-left: 10px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.up("laptop")}} {
    white-space: nowrap;
  }
`,m=(0,o.Ay)(i.A)`
  font-family: var(--regular-text-font);
  font-size: var(--terms-of-service-content-font-size);
`;function u(e){let{i18nKey:t,variant:n="body1"}=e;const{t:r,i18n:i}=(0,l.Bd)(),{config:o}=(0,c._r)(),s=r(t),u=Array.from(s.matchAll(/href=["']([^"']*)["']/g)||[]),g=d.wl.getPrivacyPolicyUrl(o,i.language,!0),C=u.reduce((e,t,n)=>{const r=`link${n+1}`,i=t[1]||g;return e[r]=a.createElement(p,{color:"inherit",href:i,rel:"noopener noreferer",target:"_blank",underline:"hover"}),e},{});return 0===Object.keys(C).length&&(C.link1=a.createElement(p,{color:"inherit",href:g,rel:"noopener noreferer",target:"_blank",underline:"hover"})),a.createElement(m,{variant:n,"data-testid":"cvc-analysis-consent-txt"},a.createElement(l.x6,{i18nKey:t,components:{...C,icon1:a.createElement(A.HW,{width:16,height:16})}}))}},87540:(e,t,n)=>{n.d(t,{S:()=>y});var a=n(14041),r=n(2345),i=n(58797),l=n(97434),o=n(68153),s=n(33106),A=n(33131),c=n(66341),d=n(85423),p=n(92241),m=n(80379),u=n(45890);const g=r.Ay.header`
  background: var(--header-background-color);
  width: 100%;
  margin: 0;
  min-height: 75px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10%;

  ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.mobile}px) {\n        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);\n        padding: 0px;\n        justify-content: flex-start;\n      }\n    `}}
`,C=(0,r.Ay)(p.E)`
  display: flex;
  align-items: center;

  ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.tablet}px) {\n        display: none;\n      }\n    `}}
`,f=r.Ay.img`
  max-height: 100px;
  min-height: 64px;
  object-fit: contain;
  padding: 16px 24px;
`,h=r.Ay.a`
  align-items: center;
  justify-content: center;
  display: flex;
  text-decoration: none;
  color: #000000de;
  font-family: "Open Sans", sans-serif;
  font-size: 0.875rem;
  font-weight: 700;
  transition: all 300ms ease;
  gap: 8px;

  &:hover {
    text-decoration: underline;
  }

  ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.tablet}px) {\n       left: 24px;\n      }\n    `}}

  ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.mobile}px) {\n        position: static;\n        align-self: center;\n      }\n    `}}
`;function y(){const e=(0,r.DP)(),{config:t}=(0,o._r)(),{t:n}=(0,l.Bd)(),p=(0,d.lC)(),y=(0,d.XV)(),E=p?.backLink||m.J.HOME;return a.createElement(g,{theme:e},a.createElement(h,{href:E},a.createElement(A.A,{View:c.gu,withContrast:!0,size:24,alt:"go back arrow"}),a.createElement(i.o5,{autoContrast:!0,variant:"span"},n("landing_page.back_to_website"))),a.createElement(C,{to:m.J.HOME},a.createElement(f,{className:"header-logo",src:(0,s.xI)(t),alt:"logo"})),y&&a.createElement(u.L,{className:"feature"}))}},87961:(e,t,n)=>{n.d(t,{G:()=>i});var a=n(14041);const r=n(2345).Ay.div`
  width: 100%;
  margin-bottom: 15px;
  text-align: center;
  @media screen and (min-width: 460px) {
    max-width: 170px;
    float: left;
    width: 30%;
    margin-right: 50px;
    margin-top: 65px;
    ${e=>{let{isTiny:t}=e;return t&&"\n    margin: 0 auto;\n    width: 100%;\n    align-self: center;\n   float: none;\n  "}}
  }
`,i=e=>{let{isTiny:t}=e;return a.createElement(r,{isTiny:t},a.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:"145.777",height:"87.284",viewBox:"0 0 145.777 87.284"},a.createElement("g",{id:"Groupe_966","data-name":"Groupe 966",transform:"translate(-309.446 -308)"},a.createElement("path",{id:"Tracé_360","data-name":"Tracé 360",d:"M148.536,113.116H120.458a4.38,4.38,0,0,1-4.358-4.358h0a4.38,4.38,0,0,1,4.358-4.358h28.078c2.39,0,.358,1.968.358,4.358h0C148.894,111.171,150.926,113.116,148.536,113.116Z",transform:"translate(205.787 207.734)",fill:"#f8f8f8"}),a.createElement("path",{id:"Tracé_361","data-name":"Tracé 361",d:"M483.092,113.116H469.058a4.38,4.38,0,0,1-4.358-4.358h0a4.38,4.38,0,0,1,4.358-4.358h14.034a4.38,4.38,0,0,1,4.358,4.358h0A4.365,4.365,0,0,1,483.092,113.116Z",transform:"translate(-56.139 207.734)",fill:"#f8f8f8"}),a.createElement("g",{id:"Groupe_726","data-name":"Groupe 726",transform:"translate(408.809 353.205)"},a.createElement("path",{id:"Tracé_362","data-name":"Tracé 362",d:"M567.8,353.523h.164a.086.086,0,0,1-.07-.023C567.847,353.5,567.823,353.523,567.8,353.523Z",transform:"translate(-548.893 -336.209)",fill:"none"}),a.createElement("path",{id:"Tracé_363","data-name":"Tracé 363",d:"M529.179,297.014H522.5a3.851,3.851,0,0,1-.539.047H506.687a4.186,4.186,0,0,1-.539-.047h-.164a.086.086,0,0,0,.07-.023,4.341,4.341,0,0,1-3.725-4.288h0a4.34,4.34,0,0,1,4.334-4.334h3.842a4.356,4.356,0,0,0-.609-8.669H492.934a4.357,4.357,0,0,0-.773,8.645h-.7a4.35,4.35,0,0,0-.281,8.692,4.379,4.379,0,0,0-4.006,4.334h0a4.38,4.38,0,0,0,4.358,4.358h37.627a4.38,4.38,0,0,0,4.358-4.358h0A4.315,4.315,0,0,0,529.179,297.014Z",transform:"translate(-487.1 -279.7)",fill:"#f8f8f8"})),a.createElement("path",{id:"Tracé_364","data-name":"Tracé 364",d:"M329.253,430.816h-3.8a4.38,4.38,0,0,1-4.358-4.358h0a4.38,4.38,0,0,1,4.358-4.358h3.8a4.38,4.38,0,0,1,4.358,4.358h0A4.38,4.38,0,0,1,329.253,430.816Z",transform:"translate(48.816 -35.531)",fill:"#f8f8f8"}),a.createElement("path",{id:"Tracé_365","data-name":"Tracé 365",d:"M149.717,361.416H131.958a4.38,4.38,0,0,1-4.358-4.358h0a4.38,4.38,0,0,1,4.358-4.358h17.759a4.38,4.38,0,0,1,4.358,4.358h0A4.38,4.38,0,0,1,149.717,361.416Z",transform:"translate(196.981 17.609)",fill:"#f8f8f8"}),a.createElement("path",{id:"Tracé_366","data-name":"Tracé 366",d:"M215.192,188.416h-9.034a4.38,4.38,0,0,1-4.358-4.358h0a4.38,4.38,0,0,1,4.358-4.358h9.034c2.39,0,.358,1.968.358,4.358h0C215.55,186.448,217.582,188.416,215.192,188.416Z",transform:"translate(140.165 150.076)",fill:"#f8f8f8"}),a.createElement("path",{id:"Tracé_367","data-name":"Tracé 367",d:"M114.4,430.816H67.358A4.38,4.38,0,0,1,63,426.458h0a4.38,4.38,0,0,1,4.358-4.358H114.4a4.38,4.38,0,0,1,4.358,4.358h0A4.38,4.38,0,0,1,114.4,430.816Z",transform:"translate(246.446 -35.531)",fill:"#f8f8f8"}),a.createElement("g",{id:"Groupe_963","data-name":"Groupe 963"},a.createElement("line",{id:"Ligne_18","data-name":"Ligne 18",x2:"4.592",transform:"translate(414.181 381.624)",fill:"none",stroke:"#ff6464",strokeLinecap:"round",strokeLinejoin:"round",strokeMiterlimit:"10",strokeWidth:"2"}),a.createElement("line",{id:"Ligne_19","data-name":"Ligne 19",y2:"4.78",transform:"translate(409.401 386.802)",fill:"none",stroke:"#ff6464",strokeLinecap:"round",strokeLinejoin:"round",strokeMiterlimit:"10",strokeWidth:"2"}),a.createElement("line",{id:"Ligne_20","data-name":"Ligne 20",x2:"2.132",y2:"2.132",transform:"translate(412.564 384.881)",fill:"none",stroke:"#ff6464",strokeLinecap:"round",strokeLinejoin:"round",strokeMiterlimit:"10",strokeWidth:"2"}),a.createElement("line",{id:"Ligne_21","data-name":"Ligne 21",x2:"1.125",y2:"1.125",transform:"translate(416.915 389.231)",fill:"none",stroke:"#ff6464",strokeLinecap:"round",strokeLinejoin:"round",strokeMiterlimit:"10",strokeWidth:"2"})),a.createElement("g",{id:"file_1_","data-name":"file (1)",transform:"translate(353 308)"},a.createElement("g",{id:"Groupe_105","data-name":"Groupe 105",transform:"translate(10.513 23.334)"},a.createElement("g",{id:"Groupe_104","data-name":"Groupe 104",transform:"translate(0)"},a.createElement("path",{id:"Tracé_161","data-name":"Tracé 161",d:"M169.817,164.017H139.632a1.705,1.705,0,0,0,0,3.411h30.185a1.705,1.705,0,1,0,0-3.411Z",transform:"translate(-137.927 -164.017)",fill:"#ff6464"}))),a.createElement("g",{id:"Groupe_107","data-name":"Groupe 107",transform:"translate(10.513 33.625)"},a.createElement("g",{id:"Groupe_106","data-name":"Groupe 106",transform:"translate(0)"},a.createElement("path",{id:"Tracé_162","data-name":"Tracé 162",d:"M169.817,236.355H139.632a1.705,1.705,0,0,0,0,3.411h30.185a1.705,1.705,0,1,0,0-3.411Z",transform:"translate(-137.927 -236.355)",fill:"#ff6464"}))),a.createElement("g",{id:"Groupe_109","data-name":"Groupe 109",transform:"translate(0.001)"},a.createElement("g",{id:"Groupe_108","data-name":"Groupe 108",transform:"translate(0 0)"},a.createElement("path",{id:"Tracé_163","data-name":"Tracé 163",d:"M118.654,14.715a1.7,1.7,0,0,0-.5-1.161L105.113.51A1.7,1.7,0,0,0,103.9,0H67.63a3.6,3.6,0,0,0-3.592,3.592V46.179c0,.015,0,.029,0,.045a2.541,2.541,0,0,0,1.207,2.1l5.883,3.652a5.934,5.934,0,0,0,6.3,0l4.038-2.506a2.543,2.543,0,0,1,2.7,0L88.2,51.977a5.933,5.933,0,0,0,6.3,0l4.038-2.506a2.544,2.544,0,0,1,2.7,0l4.038,2.506a5.933,5.933,0,0,0,6.3,0l5.883-3.652a2.541,2.541,0,0,0,1.207-2.1c0-.015,0-.029,0-.045V14.76A.443.443,0,0,0,118.654,14.715ZM105.6,5.823h0l7.232,7.232h-7.053a.18.18,0,0,1-.18-.18V5.823Zm9.644,39.855-5.48,3.4a2.543,2.543,0,0,1-2.7,0l-4.038-2.506a5.934,5.934,0,0,0-6.3,0L92.7,49.079a2.544,2.544,0,0,1-2.7,0l-4.038-2.506a5.933,5.933,0,0,0-6.3,0l-4.038,2.506a2.544,2.544,0,0,1-2.7,0l-5.48-3.4V3.591a.181.181,0,0,1,.181-.181h34.561v9.465a3.6,3.6,0,0,0,3.591,3.591h9.465Z",transform:"translate(-64.038 0.001)",fill:"#ff6464"}))),a.createElement("g",{id:"Groupe_111","data-name":"Groupe 111",transform:"translate(0 53.746)"},a.createElement("g",{id:"Groupe_110","data-name":"Groupe 110"},a.createElement("path",{id:"Tracé_164","data-name":"Tracé 164",d:"M118.652,380.368s0-.009,0-.013,0-.009,0-.013a2.558,2.558,0,0,0-3.907-2.174L109.7,381.3a2.435,2.435,0,0,1-2.582,0l-4.154-2.578a5.823,5.823,0,0,0-6.18,0L92.634,381.3a2.435,2.435,0,0,1-2.582,0L85.9,378.72a5.824,5.824,0,0,0-6.18,0L75.565,381.3a2.434,2.434,0,0,1-2.582,0l-5.042-3.129a2.558,2.558,0,0,0-3.907,2.174s0,.009,0,.013,0,.009,0,.013v12.918a3.6,3.6,0,0,0,3.592,3.592h47.436a3.6,3.6,0,0,0,3.592-3.592Zm-3.591,13.1H67.626a.181.181,0,0,1-.181-.181V381.875l3.739,2.321a5.825,5.825,0,0,0,6.179,0l4.153-2.578a2.434,2.434,0,0,1,2.582,0l4.153,2.578a5.825,5.825,0,0,0,6.18,0l4.153-2.578a2.434,2.434,0,0,1,2.582,0l4.154,2.578a5.825,5.825,0,0,0,6.179,0l3.739-2.321v11.412A.181.181,0,0,1,115.061,393.467Z",transform:"translate(-64.033 -377.784)",fill:"#ff6464"})))))))}},90835:(e,t,n)=>{n.d(t,{x:()=>c});var a=n(14041),r=n(19996),i=n(32673),l=n(97434),o=n(89575);const s=e=>"question"in e,A=e=>{let{field:t,textFieldProps:n}=e;const r=s(t)?(t.options??[]).map(e=>{let{label:t}=e;return{label:t,value:t}}):(t.options??[]).map(e=>{let{placeholder:t,value:n}=e;return{label:t,value:n}});return a.createElement(i.A,(0,o.A)({select:!0,SelectProps:{native:!0}},n),r.map((e,n)=>a.createElement("option",{key:n,value:e.value,"data-testid":`cvc-application-form-field-${t.id}-option-${n}`},e.label)))},c=e=>{let{field:t,isRequired:n,inputChange:o,inputFocus:c}=e;const{t:d}=(0,l.Bd)(),p=["text","textarea"].includes(t.type),m=s(t)?t.question:d(`application.ats_required_fields.${t.id}`),u={"data-testid":`cvc-application-form-field-${t.id}`};if(s(t)){const e="decimal"===t.format,n="integer"===t.format,a=e||n;u.inputMode=e?"decimal":n?"numeric":void 0,u.max=a&&t.max?t.max:void 0,u.maxLength=p&&t.limit?t.limit:void 0,u.min=a&&t.min?t.min:void 0,u.pattern=e?"[0-9]+([,.][0-9]+)?":n?"[0-9]*":void 0}else(e=>!s(e)&&"PHONE"===e.id)(t)&&(u.autoComplete="tel",u.type="tel");const g={error:!!t.error,fullWidth:!0,helperText:t.error,inputProps:u,label:m,name:t.api_name,onChange:o,onFocus:c,required:n??!0,value:t.value,variant:"outlined"};return a.createElement(r.Ay,{item:!0,xs:12,md:6},(e=>"select"===e.type)(t)?a.createElement(A,{field:t,textFieldProps:g}):a.createElement(i.A,g))}},92241:(e,t,n)=>{n.d(t,{E:()=>A});var a=n(89575),r=n(14041),i=n(33664),l=n(2345),o=n(8049);const s=(0,l.Ay)(i.N_)`
  font-size: 1rem;

  &:hover {
    text-decoration: underline !important;
  }
`,A=e=>{let{to:t,...n}=e;return r.createElement(s,(0,a.A)({to:(0,o.KF)(t)},n))}},93368:(e,t,n)=>{n.d(t,{w:()=>l});var a=n(89575),r=n(14041),i=n(12973);const l=(0,r.forwardRef)((e,t)=>r.createElement(i.$,(0,a.A)({},e,{size:"small",ref:t})));l.displayName="SmallButton"},93444:(e,t,n)=>{n.d(t,{ys:()=>c,pp:()=>g,Pz:()=>y,sK:()=>M,By:()=>_,$I:()=>I,ob:()=>v,yV:()=>N,jT:()=>k.j,go:()=>O,CQ:()=>Q,fg:()=>V,O2:()=>Z,kV:()=>G,kw:()=>H,JC:()=>ne,Rq:()=>de,mi:()=>ue,kI:()=>ge,jX:()=>he,mP:()=>Me,OJ:()=>xe,Z:()=>De,GI:()=>be,v3:()=>Le,n6:()=>_e});var a=n(14041),r=n(38544),i=n(96362),l=n(63926),o=n(59123),s=n(97434),A=n(47132);const c=e=>{let{view:t}=e;const n=(0,r.wA)(),{i18n:c}=(0,s.Bd)(),d=(0,a.useCallback)(e=>{n((0,i.je)(e)),n((0,l.Pd)())},[n]);return a.createElement(t,{onSuggestionSelected:d,fetchSuggestions:async e=>{const t={lang:c.language,country:(0,A.JJ)(c.language),input:e,enable_sectors_white_list:!1};let n=await(0,o.zA)(t);const a=n.suggestions.slice(0,10).map(e=>({id:e.id,label:e.label,sector_label:e.sector_label}));return{total:n.numFound,suggestions:a}}})};var d=n(7398),p=n(85423),m=n(31048),u=n(17678);const g=e=>{let{view:t}=e;const n=(0,r.wA)(),o=(0,p.GV)(m.pU),s=(0,a.useCallback)(e=>{n((0,i.OO)(e)),n((0,l.Pd)())},[n]),A=(0,a.useCallback)(e=>{let{active:t,over:a}=e;if(!a||t.id===a.id)return;const r=o.findIndex(e=>(0,u.NB)(e)===t.id),l=o.findIndex(e=>(0,u.NB)(e)===a.id),s=Array.from(o),A=(0,d.nw)(s,r);(0,d.MF)(s,l,A),n((0,i.y2)(s))},[n,o]);return a.createElement(t,{onDragEnd:A,items:o,onRemoveItem:s})};var C=n(39067),f=n.n(C),h=n(13237);const y=e=>{let{contractTypes:t,view:n}=e;const{i18n:r}=(0,s.Bd)(),i=t.map((e,n)=>n===t.length-1?`${(0,h.LK)(e,r.language)}`:`${(0,h.LK)(e,r.language)} • `);return t.length>0?a.createElement(n,{text:i}):null};y.propTypes={contractTypes:f().arrayOf(f().string)};var E=n(61501);const M=e=>{let{offer:t,showDistance:n,view:r}=e;const{t:i}=(0,s.Bd)(),{display_job_distance:l}=(0,p.Jr)();let o=(0,p.gl)(t);const A=(0,p.GV)(m.NG),c=(0,p.GV)(m.vp),u=(0,E.r9)(t);if(!u||!o?.length)return null;if(u.coordinates&&c.length>0&&A&&l&&n){const e=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:null,t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[],n=arguments.length>2?arguments[2]:void 0,a="";if(!e)throw new Error("You must pass the coordinates of the point of origin");return t.forEach(t=>{const r=(0,d.d$)(e,t.coordinates);r>0&&(a.length>0&&(a+=", "),a+=n("job_offers.locality_interval",{postProcess:"interval",count:r,city:t.label}).trim())}),a}(u.coordinates,c,i);e.length>0&&(o+=` (${e})`)}return a.createElement(r,{text:o})};var x=n(89575),w=n(66341),D=n(76073),b=n(68382),L=n(18307);const _=(0,a.memo)(e=>{let{view:t,...n}=e;const l=(0,r.wA)(),{t:o}=(0,s.Bd)(),A=(0,L.Gb)(),c=(0,p.oT)(),d=(0,p.GV)(e=>e.search.aggregations.cities),u=(0,p.GV)(m.su),g=o("city_filter.placeholder"),C=o("city_filter.label"),f=(0,a.useCallback)((e,t)=>{l((0,i.X6)(e.map(e=>e.value),t)),l((0,b.uI)(b.M$.FILTER_CLICK_CITIES,e)),A&&l((0,D.nD)())},[A,l]),h="cities";return(0,a.useEffect)(()=>{c(h,u)},[u]),a.createElement(t,(0,x.A)({dataTestId:"cvc-city-filter",aggregations:d,selectedFields:u,dispatchFunction:f,icon:w.ft,includeFilter:!0,label:C,placeholder:g,filterName:h},n))});_.displayName="JobOffersCityFilterCore";const I=(0,a.memo)(e=>{let{view:t,...n}=e;const l=(0,r.wA)(),o=(0,L.Gb)(),A=(0,p.oT)(),c=(0,p.GV)(e=>e.search.aggregations.companies),d=(0,p.GV)(m.eO),{t:u}=(0,s.Bd)(),g=u("company_filter.label"),C=u("company_filter.label"),f=(0,a.useCallback)((e,t)=>{l((0,i.n0)(e.map(e=>e.value),t)),l((0,b.uI)(b.M$.FILTER_CLICK_COMPANIES,e)),o&&l((0,D.nD)())},[o,l]),h="companies";return(0,a.useEffect)(()=>{A(h,d)},[d]),a.createElement(t,(0,x.A)({dataTestId:"cvc-company-filter",aggregations:c,selectedFields:d,dispatchFunction:f,icon:w.A9,label:g,placeholder:C,filterName:h},n))});I.displayName="JobOffersCompanyFilterCore";const v=(0,a.memo)(e=>{let{view:t,...n}=e;const{t:l,i18n:o}=(0,s.Bd)(),A=(0,L.Gb)(),c=(0,r.wA)(),d=(0,p.oT)(),m=(0,p.GV)(e=>(0,h.uz)(e.search.contracts,e.search.aggregations.contracts),r.bN),u=(0,p.GV)(e=>(0,h.kh)(e.search.aggregations.contracts,o.language),r.bN),g=l("contract_filter.label"),C=l("contract_filter.label"),f=(0,a.useCallback)((e,t)=>{c((0,i.ry)(e.map(e=>e.value),t)),c((0,b.uI)(b.M$.FILTER_CLICK_CONTRACT_TYPES,e)),A&&c((0,D.nD)())},[A,c]),y="contracts";return(0,a.useEffect)(()=>{d(y,m)},[m]),a.createElement(t,(0,x.A)({dataTestId:"cvc-contract-types-filter",aggregations:u,selectedFields:m,dispatchFunction:f,icon:w.nR,label:g,placeholder:C,filterName:y},n))});v.displayName="JobOffersContractFilterCore";const N=(0,a.memo)(e=>{let{view:t,...n}=e;const l=(0,r.wA)(),o=(0,L.Gb)(),A=(0,p.oT)(),c=(0,p.GV)(e=>e.search.aggregations.countries),d=(0,p.GV)(m.lq),{t:u}=(0,s.Bd)(),g=u("country_filter.label"),C=u("country_filter.placeholder"),f=(0,a.useCallback)((e,t)=>{l((0,i.m3)(e.map(e=>e.value),t)),l((0,b.uI)(b.M$.FILTER_CLICK_COUNTRIES,e)),o&&l((0,D.nD)())},[o,l]),h="countries";return(0,a.useEffect)(()=>{A(h,d)},[d]),a.createElement(t,(0,x.A)({dataTestId:"cvc-country-filter",aggregations:c,selectedFields:d,dispatchFunction:f,icon:w.RM,includeFilter:!0,label:g,placeholder:C,filterName:h},n))});N.displayName="JobOffersCountryFilterCore";var k=n(42843),j=n(82633),z=n(87084),T=n(16600);const O=(0,a.memo)(e=>{let{aggregations:t,selectedFields:n,isCustomFilter:r=!1,dispatchFunction:i,view:l,...o}=e;const[s,A]=(0,a.useState)([]),c=(0,a.useMemo)(()=>(0,T.zp)(t),[t]),p=0===c.length;(0,a.useEffect)(()=>{const e=(0,j.A)(n,e=>r?e.values:e),a=(0,d.op)(t,e);A(a);if((0,z.A)(a.map(e=>e.value),e).length>0){i(a,!1)}},[t,r,n,i]);return a.createElement(l,(0,x.A)({options:c,selectedOptions:s,onChange:function(e){let t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];A(e),t&&i(e,!0)},fetchJobOffers:e=>{e&&i(s,!0)},disabled:p},o))});O.displayName="JobOffersFilterCore";const Q=(0,a.memo)(e=>{let{view:t}=e;const n=(0,r.d4)(e=>e.search.isFetching||e.profile.isFetching||e.suggestions.isFetching);return a.createElement(t,{isFetching:n})});Q.displayName="JobOffersListCore";var S=n(83878),P=n(63511);const B=()=>(0,S.Mz)(e=>e.applications,(e,t)=>t,(e,t)=>e[t]&&e[t].success),V=(0,a.memo)(e=>{let{id:t,index:n,showJobOfferDescription:i,dataTestDomLocation:l,view:o}=e;const s=(0,r.wA)(),A=(0,r.d4)(e=>e.search.pageOffersRange),c=(0,r.d4)(e=>e.jobOffers[t],r.bN),d=(0,a.useMemo)(B,[]),p=(0,r.d4)(e=>d(e,t));return a.createElement(o,{trackingCallback:()=>((e,t)=>{const n=A.firstOfferPosition+t,a=b.M$.JOB_REDIRECTIONS;s((0,b.Iy)(a,e,P.Gc,n))})(t,n),id:t,index:n,jobOffer:c,alreadyApplied:p,showJobOfferDescription:i,dataTestDomLocation:l})});V.displayName="JobOffersListItemCore";var $=n(50390),F=n(8049);const Z=(0,a.memo)(e=>{let{view:t}=e;const n=(0,p.jL)(),r=(0,p.GV)(m.x0),l=(0,p.GV)(m.u6),o=(0,p.GV)(m.tC),s=(0,a.useCallback)((e,t)=>{n((0,b.Wf)(e,t))},[n]),A=(0,a.useCallback)((e,t)=>{n((0,i.lP)(e));const a=(0,u.Bo)(e,t);n((0,$.HC)((0,F.M_)(a)))},[n]);return o<=1?null:a.createElement(t,{"data-testid":"cvc-job-offers-pagination",currentPage:r,onPageChange:async e=>{const t=e.selected*l,n=e.selected+1;let a;a=r+1===n?{event:"next_offers",target_page:n}:r-1===n?{event:"previous_offers",target_page:n}:{event:"go_to_page",target_page:n},document.getElementById("result-page-top-anchor").scrollIntoView(),s(b.M$.JOB_PAGINATIONS,a),A(t,l)},pageCount:o})});Z.displayName="JobOffersPaginationCore";const G=(0,a.memo)(e=>{let{view:t,...n}=e;const l=(0,p.GV)(e=>e.search.aggregations.job_sectors),o=(0,p.GV)(m.BP),A=(0,r.wA)(),c=(0,L.Gb)(),{t:d}=(0,s.Bd)(),u=(0,p.oT)(),g=d("job_sector_filter.label"),C=d("job_sector_filter.label"),f=(0,a.useCallback)((e,t)=>{A((0,i.oC)(e.map(e=>e.value),t)),c&&A((0,D.nD)())},[c,A]),h="sectors";return(0,a.useEffect)(()=>{u(h,o)},[o]),a.createElement(t,(0,x.A)({aggregations:l,selectedFields:o,dispatchFunction:f,icon:w.ov,label:g,placeholder:C,filterName:h},n))});G.displayName="JobOffersSectorFilterCore";var R=n(37028);const H=e=>{let{onSuggestionSelected:t,fetchSuggestions:n,view:r}=e;const[i,l]=(0,a.useState)(""),[o,s]=(0,a.useState)([]),A=e=>{""!==e.value||""!==i?e.setAttribute("data-is-active","true"):e.setAttribute("data-is-active","false")},c=()=>{s([])},d=(0,R.A)(async e=>{let{value:t,reason:a}=e;if(["input-changed","input"].includes(a)&&t.length>=2)try{const e=await n(t);s(e.suggestions)}catch(e){c()}},600);return a.createElement(r,{onChange:(e,t)=>{let{newValue:n}=t;l(void 0!==n?n:e.target.value),A(e.target)},onBlur:e=>{A(e.target)},onSelectSuggestion:(e,n)=>{let{suggestion:a}=n;t(a),l("")},getSuggestionValue:e=>e.label,value:i,suggestions:o,onSuggestionsClearRequested:c,onSuggestionsFetchRequested:d})};H.propTypes={onSuggestionSelected:f().func.isRequired,fetchSuggestions:f().func.isRequired,view:f().elementType};var U=n(62004),Y=n(86090),W=n(306),J=n(50446),K=n(68153),X=n(40132),q=n(492),ee=n(23099),te=n(58797);const ne=e=>{let{view:t}=e;const n=(0,p.jL)(),{t:r}=(0,s.Bd)(),{config:o}=(0,K._r)(),A=(0,Y.zy)(),c=(0,p.GV)(m.I4),d=(0,p.GV)(m.Ut),u=(0,p.GV)(m.LH),g=(0,p.GV)(m.qP),C=(0,p.GV)(m.JT),f=(0,p.GV)(m.fj),h=(0,p.GV)(e=>e.suggestions.fetchingComplete),y=(0,p.GV)(m.x0),E=(0,p.GV)(m.tC),M=(0,p.GV)(m.mO)||{},x=(0,p.GV)(m.bl)||0,w=(0,p.GV)(m.As);(0,a.useEffect)(()=>{const e=b.M$.DISPLAYED_RESULTS_PAGES;n((0,b.Wf)(e,{})),!0===o.analytics?.at_internet&&X.A.sendPage({name:"results_analyse_cv",chapter1:"cv_catcher",chapter2:"parcours_web",level2:"1"})},[o.analytics?.at_internet,n]),(0,a.useEffect)(()=>{if(!u){const e=()=>{const e=d.custom_filters?.find(e=>"partner_meta.job_sector"===e.field);return e?e.values?.join("|"):d.job_sectors?.join("|")};(0,ee.oU)("page.display",{page_category:"List",page_subject:"Offer",page_type:"LO-Emploi",page_hostname:window.location.hostname,search_result:x,site_name:o.company_name,search_what:w,search_where:d.cities?.join("|"),search_contract:d.contracts?.join("|"),search_sector:e(),search_remote:d.remote_work_types?.map(e=>e.split("/").pop()).join("|")}),x&&(0,ee.oU)("product.display",{product_data:f?.map((e,t)=>{const n=M[e];return(0,ee.h6)(n,t+1+10*(y-1))})})}},[u]),(0,a.useEffect)(()=>{C&&q.A.setResumeId(C)},[C]),(0,a.useEffect)(()=>{if(u)return;let e=!1;const t=["cities","companies","contracts","countries","job_sectors","remote_work_types"].reduce((t,n)=>{const a=d[n];return t[n]=a.filter(t=>{const a=c[n].some(e=>e.key===t);return a||(e=!0),a}),t},{});e&&n((0,i.KV)(t,!0))},[d,u,A]),(0,a.useEffect)(()=>{const e=C||q.A.getResumeId();n((0,J.UG)(A)),!1===g&&null===f?n((0,J.Fz)(e)):C&&!h&&n((0,l.m3)()),n(e?(0,W.YO)(q.A.getApplications(e)):(0,W.YO)(q.A.getApplications(q.A.generatedResumeIdKeyName)))},[]);const D=(0,F.xE)(window.location.href),{nextPageUrl:L,prevPageUrl:_}=(0,F.jX)(window.location.href,y,E);return a.createElement(a.Fragment,null,a.createElement(U.mg,null,a.createElement("title",null,w?r("seo_markup.result_page.search_offer_title",{postProcess:"interval",count:x,clientName:o.company_name,searchText:w,jobOffersCount:x}):r("seo_markup.result_page.all_offers_title",{postProcess:"interval",count:x,clientName:o.company_name,jobOffersCount:x})),a.createElement("meta",{name:"description",content:r("seo_markup.result_page.description",{postProcess:"interval",count:x,clientName:o.company_name,jobOffersCount:x})}),!w&&a.createElement(a.Fragment,null,a.createElement("meta",{property:"og:title",content:r("seo_markup.result_page.all_offers_title",{postProcess:"interval",count:x,clientName:o.company_name,jobOffersCount:x})}),a.createElement("meta",{property:"og:description",content:r("seo_markup.result_page.description",{postProcess:"interval",count:x,clientName:o.company_name,jobOffersCount:x})})),a.createElement("meta",{property:"og:url",content:D}),a.createElement("link",{rel:"canonical",href:D}),_&&a.createElement("link",{rel:"prev",href:_}),L&&a.createElement("link",{rel:"next",href:L})),a.createElement(te.im,null),a.createElement(t,null))};var ae=n(47056),re=n(85426),ie=n.n(re),le=n(15195),oe=n(71716);const se=e=>(e.offsetTop||0)-(parseInt(e.style.paddingTop||window.getComputedStyle(e).getPropertyValue("padding-top"))||0)-(parseInt(e.style.borderTopWidth||window.getComputedStyle(e).getPropertyValue("border-top-width"))||0);var Ae=n(19555);const ce=100;function de(e){let{bgColorName:t,smallSearchBar:n,isLandingPage:r=!1,view:i}=e;const{i18n:l}=(0,s.Bd)(),c=(0,L.Gb)(),d=(0,p.d7)(),u=(0,p.jL)(),g=(0,Y.W6)(),C=(0,p.GV)(m.TW),f=(0,p.GV)(m.As),[h,y]=(0,a.useState)([]),[E,M]=(0,a.useState)(!1),[x,w]=(0,a.useState)(f);(0,a.useEffect)(()=>{w(f)},[f]),(0,a.useEffect)(()=>g.listen((e,t)=>{if("POP"===t){const t=new URLSearchParams(e.search).get(F.wW)??"";if(f!==t){_({text:t,isHistoryPop:!0})}}}),[]);const _=e=>{u((0,oe.zw)(e.text,e.isHistoryPop)),e.isClearAction||e.isHistoryPop||I(e),c&&u((0,D.nD)()),C&&u((0,oe.u9)()),ae.Fr&&window.scrollTo({top:se(document.getElementById("result-page-top-anchor")),behavior:"smooth"})},I=e=>{const t=r?"[LP]":"[RP]";ie().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Search Section",EventAction:"Recherche texte",EventLibelle:`${t} - Recherche offre`}});const n=b.M$.SUBMIT_SEARCH_BAR,a={page:r?Ae.Bd.HOME:Ae.Bd.RESULTS,...e};u((0,b.Wf)(n,a))};return(0,a.useEffect)(()=>{x?d(async()=>{try{M(!0);const e=await(async e=>{const t={lang:l.language,country:(0,A.JJ)(l.language),input:e,enable_sectors_white_list:!0};return(await(0,o.zA)(t)).suggestions.slice(0,10).map(e=>({label:e.label}))})(x);y(e)}finally{M(!1)}},ce):y([])},[x]),a.createElement(i,{bgColorName:t,smallSearchBar:n,inputValue:x,loading:E,onChange:(e,t,n)=>{const a={text:t&&"object"==typeof t?t.label:t??"",isClearAction:!1},i="option"===e.target.attributes?.role?.value;r&&"clear"===n||("clear"===n&&(a.isClearAction=!0),"click"===e.type&&i&&(a.type=le.nX.AUTOCOMPLETE,a.submit_mode=le.Em.CLICK_ON_SUGGESTIONS),13===e.keyCode&&(a.type=le.nX.FREE,a.submit_mode=le.Em.ENTER_KEY),_(a))},onClick:()=>{const e={submit_mode:le.Em.UI_BUTTON,text:x,type:le.nX.FREE};_(e)},onInputChange:async(e,t)=>{w(t)},options:h})}var pe=n(68145);const me=(e,t,n,a,r)=>1===e.length?t(e[0]):2===e.length?`${t(e[0])}, ${t(e[1])}`:e.length>2?`${t(e[0])}, ${t(e[1])} + ${e.length-2} ${e.length-2<=1?n(a):n(r)}`:"",ue=e=>{let{view:t,...n}=e;const{t:r,i18n:i}=(0,s.Bd)(),l=(0,p.GV)(m.GQ),o=(0,p.GV)(m.qP),A=(0,p.GV)(m.lq),c=(0,p.GV)(m.su),d=(0,p.GV)(m.zG),u=(0,p.GV)(m.eO),g=(0,p.GV)(m.DB),C=(0,p.GV)(m.BP),f=me(l,e=>(0,h.LK)(e,i.language),r,"contract_filter.one_selected","contract_filter.multiple_selected"),y=me(A,e=>e,r,"country_filter.one_selected","country_filter.multiple_selected"),E=me(c,e=>e,r,"city_filter.one_selected","city_filter.multiple_selected"),M=me(d,e=>(0,pe._6)(e,i.language),r,"remote_work_type_filter.one_selected","remote_work_type_filter.multiple_selected"),x=me(u,e=>e,r,"company_filter.one_selected","company_filter.multiple_selected"),w=me(C,e=>e,r,"job_sector_filter.one_selected","job_sector_filter.multiple_selected");let D;for(const e of g)D=D?D+" • "+me(e.values,e=>e,r,"",""):me(e.values,e=>e,r,"","");const b=[f,y,E,M,x,w,D].filter(Boolean).join(" • ");return!o&&b?a.createElement(t,n,b):null},ge=e=>{let{view:t}=e;const n=(0,r.wA)(),{i18n:c}=(0,s.Bd)(),d=(0,A.JJ)(c.language),p=(0,a.useCallback)(e=>{n((0,i.ZY)(e)),n((0,l.Pd)())},[n]);return a.createElement(t,{onSuggestionSelected:p,fetchSuggestions:async e=>{const t={lang:c.language+"_"+d,text:e};let n=await(0,o.pC)(t);const a=n.list.map(e=>({id:e.source.id,category:e.source.category,label:e.source[t.lang].label,score:e.score}));return{total:n.numFound,suggestions:a}}})};var Ce=n(33976);const fe=()=>(0,S.Mz)(e=>e.search.skills,e=>e.search.hobbies,(e,t)=>[...e,...t]),he=e=>{let{view:t}=e;const n=(0,r.wA)(),o=(0,a.useMemo)(fe,[]),s=(0,r.d4)(e=>o(e)),A=(0,a.useCallback)(e=>{"HOBBIES"===(0,Ce.A)(s,["id",e])?.category?n((0,i.HS)(e)):n((0,i.eV)(e)),n((0,l.Pd)())},[n,s]);return a.createElement(t,{items:s,onRemoveItem:A})};var ye=n(56946);const Ee=()=>(0,S.Mz)(e=>e.suggestions.skills,e=>e.suggestions.hobbies,(e,t)=>[...e,...t]),Me=e=>{let{view:t}=e;const n=(0,r.wA)(),i=(0,a.useMemo)(Ee,[]),o=(0,r.d4)(e=>i(e));return a.createElement(t,{onAddItem:e=>{n((0,ye.QU)(e)),n((0,l.Pd)())},items:o})},xe=e=>{let{isMapDisplayed:t,onClick:n,view:i}=e;const l=(0,r.wA)();return a.createElement(i,{"data-testid":"cvc-toggle-map-button",onClick:()=>{n(),(()=>{const e=b.M$.TOGGLE_MAP_BUTTON,n={is_map_displayed:!t};l((0,b.Wf)(e,n))})()},isMapDisplayed:t})};var we=n(5369);const De=e=>{let{view:t}=e;const n=(0,r.wA)(),{config:l}=(0,we._r)(),o=(0,r.d4)(e=>e.search.useProfile),s=(0,a.useCallback)(e=>{const t=b.M$.TOGGLE_PROFILE_SWITCH,a={enable:e};n((0,b.Wf)(t,a)),l.analytics?.google_tag_manager?.active&&ie().dataLayer({dataLayer:{event:"EventGeneric",EventCat:"Toggle Profile",EventAction:"Toggle Profile Switch",EventLibelle:"[RP] - Toggle Profile Switch"}})},[l.analytics?.google_tag_manager?.active,n]),A=(0,a.useCallback)(e=>{n((0,i.yF)(e)),s(e)},[n,s]);return a.createElement(t,{toggleSwitch:A,isChecked:o})},be=e=>{let{view:t}=e;const{isMatching:n}=(0,r.d4)(e=>e),{useProfile:i,text:l,isFetching:o}=(0,r.d4)(e=>e.search),{id:s}=(0,r.d4)(e=>e.profile);let A="job_offers.results_title_without_profile_interval";return s&&i?A="job_offers.results_title_interval":l||(A="job_offers.results_title_without_resume"),a.createElement(t,{i18nKey:A,isLoading:n||o})},Le=e=>{let{view:t}=e;const n=(0,r.wA)(),{i18n:l}=(0,s.Bd)(),A=(0,a.useCallback)(e=>{n((0,i.aQ)(e))},[n]);return a.createElement(t,{onSuggestionSelected:A,fetchSuggestions:async e=>{const t={text:e,type:"city"};return{total:(n=await(0,o.IH)(t)).numFound,suggestions:n.suggestions.map(e=>({id:e.id,label:e.international_labels[l.language]?e.international_labels[l.language]:e.default_label,coordinates:e.coordinates?e.coordinates.lat+","+e.coordinates.lon:"",country:e.is_part_of_size>=1?e.is_part_of[0]:"",region:e.is_part_of_size>=2?e.is_part_of[1]:"",department:e.is_part_of_size>=3?e.is_part_of[e.is_part_of_size-1]:"",postal_code:e.postal_codes.length>=1?e.postal_codes[0]:""}))};var n}})},_e=e=>{let{view:t}=e;const n=(0,r.d4)(e=>e.search.workLocalities),l=(0,r.wA)(),o=(0,a.useCallback)(e=>{l((0,i.T1)(e))},[l]);return a.createElement(t,{items:n,onRemoveItem:o})}},94721:(e,t,n)=>{n.d(t,{u:()=>E});var a=n(14041),r=n(2345),i=n(39067),l=n.n(i),o=n(97434),s=n(51566),A=n(61631),c=n(58797),d=n(33131),p=n(45728),m=n(66341);const u=r.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 16px;
`,g=r.Ay.form`
  display: flex;
  justify-content: center;
  gap: 24px;
  margin-top: ${e=>{let{theme:t}=e;return t.template!==p.tC.BENTO_2024&&"16px"}};
  width: 100%;
  flex-wrap: wrap;
`,C=r.Ay.div`
  position: relative;
  display: flex;
  align-items: center;
  flex: 1;
  max-width: 240px;

  &:hover,
  &:active,
  &:focus {
    opacity: 0.85;
  }

  ${e=>{let{theme:t}=e;return`\n    transition: all ${t.transitions.duration.short}ms ease;\n  `}}
`,f=r.Ay.input`
  position: absolute;
  opacity: 0;
  height: 100%;
  width: 100%;
  cursor: pointer;
`,h=r.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  border-radius: 5px;
  padding: ${e=>{let{theme:t}=e;return t.template===p.tC.BENTO_2024?"16px 24px ":"24px"}};
  width: 100%;
  height: 100%;
  ${e=>{let{theme:t}=e;return`\n    background-color: ${(0,A.x6)(t.palette,A.ll,A.qf)}\n  `}}
`,y=(0,r.Ay)(c.fz)`
  margin-top: 16px;
  margin-bottom: 0;
`,E=e=>{let{uploadTitle:t,onFileChange:n}=e;const{t:i}=(0,o.Bd)(),l=(0,r.DP)(),A=t||i("upload_zone.mobile_title_2022");return a.createElement(u,null,l.template!==p.tC.BENTO_2024&&a.createElement(s._,{topLine:A,bottomLine:i("upload_zone.mobile_subtitle_2022")}),a.createElement(g,{action:"#",id:"dropzone-area"},a.createElement(C,null,a.createElement(f,{"data-testid":"cvc-resume-upload-input",type:"file",onChange:e=>{n(e.target.files)}}),a.createElement(h,null,a.createElement(d.A,{View:m.qb,size:36,withContrast:!0}),a.createElement(y,{autoContrast:!0},i("upload_zone.mobile_upload_2022")))),a.createElement(C,null,a.createElement(f,{"data-testid":"cvc-resume-upload-input",type:"file",accept:"image/*",capture:!0,onChange:e=>{n(e.target.files)}}),a.createElement(h,null,a.createElement(d.A,{View:m.PE,size:36,withContrast:!0}),a.createElement(y,{autoContrast:!0},i("upload_zone.mobile_camera_2022"))))))};E.propTypes={onFileChange:l().func.isRequired,uploadTitle:l().string}},95628:(e,t,n)=>{n.d(t,{A:()=>M});var a=n(14041),r=n(80503),i=n(12396),l=n(18307),o=n(97134),s=n(27502),A=n(95600),c=n(87448),d=n(37529),p=n(97434),m=n(2345),u=n(66341),g=n(74798);const C=(0,m.Ay)(g.A)`
  margin: 0;
`;function f(e){let{displayAnalysisInModal:t,onClose:n}=e;const{t:r}=(0,p.Bd)();return a.createElement(o.A,{alignItems:"center",direction:"row",justifyContent:"space-between",px:t?3:0,py:t?2.5:0},a.createElement(C,{variant:"h3"},r("upload_zone.title_analyse")),t&&a.createElement(d.A,{color:"inherit",onClick:n,size:"small",startIcon:a.createElement(u.MR,{width:14,height:14})},a.createElement(g.A,{variant:"span"},r("modal.close"))))}var h=n(65563);const y=(0,m.Ay)(h.$n)`
  span {
    font-size: 14px;
    font-weight: 400;
  }
`;function E(e){let{displayAnalysisInModal:t,refuseTos:n,acceptTos:r,acceptanceText:i}=e;const{t:l}=(0,p.Bd)();return a.createElement(A.A,{display:"flex",justifyContent:t?"space-between":"flex-start",p:t?3:0,width:"100%",gap:4},a.createElement(y,{fullWidth:!t,onClick:n,size:"small",variant:"outlined"},l("upload_zone.decline_terms_of_use")),a.createElement(y,{"data-testid":"cvc-widget-tos-btn-accept",fullWidth:!t,onClick:r,size:"small"},i))}const M=e=>{let{acceptTos:t,emailSubscribeIsChecked:n,refuseTos:d,toggleEmailChecked:p,displayAnalysisInModal:m=!1,i18nKey:u,acceptanceText:g}=e;const C=(0,l.Gb)();return a.createElement(r.A,{in:!0,appear:!0,timeout:100,classNames:"tfl"},a.createElement(o.A,{direction:"column",divider:m?a.createElement(s.A,null):void 0,spacing:m?0:3},a.createElement(f,{displayAnalysisInModal:m,onClose:d}),a.createElement(A.A,{sx:{px:m?{xs:3,sm:6}:0,py:m?{xs:4,sm:6}:0}},a.createElement(c.A,{i18nKey:u}),C&&a.createElement(i.A,{isChecked:n,toggleChecked:p,label:"upload_zone.email_subscribe_text"})),a.createElement(E,{displayAnalysisInModal:m,acceptTos:t,refuseTos:d,acceptanceText:g})))}}}]);