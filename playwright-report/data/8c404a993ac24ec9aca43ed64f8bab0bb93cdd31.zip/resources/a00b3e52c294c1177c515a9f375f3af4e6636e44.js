"use strict";(self.webpackChunkcareer_site_ui=self.webpackChunkcareer_site_ui||[]).push([[860],{21705:(e,t,n)=>{n.d(t,{k:()=>m});var i=n(12643),r=n(68e3);var a=n(59123),l=n(26270),o=n(95345);const s=new o.wQ.Entity("jobOffers"),p=new o.wQ.Object({list:new o.wQ.Array(s)}),m=e=>async t=>{const n={jobs:[],skills:[],trainings:[],hobbies:[],cities:[],departments:[],regions:[],countries:[],contracts:[],job_sectors:[],remote_work_types:[],limit:e,offset:0,sort:{date:"desc"}};t({type:r.gr,payload:{isFetching:!0}});try{const e=await(0,a.zF)(n,p);t((e=>({type:r.rn,payload:{isFetching:!1,list:(0,i.A)(e.entities.jobOffers),total:e.result.total}}))(e)),t((0,l.v3)(e,null,null))}catch(e){t((e=>({type:r.ft,payload:{isFetching:!1,err:{name:e.name,message:e.message,errorCode:e.errorCode,statusCode:e.statusCode}}}))(e))}}},82860:(e,t,n)=>{n.r(t),n.d(t,{default:()=>xc});var i={};n.r(i),n.d(i,{CareerLandingPage:()=>ri});var r={};n.r(r),n.d(r,{CareerLandingPage:()=>Ri});var a={};n.r(a),n.d(a,{CareerLandingPage:()=>or});var l={};n.r(l),n.d(l,{CareerLandingPage:()=>ts});var o={};n.r(o),n.d(o,{CareerLandingPage:()=>gc});var s=n(14041),p=n(86090),m=n(68153),c=n(87433),d=n(45728),u=n(85423),g=n(43500),h=n(45759),x=n(80379);const b=e=>{let{pages:t={},productType:n}=e;const{CareerLandingPage:i}=t;return(0,u.iS)(),s.createElement(h.A,null,s.createElement(p.qh,{render:e=>{let{location:t}=e;return s.createElement(g.r,{location:t},n===d.ch.CVC_SC?s.createElement(p.qh,{exact:!0,path:x.J.HOME,component:i}):s.createElement(p.qh,{exact:!0,path:x.J.HOME},s.createElement(p.rd,{to:x.J.SEARCH})))}}))};var w=n(2345),f=n(61361),y=n(49617),E=n(97519),v=n(97434),A=n(99142),k=n(59044),$=n(65563),_=n(61631),S=n(58797);const z=(0,w.Ay)(k.RC)`
  width: 100%;

  --swiper-navigation-color: #ffffff;
  --swiper-navigation-size: 1.25rem;
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,"secondary","main")}};
  --swiper-pagination-bullet-inactive-color: transparent;
  --swiper-pagination-bullet-size: 0.875rem;

  .swiper-button-prev,
  .swiper-button-next {
    width: 48px;
    height: 48px;
    top: 50%;
    transform: translateY(-50%);
    border-radius: 50%;
    transition: ${e=>{let{theme:t}=e;return`background-color ${t.transitions.duration.standard}ms ease`}};

    &:hover,
    &:focus {
      background-color: rgba(255, 255, 255, 0.25);
    }

    &.swiper-button-disabled {
      display: none;
    }
  }

  .swiper-button-prev {
    left: 15vh;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("largeDesktop")}} {
      left: 10vh;
    }

    ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
      left: 4vh;
    }
  }

  .swiper-button-next {
    right: 15vh;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("largeDesktop")}} {
      right: 10vh;
    }

    ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
      right: 4vh;
    }
  }

  .swiper-pagination {
    bottom: ${e=>{let{theme:t}=e;return t.template===d.tC.LATERAL_BAR_2022?"32px":"20vh"}} !important;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      bottom: 32px !important;
    }
  }

  .swiper-pagination-bullet {
    opacity: 1;
    border: 1px solid
      ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,"secondary","main")}};
  }

  ${e=>{let{theme:t}=e;return t.template===d.tC.LATERAL_BAR_2022&&"\n    .swiper-button-prev,\n    .swiper-button-next {\n      top: auto;\n      bottom: 12rem;\n    }\n  "}}

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    .swiper-button-prev,
    .swiper-button-next {
      display: none;
    }
  }
`,C=(0,w.Ay)(z)`
  order: -1;
`,L=(0,w.Ay)(k.qr)`
  &.swiper-slide {
    align-self: stretch;
    height: auto;
  }
`,T=(0,w.Ay)(y.A)`
  --container-horizontal-padding: 2rem;
  --container-vertical-padding: var(--landing-cover-carousel-margin-top);

  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: ${e=>{let{theme:t}=e;return t.template===d.tC.LATERAL_BAR_2022?"flex-end":"center"}};
  align-items: center;
  gap: 2rem;
  width: 100%;
  height: 100%;
  max-width: ${e=>{let{theme:t}=e;return t.breakpoints.values.laptop}}px;
  min-height: max(100vh, 650px);
  padding: var(--container-vertical-padding) var(--container-horizontal-padding);

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    gap: 1.5rem;
    max-width: ${e=>{let{theme:t}=e;return t.breakpoints.values.tablet}}px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    --container-horizontal-padding: 1.5rem;

    max-width: ${e=>{let{theme:t}=e;return t.breakpoints.values.mobile}}px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    --container-vertical-padding: var(
      --landing-cover-carousel-margin-top-mobile
    );
  }

  ${e=>{let{theme:t}=e;return t.template===d.tC.LATERAL_BAR_2022&&`\n    justify-content: flex-end;\n    max-width: ${t.breakpoints.values.tablet}px;\n    padding-bottom: 80px;\n\n    ${t.breakpoints.between("laptop","desktop")} {\n      max-width: ${t.breakpoints.values.mobile}px;\n    }\n  `}}

  & > * {
    z-index: 1;
  }
`,I=(0,w.Ay)(y.A)`
  display: flex;
  justify-content: center;
`,P=(0,w.Ay)(S.o5)`
  display: block;
  margin: 0;
  text-align: center;
  font-size: 2.5rem;
  font-weight: 400;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 2.1rem;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    font-size: 1.8rem;
  }
`,B=(0,w.Ay)(S.o5)`
  display: block;
  text-align: center;
  line-height: 1.5rem;
  font-size: 1.25rem;
  font-weight: 400;
  margin: 0;

  p {
    margin: 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1rem;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    font-size: 14px;
  }
`,N=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.XB)(),n=(0,u.Ee)(),i=t.length>1;return s.createElement(C,{loop:i,navigation:i,keyboard:!0,watchSlidesProgress:!0,modules:[A.Vx,A.dK,A.s3],pagination:{clickable:!0}},t.map((t,i)=>s.createElement(L,{key:i},r=>{let{isActive:a,isVisible:l}=r;return s.createElement(s.Fragment,null,s.createElement(S.DN,{alt:`photo carousel numéro ${i}`,src:t.bgImage,bgPosition:t.bgPosition}),s.createElement(T,null,s.createElement(P,{autoContrast:!0,variant:"h2",dangerouslySetInnerHTML:{__html:E.A.sanitize(t.title,{USE_PROFILES:{html:!0}})}}),t.paragraph&&s.createElement(B,{autoContrast:!0,variant:"p",dangerouslySetInnerHTML:{__html:E.A.sanitize(t.paragraph,{USE_PROFILES:{html:!0}})}}),n&&s.createElement(I,{disableGutters:!0},s.createElement(S.tm,null)),s.createElement($.$n,{className:"swiper-no-swiping",colorName:_.ll,disabled:!a||!l,to:x.J.SEARCH},e("career_website_landing.discover_offers"))))})))};var R=n(22854),M=n(95600),F=n(74798),O=n(84595),j=n(13568),V=n(31048);const D=w.Ay.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  width: 100%;
  position: absolute;
  z-index: 1;
  bottom: 0;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}),
    (max-height: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    position: static;
    padding: 4rem 0;
    background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.ll,_.qf)}};
  }
`,H=(0,w.Ay)(O.hE)`
  font-size: 2rem;
  margin: 0;
  width: 100%;
  text-align: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1.5rem;
    margin-bottom: 16px;
  }
`,q=(0,w.Ay)(R.A)`
  width: 200px;
  height: 32px;
  background-color: lightgrey;
`,U=(0,w.Ay)(F.A)`
  font-size: 1.25rem;
  margin: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1rem;
  }
`,X=(0,w.Ay)(F.A)`
  margin: 0 18px;
  font-size: 1.7em;
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    display: none;
  }
`,W=(0,w.Ay)(j.g)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    order: 2;
  }
`,J=w.Ay.div`
  width: 100%;
  margin: 0 auto;
  padding: 0 24px;
  display: flex;
  justify-content: center;
  transform: translateY(50%);

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    transform: translateY(0);
    margin: 48px auto;
  }
`,G=()=>{const{t:e}=(0,v.Bd)(),{config:t}=(0,m._r)(),n=(0,u.GV)(V.HA),i=(0,u.GV)(V.Vd);return s.createElement(M.A,{position:"relative",width:"100%"},s.createElement(D,null,s.createElement(H,{variant:"h2",autoContrast:!0},e("career_website_landing.search_section.title.bottom_line",{client_name:t.company_name})),i?s.createElement(q,null):s.createElement(U,{autoContrast:!0},e("career_website_landing.search_section.title.top_line",{count:n})),s.createElement(X,{variant:"span",autoContrast:!0},"|"),s.createElement(W,{to:x.J.SEARCH,"data-testid":"cvc-career-landing-btn-all-offer"},e("career_website_landing.search_section.see_all_2022")),s.createElement(J,null,s.createElement(O.C8,null))))};var Z=n(62004),K=n(8049),Q=n(54179);const Y=()=>{const{t:e,i18n:t}=(0,v.Bd)(),{config:n}=(0,m._r)(),i=(0,u.GV)(V.HA)||0,r=n.company_name,a=(0,K.y5)(window.location.href),l=e("seo_markup.career_site_home_page.title",{clientName:r}),o=e("seo_markup.career_site_home_page.description",{postProcess:"interval",count:i,clientName:r,jobOffersCount:i});return s.createElement(s.Fragment,null,s.createElement(Z.mg,{htmlAttributes:{lang:t.language}},s.createElement("title",null,l),s.createElement("meta",{name:"description",content:o}),s.createElement("link",{rel:"canonical",href:a}),s.createElement("meta",{property:"og:title",content:e("seo_markup.career_site_home_page.title",{clientName:r})}),s.createElement("meta",{property:"og:description",content:e("seo_markup.career_site_home_page.description",{postProcess:"interval",count:i,clientName:r,jobOffersCount:i})}),s.createElement("meta",{property:"og:url",content:a})),s.createElement(Q.A,null))};var ee=n(38544),te=n(82202),ne=n(96362),ie=n(68382),re=n(23099);const ae=e=>{let{view:t}=e;const n=(0,s.useRef)(),{config:i}=(0,m._r)(),r=(0,ee.d4)(e=>e.profile.id),a=(0,ee.d4)(e=>e.search.results),l=(0,ee.wA)();return(0,s.useEffect)(()=>{(0,re.oU)("page.display",{page_category:"HP",page_subject:"Home",page_type:"Home",page_hostname:window.location.hostname,site_name:i.company_name})},[]),(0,s.useEffect)(()=>{const e=ie.M$.DISPLAYED_HOMEPAGES;l((0,ie.Wf)(e,{}))},[l]),(0,s.useEffect)(()=>{n.current||(n.current=!0,null!==r&&l((0,te.sb)()),null!==a&&l((0,ne.uz)()))},[l,r,a]),s.createElement(t,null)};var le=n(29298),oe=n(94721);const se=w.Ay.div`
  display: block;
  width: 100%;
  background-color: ${e=>{let{theme:t}=e;return t.template!==d.tC.BENTO_2024?"white":"transparent"}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: ${e=>{let{theme:t}=e;return t.template===d.tC.LATERAL_BAR_2022?"0 0 20px":t.template===d.tC.BENTO_2024?"0":"44px 0px 64px"}};
  }
`,pe=e=>{let{displayAnalysisInModal:t=!1,mobileUploadZoneView:n=oe.u,...i}=e;return s.createElement(se,i,s.createElement(le.A,{mobileUploadZoneView:n,displayAnalysisInModal:t}))};var me=n(3548),ce=n(59437),de=n(51566),ue=n(89575);const ge=(0,w.Ay)(k.RC)`
  --swiper-navigation-size: 2.5rem;
  --swiper-navigation-color: ${e=>{let{theme:t}=e;return t.palette.common.white}};
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return t.palette.common.white}};
  --swiper-pagination-bullet-inactive-color: ${e=>{let{theme:t}=e;return t.palette.common.white}};
  --swiper-pagination-bullet-size: 0.8rem;
`,he=w.Ay.div`
  position: absolute;
  left: 0;
  bottom: 0;
  display: flex;
  gap: 24px;

  .swiper-button-prev,
  .swiper-button-next {
    position: static;
    display: inline-block;
    vertical-align: middle;
  }

  margin: 0;
`,xe=e=>{const{control:t,...n}=e||{};if(t){if(Array.isArray(t)){return{control:t.filter(e=>e&&!0!==e.destroyed),...n}}return{control:t.destroyed?void 0:t,...n}}return n},be=e=>{let{isMultiSlides:t=!1,children:n,blockName:i,enablePagination:r=!0,enableNavigation:a=!0,controller:l,...o}=e;const p=`swiper-${i}-prev`,m=`swiper-${i}-next`;return s.createElement(ge,(0,ue.A)({loop:o.loop??t,spaceBetween:16,keyboard:!0,watchSlidesProgress:!0,modules:[A.Vx,A.dK,A.s3,A.xI],pagination:{clickable:!0,enabled:r&&t},navigation:{prevEl:`#${p}`,nextEl:`#${m}`,clickable:!0},controller:xe(l)},o),n,a&&t&&s.createElement(he,null,s.createElement("div",{id:p,className:"swiper-button-prev"}),s.createElement("div",{id:m,className:"swiper-button-next"})))};var we=n(56545);const fe=w.Ay.div`
  width: 100%;
  --swiper-navigation-size: 1rem;
  --swiper-navigation-color: #ffffff;

  position: relative;
  .swiper-button-disabled {
    display: none;
  }
  .swiper-button-prev,
  .swiper-button-next {
    height: 28px;
    width: 28px;
    padding: 1rem;
    border-radius: 50%;
    margin-top: 0;
    background-color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
    color: white;
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
      display: none;
    }
  }
  .swiper-button-prev {
    left: 0;
    transform: translate(-50%, -50%);
  }

  .swiper-button-next {
    right: 0;
    transform: translate(50%, -50%);
  }
`,ye=(0,w.Ay)(be)`
  width: 100%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    margin: 0;
    .swiper-slide {
      max-width: 70%;
      &:last-child {
        margin-right: 16px;
      }
    }
  }

  @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.tablet+1}px`}}) and (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    margin: 0;
    .swiper-slide {
      max-width: 37%;
      &:last-child {
        margin-right: 16px;
      }
    }
  }
`,Ee=e=>{let{children:t,smallBreakpoint:n="smallDevicesLimit",blockName:i,loop:r=!1,...a}=e;const l=(0,w.DP)();return s.createElement(fe,{className:a.className},s.createElement(ye,(0,ue.A)({enablePagination:!1,enableNavigation:!1,isMultiSlides:a.isMultiSlides,loop:r,blockName:i,slidesPerView:"auto",breakpoints:{[l.breakpoints.values[n]]:{slidesPerView:a.nbSlides||4}}},a),t),s.createElement("div",{id:`swiper-${i}-prev`,className:"swiper-button-prev"}),s.createElement("div",{id:`swiper-${i}-next`,className:"swiper-button-next"}))},ve=(0,w.Ay)(O.aF)`
  & {
    max-width: 60vw;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.tablet}px`}}) {
    & {
      max-width: 90vw;
    }
  }
`,Ae=w.Ay.div`
  --swiper-navigation-color: #ffffff;
  --swiper-navigation-size: 1rem;

  position: relative;

  .swiper-button-disabled {
    display: none;
  }

  .swiper-button-prev,
  .swiper-button-next {
    background-color: black;
    padding: 1rem;
    border-radius: 50%;
    margin-top: 0;
    z-index: 10;
    height: 40px;
    width: 40px;
  }

  .swiper-button-prev {
    left: 0;
    transform: translate(-50%, -50%);
  }

  .swiper-button-next {
    right: 0;
    transform: translate(50%, -50%);
  }
`,ke=(0,w.Ay)(Ee).attrs({nbSlides:1,smallBreakpoint:"smallDevicesLimit"})`
  margin-top: 0;
  width: 100%;

  .swiper-wrapper {
    width: 100%;
    margin: 0 auto;
  }

  .swiper-slide {
    width: 100%;
    max-width: 100%;
  }
`,$e=w.Ay.img`
  width: 100%;
  object-fit: contain;
  border-radius: 16px;
`,_e=w.Ay.h3`
  font-weight: bold;
  text-align: center;
  margin-top: 1rem;
`,Se=w.Ay.p`
  font-weight: normal;
  text-align: center;
  margin-top: 0.5rem;
`,ze=e=>{let{open:t,onClose:n,title:i,subtitle:r,items:a,initialSlide:l=0,onSlideChange:o,blockName:p="modal-swiper"}=e;return s.createElement(ve,{open:t,onClose:n},s.createElement(O.aF.Header,{title:i,subtitle:r,onClose:n}),s.createElement(O.aF.Content,null,s.createElement(Ae,null,s.createElement(ke,{blockName:p,enableNavigation:!0,enablePagination:!1,initialSlide:l,onSlideChange:e=>o?.(e),spaceBetween:16,centerInsufficientSlides:!1,navigation:{prevEl:`#swiper-${p}-prev`,nextEl:`#swiper-${p}-next`},keyboard:!0,modules:[A.Vx,A.s3]},a.map((e,t)=>s.createElement(k.qr,{key:t},s.createElement($e,{src:e.srcFullSize,alt:e.title||`Slide ${t+1}`}),e.title&&s.createElement(_e,null,e.title),e.description&&s.createElement(Se,null,e.description)))),s.createElement("div",{id:`swiper-${p}-prev`,className:"swiper-button-prev"}),s.createElement("div",{id:`swiper-${p}-next`,className:"swiper-button-next"}))))},Ce=(0,w.Ay)(ce.m)`
  position: relative;

  .swiper-button-disabled {
    display: none;
  }

  .swiper-button-prev,
  .swiper-button-next {
    height: 28px;
    width: 28px;
    top: 65%;
    color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};

    ${e=>{let{theme:t}=e;return t.breakpoints.down("smallDevicesLimit")}} {
      display: none;
    }
  }

  .swiper-button-prev {
    left: -32px;
  }

  .swiper-button-next {
    right: -32px;
  }
`,Le=(0,w.Ay)(be)`
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return t.palette.secondary.main}};

  &.swiper {
    padding-bottom: 12px;
  }

  .swiper-pagination {
    display: none;
  }

  .swiper-slide {
    height: auto;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding-bottom: 40px;
    .swiper-pagination {
      position: absolute;
      display: block;
      bottom: 0;
    }

    .swiper-slide {
      max-width: 33%;
    }

    .swiper-slide:last-child {
      padding-right: 16px;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    .swiper-slide {
      max-width: 50%;
    }
  }
`,Te=(0,w.Ay)(k.qr)`
  ${e=>{let{theme:t}=e;return t.breakpoints.up("tablet")}} {
    padding: 0.5vw;
  }

  &:last-child {
    margin-right: 0 !important;
  }
`,Ie=w.Ay.img`
  width: 100%;
  max-width: 400px;
  max-height: 250px;
  object-fit: contain;
  border-radius: 8px;
`,Pe=w.Ay.a`
  cursor: pointer;
`,Be=w.Ay.div`
  display: flex;
  justify-content: center;
`,Ne=()=>{const{breakpoints:e={}}=(0,w.DP)(),t=(0,u.dn)(),{isAboveOrEqualToBreakpoint:n}=(0,we.d)(),i=t.gallery,r=i?.pictures||[],a=r.length>3?3:r.length,l="gallery",[o,p]=(0,s.useState)(!1),[m,c]=(0,s.useState)(0);if(a<1)return null;return s.createElement(me.w,null,s.createElement(Ce,null,s.createElement(de._,{topLine:i.title,bottomLine:i.subTitle}),s.createElement(Le,{enablePagination:!1,enableNavigation:!1,blockName:l,slidesPerView:"auto",centerInsufficientSlides:!0,breakpoints:{[e.tablet]:{slidesPerView:a}},spaceBetween:n(e.tablet)?16:32},i.pictures.map((e,t)=>s.createElement(Te,{key:t},s.createElement(Be,null,e.src?s.createElement(Pe,{onClick:()=>(e=>{c(e),p(!0)})(t)},s.createElement(Ie,{src:e.src,alt:e.title||`Image ${t+1}`})):s.createElement(Ie,{src:e.src,alt:e.title||`Image ${t+1}`}))))),s.createElement("div",{id:`swiper-${l}-prev`,className:"swiper-button-prev"}),s.createElement("div",{id:`swiper-${l}-next`,className:"swiper-button-next"})),o&&s.createElement(ze,{open:o,onClose:()=>p(!1),title:i.title,subtitle:i.subTitle,items:r,initialSlide:m,blockName:"gallery-modal"}))};var Re=n(47056),Me=n(68858),Fe=n(39234);const Oe=e=>{const t=(0,u.dn)(),n=(0,Fe.W)(t?.parallax,Re.Fr);return n?s.createElement(me.w,e,s.createElement(Me.zE,null,s.createElement(Me.y,{layers:[{image:n,amount:.4}],style:{height:450}}))):null};var je=n(47603),Ve=n(8877),De=n(36080);const He=(0,w.Ay)(ce.m)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding-right: 0;
  }
`,qe=w.Ay.div`
  --swiper-navigation-color: #ffffff;
  --swiper-navigation-size: 1rem;

  position: relative;

  .swiper-button-disabled {
    display: none;
  }

  .swiper-button-prev,
  .swiper-button-next {
    background-color: black;
    padding: 1rem;
    border-radius: 50%;
    margin-top: 0;
  }

  .swiper-button-prev {
    left: 0;
    transform: translate(-50%, -50%);
  }

  .swiper-button-next {
    right: 0;
    transform: translate(50%, -50%);
  }
`,Ue=(0,w.Ay)(k.RC)`
  .swiper-slide {
    height: auto;
  }

  @media (max-width: 768px) {
    .swiper-slide {
      max-width: 70%;
    }

    .swiper-slide:last-child {
      padding-right: 16px;
    }
  }
`,Xe=(0,w.Ay)(je.A)`
  gap: 1rem;
`,We=(0,w.Ay)(F.A)`
  color: ${De.c3[900]};
  font-size: 1rem;
  line-height: 1.5;
  margin: 0;
  white-space: pre-line;

  ul {
    padding: 0;
    margin: 0;
    margin-left: 1rem;

    p {
      margin: 0 0 0.3rem 0;
    }
  }
`,Je=(0,w.Ay)(F.A)`
  font-size: 1rem;
  line-height: 1.15;
  margin: 0;
  font-weight: 600;
  // this minimum height of the titles allows to align the texts below them
  min-height: 2.5rem;
`,Ge=()=>{const{breakpoints:e={}}=(0,w.DP)(),t=(0,u.dn)(),n=t?.advantages?.list||[],i=t?.advantages?.title,r=t?.advantages?.subTitle;return n.length<1?null:s.createElement(me.w,null,s.createElement(He,null,s.createElement(de._,{topLine:i,bottomLine:r}),s.createElement(qe,null,s.createElement(Ue,{slidesPerView:"auto",spaceBetween:16,breakpoints:{[e.tablet]:{slidesPerView:Math.ceil(2)},[e.laptop]:{slidesPerView:n.length<4?n.length:4}},navigation:{prevEl:"#swiper-company-advantages-prev",nextEl:"#swiper-company-advantages-next",clickable:!0},keyboard:!0,modules:[A.Vx,A.s3]},n.map((e,t)=>s.createElement(k.qr,{key:t},s.createElement(Xe,{bgColorName:"secondary"},s.createElement(Je,{autoContrast:!0},e.title),s.createElement(We,{autoContrast:!0,dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text,{USE_PROFILES:{html:!0}})}}))))),s.createElement(Ve.rb,{up:!0},s.createElement("div",{id:"swiper-company-advantages-prev",className:"swiper-button-prev"}),s.createElement("div",{id:"swiper-company-advantages-next",className:"swiper-button-next"})))))};var Ze=n(39067),Ke=n.n(Ze);const Qe=(0,w.Ay)(me.w)`
  padding: ${e=>{let{theme:t}=e;return t.template===d.tC.HORIZONTAL_BAR_2022?"0 0 64px 0":"0"}};
  margin: ${e=>{let{theme:t}=e;return t.template===d.tC.HORIZONTAL_BAR_2022?"0":"0 0 64px 0"}};
`,Ye=w.Ay.div`
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.QZ,_.qf)}};
  padding-bottom: 36px;

  h2 {
    margin-bottom: 0;
  }
`,et=(0,w.Ay)(k.RC)`
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return t.palette.secondary.main}};

  .swiper-pagination {
    display: none;
    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      display: block;
      bottom: 32px !important;
      transform: translate(0px, 50%);
    }
  }

  .swiper-slide {
    height: auto;
  }
`,tt=w.Ay.div`
  display: flex;
  flex-wrap: wrap;
  height: 100%;
  min-height: 25vw;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    height: auto;
    min-height: initial;
  }
`,nt=w.Ay.div`
  display: block;
  width: ${e=>{let{imageWidth:t}=e;return t||"50%"}};
  height: 100%;
  background-image: url(${e=>{let{image:t}=e;return t}});
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
  border-radius: ${e=>{let{theme:t}=e;return t.template===d.tC.HORIZONTAL_BAR_2022?"20px":"0"}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    width: 100%;
    height: 300px;
    border-radius: 0;
  }
`,it=w.Ay.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 64px;
  width: ${e=>{let{imageWidth:t}=e;return`calc(100% - ${t})`||"50%"}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    width: 100%;
    padding: 32px 32px 64px 32px;
    justify-content: flex-start;

    ${e=>{let{theme:t,bgColorName:n}=e;return t.template===d.tC.HORIZONTAL_BAR_2022&&n&&`\n      width: 90%;\n      // Moves the text over the image\n      margin: -100px auto 0 auto;\n      border-radius: 8px;\n      background-color: ${(0,_.x6)(t.palette,n,_.qf)};\n    `}};
  }

  h3 {
    font-size: ${e=>{let{theme:t}=e;return t.template===d.tC.CLASSIC_2022?"2rem":"1.25rem"}};
    font-weight: 600;
    margin-top: 0;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      font-size: ${e=>{let{theme:t}=e;return t.template===d.tC.CLASSIC_2022?"1.25rem":"1rem"}};
    }
  }

  p {
    font-size: 1rem;
    margin: 0;
    max-width: 35vw;
    line-height: 1.5;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      max-width: none;
    }
  }
`,rt=w.Ay.div`
  --swiper-navigation-color: ${e=>{let{theme:t,bgColorName:n}=e;return n?(0,_.Vh)((0,_.x6)(t.palette,n,_.qf),t.palette):t.palette.text.primary}};
  --swiper-navigation-size: 1.25rem;

  display: flex;
  align-items: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("tablet")}} {
    position: absolute;
    bottom: 32px;
  }

  .swiper-button-prev,
  .swiper-button-next {
    position: static;
    display: inline-block;
    vertical-align: middle;
    margin: 0;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      display: none;
    }
  }

  span {
    font-size: 0.875rem;
    margin: -2px 8px 0 8px;
  }
`,at=(0,w.Ay)(ce.m)`
  padding: 0;
`,lt=(0,w.Ay)(F.A)`
  white-space: pre-line;
  ul {
    padding: 0;
    margin: 0.5rem 0 0 1rem;
  }
`,ot=e=>{let{imageWidth:t="50%"}=e;const{template:n}=(0,w.DP)(),i=(0,u.dn)(),[r,a]=(0,s.useState)(0),l=n===d.tC.HORIZONTAL_BAR_2022,o=l?_.QZ:_.ll,p=i?.briefAndPictures?.diapositives||[],m=i?.briefAndPictures?.title,c=i?.briefAndPictures?.subtitle;return p.length<1?null:s.createElement(Qe,{bgColorName:o},s.createElement(at,{full:!l},m&&s.createElement(Ye,{bgColorName:o},s.createElement(de._,{topLine:m,bottomLine:c})),s.createElement(et,{effect:"fade",fadeEffect:{crossFade:!0},loop:!0,navigation:{prevEl:"#swiper-company-brief-prev",nextEl:"#swiper-company-brief-next"},keyboard:!0,modules:[A._R,A.Vx,A.dK,A.s3],pagination:{clickable:!0},onRealIndexChange:e=>{a(e.realIndex)}},p.map((e,n)=>s.createElement(k.qr,{key:n},s.createElement(tt,null,s.createElement(nt,{image:e.image,imageWidth:t}),s.createElement(it,{imageWidth:t,bgColorName:o},s.createElement(lt,{autoContrast:!0,variant:"h3"},e.title),s.createElement(lt,{autoContrast:!0,variant:"p",dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text||"",{USE_PROFILES:{html:!0},ADD_ATTR:["target","rel"]})}}),p.length>1&&s.createElement(Ve.rb,{up:!0},s.createElement(rt,{bgColorName:o},s.createElement("div",{id:"swiper-company-brief-prev",className:"swiper-button-prev"}),s.createElement(F.A,{autoContrast:!0,variant:"span"},r+1+"/"+p.length),s.createElement("div",{id:"swiper-company-brief-next",className:"swiper-button-next"}))))))))))};ot.propTypes={imageWidth:Ke().string};const st=(0,w.Ay)(ce.m)`
  display: flex;
  flex-direction: column;
  gap: 28px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    gap: 0;
  }

  .swiper-button-disabled {
    display: none;
  }
`,pt=w.Ay.div`
  position: relative;
  width: 100%;

  --swiper-navigation-size: 32px;
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return t.palette.secondary.main}};

  .swiper-button-prev,
  .swiper-button-next {
    color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};

    ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
      display: none;
    }
  }

  .swiper-button-prev {
    left: -32px;
  }

  .swiper-button-next {
    right: -32px;
  }
`,mt=(0,w.Ay)(be)`
  .swiper-pagination {
    display: none;
  }

  .swiper-slide {
    height: auto;
    width: auto;
    display: flex;
    justify-content: center;
    align-content: center;
    align-items: center;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    .swiper-pagination {
      position: absolute;
      display: block;
      bottom: 0;
    }

    .swiper-slide {
      max-width: 33%;
    }
  }
`,ct=(0,w.Ay)(k.qr)`
  &:last-child {
    margin-right: 0 !important;
  }
`,dt=w.Ay.img`
  width: 100%;
  max-width: 150px;
  max-height: 150px;
  object-fit: contain;
`,ut=w.Ay.a`
  cursor: pointer;
`,gt=w.Ay.div`
  display: flex;
  justify-content: center;
  height: 100%;
`,ht=()=>{const{breakpoints:e}=(0,w.DP)(),t=(0,u.wT)(),{isAboveOrEqualToBreakpoint:n}=(0,u.dv)();if(!t?.certifications.length)return null;const i="certifications",{certifications:r,subTitle:a,title:l}=t;return s.createElement(me.w,null,s.createElement(st,null,s.createElement(de._,{topLine:l,bottomLine:a}),s.createElement(pt,null,s.createElement(mt,{enablePagination:!1,enableNavigation:!1,blockName:i,slidesPerView:"auto",centerInsufficientSlides:!0,breakpoints:{[e.values.tablet]:{slidesPerView:r.length>4?4:"auto"}},spaceBetween:n("tablet")?64:16},r.map((e,t)=>s.createElement(ct,{key:t},s.createElement(gt,null,e.url?s.createElement(ut,{href:e.url,target:"_blank",rel:"noopener noreferrer"},s.createElement(dt,{src:e.logo,alt:""})):s.createElement(dt,{src:e.logo,alt:""}))))),s.createElement("div",{id:`swiper-${i}-prev`,className:"swiper-button-prev"}),s.createElement("div",{id:`swiper-${i}-next`,className:"swiper-button-next"}))))};var xt=n(19996),bt=n(66341),wt=n(8544);const ft={[wt.Te.activity]:bt.$7,[wt.Te.apartment]:bt.A9,[wt.Te.atSign]:bt.E1,[wt.Te.cake]:bt.X7,[wt.Te.clock]:bt._L,[wt.Te.gender]:bt.lQ,[wt.Te.graduationCap]:bt.aw,[wt.Te.heartHands]:bt.q1,[wt.Te.heartHandshake]:bt.S8,[wt.Te.location]:bt.ft,[wt.Te.people]:bt.aO,[wt.Te.phone]:bt.st,[wt.Te.receiptLong]:bt.R0,[wt.Te.rocket]:bt.ol,[wt.Te.route]:bt.Ll,[wt.Te.shoppingCart]:bt.AM,[wt.Te.star]:bt.lV,[wt.Te.storefront]:bt.u6,[wt.Te.tag]:bt.cD,[wt.Te.truck]:bt.pN,[wt.Te.verified]:bt._$,[wt.Te.webAsset]:bt.tS,[wt.Te.work]:bt.ov};var yt=n(33131);const Et=w.Ay.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;

  svg {
    margin: 0 auto;
  }

  h4 {
    font-size: 1.25rem;
    font-weight: 600;
    padding: 0.5rem 2rem;
    margin: 0;
  }

  @media (max-width: 900px) {
    h4 {
      font-size: 1rem;
    }
  }

  span {
    display: block;
    font-weight: 500;
  }
`,vt=e=>{let{name:t,size:n}=e;const i={size:n,withContrast:!0},r=ft[t]||ft.people;return s.createElement(yt.A,(0,ue.A)({View:r},i))},At=w.Ay.span`
  margin-top: 4px;
  p {
    margin: 0;
  }
`,kt=()=>{const e=(0,u.dn)(),t=e?.keyInformations;return t?.length?s.createElement(me.w,null,s.createElement(ce.m,null,s.createElement(xt.Ay,{container:!0,spacing:2},t.map((e,t)=>s.createElement(xt.Ay,{key:t,item:!0,xs:6,md:3},s.createElement(Et,null,s.createElement(vt,{name:e.icon,size:50}),s.createElement(F.A,{variant:"h4",autoContrast:!0},e.title,e.description&&s.createElement(At,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.description,{USE_PROFILES:{html:!0}})}})))))))):null};var $t=n(53416);const _t=(0,w.Ay)(ce.m)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding-right: 0;
  }
`,St=w.Ay.div`
  --swiper-navigation-color: #ffffff;
  --swiper-navigation-size: 1rem;

  position: relative;

  .swiper-button-disabled {
    display: none;
  }

  .swiper-button-prev,
  .swiper-button-next {
    background-color: black;
    padding: 1rem;
    border-radius: 50%;
    margin-top: 0;
  }

  .swiper-button-prev {
    left: 0;
    transform: translate(-50%, -50%);
  }

  .swiper-button-next {
    right: 0;
    transform: translate(50%, -50%);
  }
`,zt=(0,w.Ay)(k.RC)`
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return t.palette.secondary.main}};

  .swiper-pagination {
    display: none;
  }

  .swiper-wrapper {
    margin-bottom: 1px; // Prevent the 1px border to be hidden.
  }

  .swiper-slide {
    height: auto;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding-bottom: 40px !important;

    .swiper-pagination {
      position: absolute;
      display: block;
      bottom: 0;
    }

    .swiper-slide {
      max-width: 70%;
    }

    .swiper-slide:last-child {
      padding-right: 16px;
    }
  }
`,Ct=(0,w.Ay)(je.A)`
  position: relative;
  border: ${e=>{let{theme:t}=e;return`1px solid ${t.palette.secondary.main}`}};

  &::before {
    content: "";
    display: ${e=>{let{isLast:t}=e;return t?"none":"block"}};
    width: 0.75rem;
    height: 0.75rem;
    border: ${e=>{let{theme:t}=e;return`1px solid ${t.palette.secondary.main}`}};
    border-left: none;
    border-bottom: none;
    position: absolute;
    right: -1px;
    top: 50%;
    transform: translate(50%, -50%) rotate(45deg);
    background-color: ${e=>{let{theme:t}=e;return t.palette.common.white}};
  }
`,Lt=w.Ay.span`
  display: block;
  font-weight: 700;
  font-size: 2.5rem;
  line-height: 1.2;
  margin-bottom: 1rem;
  color: ${e=>{let{theme:t}=e;const n=t.palette.secondary.main,i=t.palette.common.white;return(0,_.PM)(i,n,t.palette.contrastThreshold)}};
`,Tt=w.Ay.p`
  color: ${De.c3[900]};
  font-size: 1rem;
  line-height: 1.25;
  margin: 0;
`,It=()=>{const{breakpoints:e={}}=(0,w.DP)(),t=(0,u.dn)(),n=t?.recruitmentSteps,i=n?.list;if(!i?.length)return null;const r=Math.min(i.length,4);return s.createElement(me.w,null,s.createElement(_t,null,s.createElement(de._,{topLine:n.title,bottomLine:n.subTitle}),s.createElement(St,null,s.createElement(zt,{slidesPerView:"auto",spaceBetween:16,breakpoints:{[e.tablet]:{slidesPerView:Math.ceil(r/2)},[e.laptop]:{slidesPerView:r}},navigation:{prevEl:"#swiper-company-steps-prev",nextEl:"#swiper-company-steps-next",clickable:!0},pagination:{type:"bullets"},keyboard:!0,modules:[A.Vx,A.s3,A.dK]},i.map((e,t)=>s.createElement(k.qr,{key:t},s.createElement(Ct,{isLast:t+1===i.length},s.createElement(Lt,null,(0,$t.A)((t+1).toString(),2,0)),s.createElement(Tt,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e,{USE_PROFILES:{html:!0}})}}))))),s.createElement(Ve.rb,{up:!0},s.createElement("div",{id:"swiper-company-steps-prev",className:"swiper-button-prev"}),s.createElement("div",{id:"swiper-company-steps-next",className:"swiper-button-next"})))))};var Pt=n(25864),Bt=n.n(Pt);const Nt=JSON.parse('{"youtube":{"embedOptions":{"host":"https://www.youtube-nocookie.com"}},"vimeo":{"playerOptions":{"dnt":true,"autoplay":true}}}'),Rt=w.Ay.div`
  overflow: hidden;
  border-radius: ${e=>{let{theme:t}=e;return t.template===d.tC.HORIZONTAL_BAR_2022?"20px":"0"}};

  .react-player__preview {
    position: relative;
    &::before {
      content: "";
      display: block;
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      background-color: rgba(0, 0, 0, 0.33);
    }
  }
`,Mt=w.Ay.div`
  position: relative;
  display: block;
  text-align: center;
  color: #ffffff;

  svg {
    fill: #ffffff;
  }

  span {
    display: block;
    text-transform: uppercase;
    font-size: 0.875rem;
    letter-spacing: 0.0875rem;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
      display: none;
    }
  }
`,Ft=()=>{const{t:e}=(0,v.Bd)();return s.createElement(s.Fragment,null,s.createElement(Mt,null,s.createElement(yt.A,{View:bt.UG,size:76}),s.createElement("span",null,e("career_website_landing.play_video"))))},Ot=()=>{const e=(0,u.dn)(),t=e?.videoTemplate;return t?.url?s.createElement(me.w,null,s.createElement(ce.m,null,s.createElement(de._,{topLine:t.title,bottomLine:t.subTitle}),s.createElement(Rt,null,s.createElement(Bt(),{width:"100%",height:"50vw",style:{maxHeight:600},playIcon:s.createElement(Ft,null),url:t.url,light:t.thumbnail,config:Nt,controls:!0,playing:!0})))):null};var jt=n(21705);const Vt=e=>{let{children:t,limit:n}=e;const i=(0,ee.wA)();return(0,s.useEffect)(()=>{i((0,jt.k)(n))},[i,n]),t};Vt.propTypes={limit:Ke().number.isRequired};var Dt=n(20800);const Ht=(0,w.Ay)(Dt.l)`
  padding: 64px 0;
  margin: 0 0 64px 0;
`,qt=()=>{const{t:e}=(0,v.Bd)(),{template:t}=(0,w.DP)(),{list:n,isFetching:i,total:r}=(0,u.GV)(V.y4);return s.createElement(Vt,{limit:4},s.createElement(Ht,{dataTestId:"cvc-last-job-offers-card",slug:"swiper-last-offers",largeButtonLink:t===d.tC.HORIZONTAL_BAR_2022,jobOffers:n,title:e("career_website_landing.last_job_offers_section.title_2022"),jobOffersCount:r,isFetching:i,tinyContratType:!0}))},Ut=w.Ay.button`
  cursor: pointer;
  position: absolute;
  left: calc(20% + 24px);
  top: 16px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    left: 8px;
    top: 8px;
  }
`,Xt=e=>{let{onClick:t,children:n=s.createElement(yt.A,{View:bt.g1,size:48,withContrast:!0}),...i}=e;return s.createElement(Ut,(0,ue.A)({},i,{onClick:t}),n)},Wt=e=>{let{playIcon:t,url:n,preview:i,isActive:r,StopIconComponent:a=Xt,...l}=e;const o=(0,s.useRef)(null),[p,m]=(0,s.useState)(!0);return s.createElement(s.Fragment,null,r&&s.createElement(a,{onClick:()=>{o.current.showPreview()}}),s.createElement(Bt(),(0,ue.A)({},l,{"border-radius":16,ref:o,width:"100%",height:"100%",onEnded:()=>{o.current.showPreview()},onPause:()=>{m(!1)},onPlay:()=>{m(!0)},playIcon:t,url:n,light:i,playing:r&&p,config:Nt,controls:!0})))},Jt=w.Ay.div`
  flex: 1;
  width: 100%;
  position: relative;
  padding-top: 56.25%; // 16:9 aspect ratio
  height: 100%;
  overflow: hidden;

  .react-player__preview {
    position: relative;

    &::before {
      content: "";
      display: block;
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      background: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.5));
    }
  }
`,Gt=(0,w.Ay)(Bt())`
  position: absolute;
  top: 0;
  left: 0;
`,Zt=w.Ay.div`
  position: absolute;
  display: flex;
  gap: 21px;
  align-items: center;
  ${e=>{let{playIconPosition:t}=e;return t===en.Center?"\n    top: 50%;\n    left: 50%;\n    transform: translate(-50%, -50%);\n    flex-direction: column;\n  ":"\n    bottom: 5%;\n    left: 5%;\n  "}}
`,Kt=w.Ay.div`
  padding: 25px 25px 25px 28px;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
`,Qt=w.Ay.span`
  font-size: 20px;
  color: #fff;
  font-weight: 500;
`,Yt=e=>{let{playIconPosition:t,...n}=e;const{t:i}=(0,v.Bd)();return s.createElement(Zt,(0,ue.A)({playIconPosition:t},n),s.createElement(Kt,null,s.createElement(bt.r0,{fill:"#fff"})),s.createElement(Qt,null,i("career_website_landing.play_video")))};let en=function(e){return e.Center="center",e.BottomLeft="bottom-left",e}({});const tn=e=>{let{playIconPosition:t,...n}=e;const i=(0,u.dn)(),r=i?.videoTemplate;return r?.url?s.createElement(Jt,n,s.createElement(Gt,{width:"100%",height:"100%",playIcon:s.createElement(Yt,{playIconPosition:t}),url:r.url,light:r.thumbnail,config:Nt,controls:!0,playing:!0})):null},nn=(0,w.Ay)(be)`
  width: 100%;
  height: 100%;

  .swiper-pagination {
    display: none;
  }
  .swiper-button-prev,
  .swiper-button-next {
    display: none;
  }
`,rn=(0,w.Ay)(k.qr)`
  height: auto;
`,an=w.Ay.div`
  display: flex;
  gap: 16px;
  height: 100%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.sm}px`}}) {
    flex-direction: column;
    height: 100%;
  }
`,ln=w.Ay.div`
  width: 60%;
  border-radius: 16px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.sm}px`}}) {
    width: 100%;
    height: 25vh;
  }
`,on=(0,w.Ay)(ln)`
  background-color: #000000;
  .react-player__preview {
    position: relative;
    border-radius: 16px;

    &::before {
      border-radius: 16px;
      content: "";
      display: block;
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      background-color: rgba(0, 0, 0, 0.33);
    }
  }
`,sn=w.Ay.div`
  display: flex;
  gap: 16px;
  width: 40%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.sm}px`}}) {
    width: 100%;
    height: 50%;
  }
`,pn=w.Ay.div`
  width: 50%;
  height: 100%;
`,mn=w.Ay.img`
  height: 100%;
  width: 100%;
  border-radius: 16px;
  position: relative;
  background-size: cover;
  background-position: center center;
  object-fit: cover;
`,cn=(0,w.Ay)(Yt)`
  ${Kt} {
    padding: 22px 22px 22px 24px;
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
      padding: 18px 18px 18px 20px;
    }
  }
`,dn=(0,w.Ay)(Xt)`
  left: 16px;
  top: 16px;
`,un=e=>{let{onClick:t}=e;return s.createElement(dn,{onClick:t},s.createElement(bt.g1,{fill:"#fff"}))},gn=e=>{let{controller:t,onSwiper:n,isMultiSlides:i,swiperContent:r,...a}=e;return s.createElement(nn,(0,ue.A)({onSwiper:n,controller:t,isMultiSlides:i,blockName:"team"},a),r.map((e,t)=>s.createElement(rn,{key:t},t=>{let{isActive:n}=t;return s.createElement(an,null,e.video?s.createElement(on,null,s.createElement(Wt,{StopIconComponent:un,isActive:n,url:e.video,preview:e.images?.[1],playIcon:s.createElement(cn,null)})):s.createElement(ln,null,s.createElement(mn,{src:e.images[1]})),s.createElement(sn,null,s.createElement(pn,null,s.createElement(mn,{src:e.images[0]})),s.createElement(pn,null,s.createElement(mn,{src:e.images[2]}))))})))},hn=w.AH`
  .swiper-pagination-bullet {
    opacity: 1;
  }

  --swiper-pagination-bullet-inactive-color: transparent;
  --swiper-pagination-bullet-size: 0.7rem;
`,xn=w.AH`
  ${hn};

  .swiper-pagination-bullet {
    border: 1px solid #000;
  }

  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
`,bn=w.AH`
  ${hn};

  .swiper-pagination-bullet {
    border: 1px solid #fff;
  }

  --swiper-pagination-color: ${e=>{let{theme:t}=e;return t.palette.common.white}};
`,wn=(0,w.Ay)(be)`
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  --swiper-pagination-bullet-inactive-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  --swiper-navigation-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  --swiper-navigation-size: 2rem;
  position: initial;

  ${xn};

  &.swiper {
    padding: 0 0 32px 0;
  }

  .swiper-pagination {
    display: none;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    .swiper-pagination {
      display: block;
      text-align: left;
      left: 0;
    }
  }
`,fn=(0,w.Ay)(k.qr)`
  position: initial;
  display: flex;
  align-items: center;
`,yn=w.Ay.div`
  display: flex;
  flex-direction: column;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin-top: 16px;
  }
`,En=w.Ay.p`
  font-size: 20px;
  margin: 12px 0 0 0;
  font-weight: 600;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    font-size: 18px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 16px;
    margin-bottom: 0;
  }
`,vn=(0,w.Ay)(En)`
  font-size: 18px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 16px;
  }
`,An=w.Ay.div`
  display: flex;
  gap: 24px;
  align-items: stretch;
  position: relative;
  min-height: 50vh;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-direction: column-reverse;
    gap: 0;
  }
`,kn=w.Ay.div`
  max-width: 30%;
  position: relative;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    max-width: 100%;
    flex-shrink: 0;
  }
`,$n=(0,w.Ay)(e=>{let{onSwiper:t,controller:n,isMultiSlides:i,swiperContent:r,...a}=e;const{isBelowOrEqualToBreakpoint:l}=(0,we.d)(),o=l("tablet");return r.length<1?null:s.createElement(wn,(0,ue.A)({onSwiper:t,controller:n,isMultiSlides:i,enableNavigation:!o,blockName:"team"},a),r.map((e,t)=>s.createElement(fn,{key:t},s.createElement(yn,null,s.createElement(En,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.name,{USE_PROFILES:{html:!0}})}}),s.createElement(vn,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.job,{USE_PROFILES:{html:!0}})}}),e.testimony&&s.createElement("p",{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.testimony,{USE_PROFILES:{html:!0}})}})))))})`
  height: 100%;
`,_n=w.Ay.div`
  max-width: 66%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    max-width: 100%;
    flex-grow: 1;
  }
`,Sn=e=>{let{swiperContent:t}=e;const[n,i]=(0,s.useState)(void 0),[r,a]=(0,s.useState)(void 0),l=t.length>1;return s.createElement(An,null,s.createElement(kn,null,s.createElement($n,{controller:{control:r},onSwiper:i,swiperContent:t,isMultiSlides:l})),s.createElement(_n,null,s.createElement(gn,{onSwiper:a,controller:{control:n},swiperContent:t,isMultiSlides:l})))},zn=w.Ay.div`
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.QZ,_.qf)}};
  padding-bottom: 36px;

  h2 {
    margin-bottom: 0;
  }
`,Cn=e=>{let{topLine:t,bottomLine:n}=e;return t?s.createElement(zn,null,s.createElement(de._,{topLine:t,bottomLine:n})):null},Ln=w.Ay.section`
  width: 100%;
  max-width: 1072px;
  margin: 0 auto;
  padding: 0 24px 64px 24px;
  position: relative;

  section {
    margin-top: 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 0 32px;
    margin-top: 0;
  }
`,Tn=()=>{const e=(0,u.dn)(),t=e?.team?.list||[],n=e?.team?.title,i=e?.team?.subTitle;return s.createElement(Ln,null,s.createElement(Cn,{topLine:n,bottomLine:i}),s.createElement(Sn,{swiperContent:t}))},In=(0,w.Ay)(z)`
  --swiper-navigation-size: 2.5rem;

  .swiper-button-prev,
  .swiper-button-next {
    width: 64px;
    height: 64px;
  }

  .swiper-button-prev {
    left: calc(20% + 24px);
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
      left: 0;
    }
  }

  .swiper-button-next {
    right: calc(20% + 24px);
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
      right: 0;
    }
  }
`,Pn=w.Ay.div`
  display: flex;
  height: 50vw;
  min-height: 450px;
  max-height: 600px;
`,Bn=w.Ay.div`
  width: 20%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    display: none;
  }
`,Nn=w.Ay.div`
  width: 60%;
  margin: 0 8px;
  background-color: #000000;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.tablet}px`}}) {
    width: 100%;
    margin: 0;
  }

  .react-player__preview {
    position: relative;
    &::before {
      content: "";
      display: block;
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      background-color: rgba(0, 0, 0, 0.33);
    }
  }
`,Rn=w.Ay.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 24px;
  position: relative;
  height: 100%;
  background-image: url("${e=>{let{bgImage:t}=e;return t}}");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

  &::before {
    content: "";
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    background-color: rgba(0, 0, 0, 0.33);
  }

  & > * {
    position: relative;
    z-index: 1;
  }
`,Mn=w.Ay.div`
  ${e=>!e.displayFull&&w.AH`
        @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}}) {
          margin: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: normal;
          max-width: 100%;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
      `};
`,Fn=(0,w.Ay)(F.A)`
  display: block;
  max-width: 75%;
  font-size: 1rem;
  line-height: ${e=>{let{theme:t}=e;return t.typography.lineHeight.default}};
  margin: 16px 0 0 0;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  padding: 16px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.laptop}px`}}) {
    max-width: none;
    max-height: 100%;
    overflow: auto;
  }
`,On=w.Ay.img`
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,jn=w.Ay.div`
  position: absolute;
  left: 24px;
  bottom: 24px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  color: #ffffff;

  svg {
    display: block;
    margin: 0 0 -5px -5px;
  }
`,Vn=(0,w.Ay)(F.A)`
  font-size: 2rem;
  font-weight: 400;
  margin: 0;
`,Dn=(0,w.Ay)(F.A)`
  font-weight: 600;
  font-size: 1rem;
  text-transform: uppercase;
  letter-spacing: 0.05rem;
`,Hn=e=>{let{name:t,jobPosition:n}=e;return s.createElement(jn,null,s.createElement(yt.A,{View:bt.UG,size:76,withContrast:!0}),s.createElement(Vn,{autoContrast:!0,variant:"h4"},t),n&&s.createElement(Dn,{autoContrast:!0,variant:"span"},n))},qn=w.Ay.div`
  display: flex;
  width: 100%;
  flex-direction: row;
  justify-content: flex-end;
  cursor: pointer;
  color: inherit;
  margin-top: 8px;
`,Un=w.Ay.button`
  color: inherit;
  cursor: pointer;
`,Xn=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.dn)(),n=t?.team?.title,i=t?.team?.subTitle,r=t?.team?.list||[],a=(0,s.useRef)([]),[l,o]=(0,s.useState)(new Array(r.length).fill(!1)),[p,m]=(0,s.useState)(new Array(r.length).fill(!1));(0,s.useEffect)(()=>(c(),window.addEventListener("resize",c),()=>window.removeEventListener("resize",c)),[]);const c=()=>{const e=a.current;m(e.map(e=>e.offsetHeight<e.scrollHeight))};return r.length<1?null:s.createElement(me.w,null,s.createElement(de._,{topLine:n,bottomLine:i}),s.createElement(In,{navigation:!0,keyboard:!0,modules:[A.Vx,A.s3]},r.map((t,n)=>s.createElement(k.qr,{key:n},i=>{let{isActive:r}=i;return s.createElement(Pn,null,s.createElement(Bn,null,s.createElement(On,{src:t.images[0],alt:`Photo de ${t.name||"quelqu'un travaillant avec nous"}`})),s.createElement(Nn,null,t.video?s.createElement(Wt,{url:t.video,preview:t.images[1],isActive:r,playIcon:s.createElement(Hn,{name:t.name,jobPosition:t.job})}):s.createElement(Rn,{bgImage:t.images[1]},t.name&&s.createElement(Vn,{variant:"h4",autoContrast:!0},`${t.name}`),t.job&&s.createElement(Dn,{variant:"span",autoContrast:!0},t.job),s.createElement(Fn,{variant:"blockquote",autoContrast:!0,cite:`${t.name||""}`},s.createElement(Mn,{ref:e=>a.current[n]=e,displayFull:l[n],dangerouslySetInnerHTML:{__html:E.A.sanitize(t.testimony,{USE_PROFILES:{html:!0}})}}),p[n]&&s.createElement(qn,null,s.createElement(Un,{onClick:()=>(e=>{o(t=>{const n=[...t];n[e]=!n[e],o(n)})})(n)},l[n]?e("career_website_landing.team_section.show_less"):e("career_website_landing.team_section.show_more")))))),s.createElement(Bn,null,s.createElement(On,{src:t.images[2],alt:""})))}))))},Wn=e=>{let{sectionName:t}=e;const{config:n}=(0,m._r)(),i=n.template,r=i===d.tC.LATERAL_BAR_2022?"60%":"50%";switch(t){case"heading":return null;case"lastOffers":return s.createElement(qt,null);case"keyInformations":return s.createElement(kt,null);case"videoTemplate":return s.createElement(Ot,null);case"employerCertifications":return s.createElement(ht,null);case"team":return i===d.tC.HORIZONTAL_BAR_2022?s.createElement(Tn,null):s.createElement(Xn,null);case"advantages":return s.createElement(Ge,null);case"briefAndPictures":return s.createElement(ot,{imageWidth:r});case"parallax":return s.createElement(Oe,null);case"recruitmentSteps":return s.createElement(It,null);case"gallery":return s.createElement(Ne,null);default:throw new Error(`Unsupported "${t}" section. Please check the config.home.sections field.`)}},Jn=()=>{const e=(0,u.dn)();return(e?.sections||[]).filter(e=>e.display).map((e,t)=>s.createElement(Wn,{key:t,sectionName:e.name}))};var Gn=n(40126);const Zn=w.Ay.div`
  display: block;
  padding-bottom: 64px;
  text-align: center;
`,Kn=()=>{const{t:e}=(0,v.Bd)(),t=e("career_website_landing.steps_section.button");return t&&s.createElement(Zn,null,s.createElement($.$n,{colorName:_.ll,to:x.J.SEARCH},t))},Qn=w.Ay.div`
  width: 100vw;
  min-height: 100vh;
  position: relative;
`,Yn=w.Ay.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  position: relative;
`,ei=(0,w.Ay)(e=>s.createElement(Qn,(0,ue.A)({"data-testid":"cvc-page-landing"},e)))``,ti=(0,w.Ay)(e=>s.createElement(Yn,(0,ue.A)({"data-testid":"cvc-page-landing"},e)))``,ni=w.Ay.main`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,ii=()=>s.createElement(ti,null,s.createElement(Gn.Y9,{transparent:!0}),s.createElement(Y,null),s.createElement(ni,null,s.createElement(N,null),s.createElement(G,null),s.createElement(pe,null),s.createElement(Jn,null),s.createElement(Kn,null)),s.createElement(f.w,null)),ri=()=>s.createElement(ae,{view:ii});var ai=n(66576),li=n(33011),oi=n(71804);const si=w.Ay.div`
  // Higher than SwiperJs and widget z-indexes
  z-index: 20;
  bottom: 0;
  background-color: #ffffff;
  margin-top: 20px;

  ${e=>{let{theme:t,fixedBar:n}=e;return`\n    padding: ${n?"16px":"32px"};\n    position: ${n?"fixed":"static"};\n    border-radius: ${n?"0":"20px"};\n    box-shadow: ${n?t.shadows[10]:t.shadows[20]};\n    \n    // See fixedBarScaleRatio comments.\n    transform: ${n?"scale(0.8) translateY(calc(10% * 1.25))":"none"};\n    width: ${n?"calc(100% * 1.25)":"auto"};\n  `}};
`,pi=w.Ay.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 24px 16px;
  margin: 0 auto;

  ${e=>{let{theme:t,fixedBar:n}=e;return`\n    flex-direction: ${n?"row":"column"};\n    \n    // See fixedBarScaleRatio comments.\n    max-width: ${n?`calc(${t.breakpoints.laptop}px * 1.25)`:"none"};\n  `}};

  ${li.uM} {
    position: static;
    padding: 0;
    max-width: none;
    box-shadow: none;
    width: 100%;

    // TODO: improve this when the widget will no longer be managed in scss
    ${e=>{let{theme:t,fixedBar:n}=e;return n&&`\n      @media (max-width: ${t.breakpoints.mobile}px) {\n        width: auto;\n      }\n      form {\n        @media (max-width: ${t.breakpoints.mobile}px) {\n          padding: 8px;\n        }\n      }\n      form > div {\n          flex-direction: row;\n          gap: 4px 8px;\n          @media (max-width: ${t.breakpoints.mobile}px) {\n            flex-direction: column;\n          }\n       }\n       form > div > div:nth-child(2) {\n          margin: 0;\n          @media (max-width: ${t.breakpoints.mobile}px) {\n            font-size: 0.8rem;\n          }\n       }\n\n       ${oi.Kd} {  \n          display: none;\n       }\n    `}};
  }
`,mi=(0,w.Ay)(O.hE)`
  font-size: 1.15rem;
  margin: 0 0 -12px 0;
  width: 100%;
  text-align: center;
`,ci=(0,w.Ay)(R.A)`
  width: 200px;
  height: 24px;
  background-color: lightgrey;
`,di=(0,w.Ay)(F.A)`
  font-size: 1rem;
  margin: 0;
`,ui=w.Ay.div`
  width: 100%;
  margin: 0;
`,gi=w.Ay.div`
  display: flex;
  gap: 0 16px;
  align-items: center;
  text-align: center;
  text-transform: uppercase;
  margin: 0;

  ${e=>{let{theme:t,fixedBar:n}=e;return`\n    width: ${n?"auto":"100%"};\n    @media (max-width: ${t.breakpoints.tablet}px) {\n      display: none;\n    }\n  `}};

  &::before,
  &::after {
    content: "";
    display: ${e=>{let{fixedBar:t}=e;return t?"none":"block"}};
    flex-grow: 1;
    width: auto;
    height: 1px;
    background-color: #bebebe;
  }
`,hi=(0,w.Ay)(F.A)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 3rem;
  height: 3rem;
  border: 2px solid #000000;
  text-align: center;
  border-radius: 50%;
  font-weight: bold;
  font-size: 0.85rem;
`,xi=e=>{let{fixedBar:t=!1}=e;const{config:n}=(0,m._r)(),{t:i}=(0,v.Bd)(),{total:r,isFetching:a}=(0,ee.d4)(e=>e.lastJobOffers),[l,o]=(0,s.useState)(!1),p=()=>{window.scrollY>window.innerHeight/3?o(!0):o(!1)};return(0,s.useEffect)(()=>(window.addEventListener("scroll",p),()=>{window.removeEventListener("scroll",p)}),[]),s.createElement(ai.A,{in:t&&l||!t,appear:t},s.createElement(si,{fixedBar:t},s.createElement(pi,{fixedBar:t},!t&&s.createElement(s.Fragment,null,s.createElement(mi,{variant:"h2",autoContrast:!0},i("career_website_landing.search_section.title.bottom_line",{client_name:n.company_name})),a?s.createElement(ci,null):s.createElement(di,{autoContrast:!0},i("career_website_landing.search_section.title.top_line",{count:r}))),s.createElement(ui,null,s.createElement(O.C8,{smallSearchBar:!0})),s.createElement(gi,{fixedBar:t},s.createElement(hi,{variant:"span",autoContrast:!0},i("career_website_landing.search_section.or"))),s.createElement(le.A,{displayAnalysisInModal:!0}),!t&&s.createElement(j.g,{to:x.J.SEARCH,"data-testid":"cvc-career-landing-btn-all-offer"},i("career_website_landing.search_section.see_all_2022")))))},bi=w.Ay.div`
  display: block;
  width: 100%;
  position: relative;

  ::before {
    content: "";
    display: block;
    position: absolute;
    z-index: 0;
    left: 0;
    top: 0;
    background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.sA)}};
    width: 100%;
    height: max(85vh, 650px);
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    ::before {
      background-color: rgba(0, 0, 0, 0.66);
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.up("tablet")}} {
    background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.ll,_.qf)}};
  }
`,wi=w.Ay.div`
  width: calc(50% - 24px);

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    width: 100%;
  }
`,fi=(0,w.Ay)(O.mc)`
  --container-margin-top: var(--landing-cover-carousel-margin-top);

  position: relative;
  display: flex;
  gap: 0 48px;
  margin-top: var(--landing-cover-carousel-margin-top);

  --swiper-navigation-color: #ffffff;
  --swiper-navigation-size: 1.25rem;
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.ll,_.Xs)}};
  --swiper-pagination-bullet-inactive-color: transparent;
  --swiper-pagination-bullet-size: 0.875rem;

  .swiper-button-prev,
  .swiper-button-next {
    margin-top: 0;
    top: 40vh;
  }

  .swiper-button-prev {
    left: -32px;
    transform: translate(-50%, -50%);
  }

  .swiper-button-next {
    right: -32px;
    transform: translate(50%, -50%);
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    --swiper-navigation-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.ll,_.Xs)}};

    .swiper-button-prev,
    .swiper-button-next {
      height: auto;
      background-color: #ffffff;
      padding: 8px 16px;
      border-radius: 4px;
    }

    .swiper-button-prev {
      left: calc(50% + 64px);
    }

    .swiper-button-next {
      right: 64px;
    }

    &.single-slide {
      ${wi}:first-child {
        width: 100%;
        position: relative;
        z-index: 2;
      }

      ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
        ${wi}:first-child {
        }

        ${wi}:last-child {
          display: block;
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 1;
          opacity: 0.1;
        }
      }
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    --container-margin-top: var(--landing-cover-carousel-margin-top-mobile);

    .swiper-button-prev,
    .swiper-button-next {
      display: none;
    }
  }
`,yi=(0,w.Ay)(k.RC)`
  width: 100%;

  &.swiper-horizontal > .swiper-pagination-bullets {
    width: auto;
    left: 50%;
    transform: translate(-50%, 0);
  }

  .swiper-pagination-bullet {
    opacity: 1;
    border: 1px solid
      ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.ll,_.Xs)}};
  }
`,Ei=(0,w.Ay)(yi)`
  ${e=>{let{theme:t}=e;return t.breakpoints.up("tablet")}} {
    .swiper-pagination {
      display: none;
    }
  }
`,vi=(0,w.Ay)(yi)`
  height: 100%;

  .swiper-pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #ffffff;
    padding: 4px;
    border-radius: 4px;
    bottom: 16px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    .swiper-pagination {
      display: none;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    &.swiper-horizontal {
      position: absolute;
      z-index: -1;
      left: 0;
      top: calc(var(--landing-cover-carousel-margin-top) * -1);
      height: 85vh;
    }
  }
`,Ai=(0,w.Ay)(k.qr)`
  &.swiper-slide {
    height: auto;
  }
`,ki=w.Ay.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: ${e=>{let{bgPosition:t}=e;return t||"center"}};
  border-radius: 20px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    border-radius: 0;
  }
`,$i=w.Ay.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 24px;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.sA)}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    align-items: center;
    background-color: transparent;
    margin-bottom: 64px;
  }
`,_i=(0,w.Ay)(y.A)`
  display: flex;
  justify-content: center;
`,Si=(0,w.Ay)(_i)`
  position: absolute;
  top: -12vh;
  left: 0;
`,zi=(0,w.Ay)(S.o5)`
  position: relative;
  display: block;
  margin: 0;
  padding-bottom: 24px;
  font-size: 2rem;
  font-weight: 400;

  ::before {
    content: "";
    position: absolute;
    bottom: -2px;
    width: 32px;
    height: 4px;
    background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.ll,_.Xs)}};
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1.8rem;
    text-align: center;

    ::before {
      content: "";
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    font-size: 1.6rem;
  }
`,Ci=(0,w.Ay)(S.o5)`
  display: block;
  margin: 0;
  line-height: 1.5rem;
  font-size: 1.15rem;
  font-weight: 400;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 1rem;
    text-align: center;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    font-size: 0.85rem;
  }
`,Li=[A.xI,A.dK,A.Vx,A.s3],Ti=()=>{const{isAboveBreakpoint:e}=(0,u.dv)(),t=(0,u.XB)(),n=(0,u.Pn)(),i=(0,u.Ee)(),r=e("tablet"),a=t.length>1,[l,o]=(0,s.useState)(null),[p,m]=(0,s.useState)(null);(0,s.useEffect)(()=>{l?.controller&&p?.controller&&!l?.destroyed&&!p?.destroyed&&(l.controller.control=p,p.controller.control=l)},[l,p]);const c=(0,s.useMemo)(()=>({loop:a,modules:Li,pagination:{enabled:a,clickable:!0},keyboard:a,allowTouchMove:a,effect:"slide"}),[a]),d=(0,s.useMemo)(()=>({...c,navigation:a?{prevEl:"#swiper-cover-prev",nextEl:"#swiper-cover-next"}:void 0}),[c,a]),g=c;return s.createElement(bi,null,s.createElement(fi,{className:a?"":"single-slide"},!n&&i&&s.createElement(Si,null,s.createElement(S.tm,null)),s.createElement(wi,null,s.createElement(Ei,(0,ue.A)({onSwiper:o},d),t.map((e,t)=>s.createElement(Ai,{key:t},s.createElement($i,null,n&&i&&s.createElement(_i,{disableGutters:r},s.createElement(S.tm,null)),s.createElement(zi,{autoContrast:!0,variant:"h2",dangerouslySetInnerHTML:{__html:E.A.sanitize(e.title,{USE_PROFILES:{html:!0}})}}),e.paragraph&&s.createElement(Ci,{autoContrast:!0,variant:"p",dangerouslySetInnerHTML:{__html:E.A.sanitize(e.paragraph,{USE_PROFILES:{html:!0}})}}))))),s.createElement(xi,null)),s.createElement(wi,null,s.createElement(vi,(0,ue.A)({onSwiper:m},g),t.map((e,t)=>s.createElement(Ai,{key:t},s.createElement(ki,{alt:"",src:e.bgImage,bgPosition:e.bgPosition}))))),a&&s.createElement(s.Fragment,null,s.createElement("div",{id:"swiper-cover-prev",className:"swiper-button-prev"}),s.createElement("div",{id:"swiper-cover-next",className:"swiper-button-next"}))))};var Ii=n(45890);const Pi=w.Ay.main`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,Bi=(0,w.Ay)(f.w)`
  // To prevent the fixed bar from hiding the content of the footer
  padding-bottom: 112px;
`,Ni=()=>{const e=(0,u.XV)();return s.createElement(ti,null,s.createElement(Gn.B3,{transparent:!0},s.createElement(Gn.B3.RouterLink,null)),s.createElement(Y,null),s.createElement(Pi,null,e&&s.createElement(Ii.L,null),s.createElement(Ti,null),s.createElement(Jn,null),s.createElement(xi,{fixedBar:!0}),s.createElement(Kn,null)),s.createElement(Bi,null))},Ri=()=>s.createElement(ae,{view:Ni});var Mi=n(11693),Fi=n(76772);const Oi=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  height: 100%;
  width: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    position: static;
    padding: 3rem 0;
    max-width: 400px;
    background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  }

  ${li.uM} {
    position: static;
  }

  ${se} {
    display: flex;
    justify-content: center;
    background-color: transparent;
  }
`,ji=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 24px 16px;
  margin: 0 auto;
  height: 100%;
  width: 100%;
`,Vi=(0,w.Ay)(O.hE)`
  font-size: 1.5rem;
  margin: 0 0 -12px 0;
  width: 100%;
  text-align: center;

  ${e=>{let{theme:t}=e;return`\n      @media (min-width: ${t.breakpoints.laptop}px) and (max-height: 830px) {\n        font-size: 1.25rem;\n      }\n      @media (min-width: ${t.breakpoints.laptop}px) and (max-height: 650px) {\n        display: none;\n      }\n      `}}
`,Di=(0,w.Ay)(R.A)`
  width: 200px;
  height: 32px;
  background-color: lightgrey;
`,Hi=(0,w.Ay)(F.A)`
  font-size: 1.25rem;
  margin: 0;

  ${e=>{let{theme:t}=e;return`@media (min-width: ${t.breakpoints.laptop}px) and (max-height: 830px) {\n        font-size: 1rem;\n      }`}}
`,qi=w.Ay.div`
  width: 100%;
  margin: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 0 24px;
  }
`,Ui=w.Ay.div`
  display: flex;
  gap: 0 16px;
  align-items: center;
  text-align: center;
  text-transform: uppercase;
  margin: 0;
  width: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin: 20px 0 0;
  }

  &::before,
  &::after {
    content: "";
    flex-grow: 1;
    width: auto;
    height: 1px;
    background-color: #ffffff;
  }
`,Xi=(0,w.Ay)(F.A)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 3rem;
  height: 3rem;
  border: 2px solid #ffffff;
  text-align: center;
  border-radius: 50%;
  font-weight: bold;
  font-size: 0.85rem;

  ${e=>{let{theme:t}=e;return`@media (min-width: ${t.breakpoints.laptop}px) and (max-height: 830px) {\n        width: 2.25rem;\n        height: 2.25rem;\n        font-size: 0.70rem;\n      }`}}
`,Wi=(0,w.Ay)(j.g)`
  margin-top: auto;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    margin-top: 2.25rem;
  }
`,Ji=e=>{let{bgColorName:t}=e;const{config:n}=(0,m._r)(),{t:i}=(0,v.Bd)(),{total:r,isFetching:a}=(0,ee.d4)(e=>e.lastJobOffers);return s.createElement(Oi,null,s.createElement(ji,null,s.createElement(Vi,{variant:"h2",autoContrast:!0},i("career_website_landing.search_section.title.bottom_line",{client_name:n.company_name})),a?s.createElement(Di,null):s.createElement(Hi,{autoContrast:!0},i("career_website_landing.search_section.title.top_line",{count:r})),s.createElement(qi,null,s.createElement(O.C8,{bgColorName:t,smallSearchBar:!0})),s.createElement(Ui,null,s.createElement(Xi,{variant:"span",autoContrast:!0},i("career_website_landing.search_section.or"))),s.createElement(pe,{displayAnalysisInModal:!0})),s.createElement(Wi,{to:x.J.SEARCH,"data-testid":"cvc-career-landing-btn-all-offer"},i("career_website_landing.search_section.see_all_2022")))},Gi=w.Ay.div`
  width: 100%;
  display: flex;
  justify-content: center;
`,Zi=w.Ay.div`
  position: absolute;
  top: 8px;
  right: 8px;
  cursor: pointer;
`,Ki=(0,w.Ay)(Fi._)`
  position: fixed;
  bottom: 16px;
  z-index: 2;
  width: 95%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px 32px;
`,Qi=(0,w.Ay)(M.A)`
  font-family: ${e=>{let{theme:t}=e;return t.typography.fontFamily}};
  display: flex;
  justify-content: center;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
`,Yi=e=>{let{anchor:t,toggleDrawer:n}=e;return s.createElement(Qi,null,s.createElement(Zi,{onClick:n(t,!1),onKeyDown:n(t,!1)},s.createElement(yt.A,{View:bt.MR,size:32,fill:_.QZ})),s.createElement(Ji,{bgColorName:"primary"}))},er=()=>{const{t:e}=(0,v.Bd)(),[t,n]=(0,s.useState)(!1),i="bottom",r=(e,t)=>e=>{(!e||"keydown"!==e.type||"Tab"!==e.key&&"Shift"!==e.key)&&n(t)};return s.createElement(Gi,null,s.createElement(Ki,{icon:bt.C0,iconPosition:"left",iconSize:32,colorName:"secondary",onClick:r(0,!0)},e("landing_page.floating_search_button")),s.createElement(Mi.A,{anchor:i,open:t,onClose:r(0,!1),onOpen:r(0,!0)},s.createElement(Yi,{anchor:i,toggleDrawer:r})))},tr=e=>{let{view:t,anchorRef:n={}}=e;const[i,r]=(0,s.useState)(!1);return(0,s.useEffect)(()=>{const e=()=>{const{current:e}=n;if(e){const{bottom:t,height:n}=e.getBoundingClientRect();r(t<=n/2)}};return window.addEventListener("scroll",e),window.addEventListener("resize",e),()=>{window.removeEventListener("scroll",e),window.removeEventListener("resize",e)}},[n]),i?s.createElement(t,{anchorRef:n}):null};tr.propTypes={view:Ke().elementType,anchorRef:Ke().shape({current:Ke().instanceOf(Element)})};const nr=(0,w.Ay)(ti)`
  justify-content: flex-end;
  position: relative;
  flex-direction: row;
`,ir=w.Ay.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 25%;
  height: 100%;
  z-index: 3;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    width: 30%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    position: static;
    width: 100%;
    z-index: 2;
    height: auto;
  }
`,rr=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: sticky;
  height: 100vh;
  width: 100%;
  overflow: auto;
  padding: 24px 32px;
  top: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.up("desktop")}} {
    ${Gn.h9} {
      padding: 24px;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    position: static;
    width: 100%;
    height: auto;
    max-height: none;
    padding: 40px 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    overflow: hidden;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    position: static;
    width: 100%;
    height: auto;
    max-height: none;
    padding: 0;
  }
`,ar=w.Ay.main`
  width: 75%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    width: 70%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    width: 100%;
  }
`,lr=()=>{const e=(0,s.useRef)(),t=(0,u.XV)();return s.createElement(nr,{"data-testid":"cvc-page-landing"},s.createElement(Y,null),s.createElement(ar,null,s.createElement(ir,{ref:e},s.createElement(rr,null,s.createElement(Gn.B3,{position:"static",transparent:!0},s.createElement(Gn.B3.RouterLink,null)),s.createElement(Ji,{bgColorName:"primary"}))),s.createElement(N,null),t&&s.createElement(Ii.L,null),s.createElement(Jn,null),s.createElement(Kn,null),!Re.xl&&s.createElement(tr,{view:er,anchorRef:e}),s.createElement(f.w,null)))},or=()=>s.createElement(ae,{view:lr}),sr=w.Ay.button`
  width: auto;
  color: ${e=>{let{theme:t}=e;return(0,_.Vh)((0,_.x6)(t.palette,_.Fl,_.Xs),t.palette)}};
  border-radius: 8px;
  padding: 2.3vh 2vw;
  cursor: pointer;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  border: 1px solid
    ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};

  transition:
    background-color 300ms ease,
    transform 300ms ease,
    color 300ms ease,
    border-color 300ms ease;

  &:hover {
    background-color: transparent;
    color: ${e=>{let{hoverTextColor:t,theme:n}=e;return t||(0,_.x6)(n.palette,_.Fl,_.Xs)}};
    border-color: ${e=>{let{hoverBorderColor:t,theme:n}=e;return t||(0,_.x6)(n.palette,_.Fl,_.Xs)}};
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    padding: 20px 20px;
  }
`,pr=w.Ay.span`
  font-size: 1rem;
  font-weight: 400;
`,mr=e=>{let{onClick:t,buttonText:n,hoverBorderColor:i,hoverTextColor:r,...a}=e;const{t:l}=(0,v.Bd)();return s.createElement(sr,(0,ue.A)({"data-testid":"job-offers-search-btn",onClick:t,type:"button",title:l("job_offers.search_bar.button_text"),hoverBorderColor:i,hoverTextColor:r},a),s.createElement(pr,null,n))},cr=(0,w.Ay)(be)`
  height: 90vh;
  border-radius: 8px;

  --swiper-navigation-color: ${e=>{let{theme:t}=e;return t.palette.common.white}};

  .swiper-pagination-bullets {
    display: none;
  }

  ${he} {
    position: relative;
    margin-top: calc(var(--swiper-navigation-size) / 2);
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    height: 70vh;
    border-radius: 0;

    --swiper-pagination-bullet-size: 0.7rem;

    .swiper-pagination-bullets {
      display: block;
      bottom: 0;
      margin-left: 0;
      padding: 24px 48px;
      text-align: left;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    height: 85vh;

    .swiper-pagination-bullets {
      padding: 16px;
    }
  }
`,dr=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  gap: 24px;
  padding: 64px;
  height: 100%;
  max-width: 50vw;

  & > * {
    z-index: 10;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    padding: 64px 48px;
    max-width: 100%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 48px 24px;
  }
`,ur=(0,w.Ay)(S.o5)`
  font-size: 40px;
  font-weight: 700;
  margin: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    font-size: 24px;
  }
`,gr=(0,w.Ay)(S.o5)`
  font-size: 20px;
  font-weight: 400;
  line-height: 1.25;
  margin: 0;

  p {
    margin: 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-size: 16px;
    line-height: 1.5;
  }
`,hr=e=>{let{title:t,paragraph:n}=e;const i=(0,p.W6)(),r=(0,w.DP)(),{t:a}=(0,v.Bd)(),{isBelowOrEqualToBreakpoint:l}=(0,u.dv)(),o=l("laptop");return s.createElement(s.Fragment,null,s.createElement(ur,{autoContrast:!0,variant:"h2",dangerouslySetInnerHTML:{__html:E.A.sanitize(t,{USE_PROFILES:{html:!0}})}}),n&&s.createElement(gr,{autoContrast:!0,variant:"p",dangerouslySetInnerHTML:{__html:E.A.sanitize(n,{USE_PROFILES:{html:!0}})}}),!o&&s.createElement(mr,{onClick:()=>i.push(x.J.SEARCH),buttonText:a("career_website_landing.discover_offers"),hoverBorderColor:r.palette.common.white,hoverTextColor:r.palette.common.white}))},xr=()=>{const e=(0,u.XB)(),{isBelowOrEqualToBreakpoint:t}=(0,u.dv)(),n=(0,u.Ee)(),i=e.length>1,r=t("laptop");return s.createElement(cr,{blockName:"cover",enableNavigation:!1,enablePagination:r,isMultiSlides:i,navigation:{prevEl:"#swiper-cover-prev",nextEl:"#swiper-cover-next"}},e.map((e,t)=>s.createElement(k.qr,{key:t},s.createElement(S.DN,{alt:`photo carousel numéro ${t}`,src:e.bgImage,bgPosition:e.bgPosition}),s.createElement(dr,null,n&&s.createElement(y.A,{disableGutters:!0},s.createElement(S.tm,null)),i&&!r&&s.createElement(he,null,s.createElement("div",{id:"swiper-cover-prev",className:"swiper-button-prev"}),s.createElement("div",{id:"swiper-cover-next",className:"swiper-button-next"})),s.createElement(hr,{title:e.title,paragraph:e.paragraph})))))},br=w.Ay.div`
  margin-top: 24px;

  .swiper-slide {
    height: auto;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin: 16px 0 16px 16px;
  }

  @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.tablet+1}px`}}) and (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    margin: 16px 0 16px 16px;
    }
  }
`,wr=(0,w.Ay)(k.qr)`
  height: auto;
  background-color: #f5f5f5;
  display: flex;
  border-radius: 8px;
  justify-content: center;
  text-align: left;
  align-items: center;
  padding: 50px 35px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("thirteenInchScreen")}} {
    padding: 30px 20px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("smallDevicesLimit")}} {
    &:last-child {
      margin-right: 16px;
    }
  }

  @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.tablet+1}px`}}) and (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    max-width: 37%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    max-width: 70%;
  }
`,fr=(0,w.Ay)(yt.A)`
  margin-right: 21px;
`,yr=e=>{let{name:t,size:n,fill:i="#000"}=e;const r={size:n,fill:i},a=ft[t]||ft.people;return s.createElement(fr,(0,ue.A)({View:a},r))},Er=w.Ay.div`
  display: flex;
  flex-direction: column;
`,vr=(0,w.Ay)(F.A)`
  margin: 0;
  font-size: 1rem;
  font-weight: 700;
`,Ar=(0,w.Ay)(F.A)`
  margin: 0;
  font-size: 1rem;
  font-weight: 400;
`,kr=()=>{const e=(0,w.DP)(),t=(0,u.dn)(),n=t?.keyInformations;return n?.length?s.createElement(br,null,s.createElement(be,{slidesPerView:"auto",breakpoints:{[e.breakpoints.values.smallDevicesLimit]:{slidesPerView:4}},modules:[A.s3],enablePagination:!1,enableNavigation:!1,blockName:"key-informations"},n.map((t,n)=>s.createElement(wr,{key:n},s.createElement(yr,{name:t.icon,size:34,fill:e.palette.primary.main}),s.createElement(Er,null,s.createElement(vr,{variant:"h4",autoContrast:!0},t.title),t.description&&s.createElement(Ar,{dangerouslySetInnerHTML:{__html:E.A.sanitize(t.description,{USE_PROFILES:{html:!0}})}})))))):null},$r=w.Ay.span`
  color: black;
`,_r=w.Ay.div`
  width: 100%;
  height: 1px;
  background-color: #e0e0e0;
`,Sr=(0,w.Ay)(_r)`
  margin-bottom: 16px;
  @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    display: none;
  }
`;var zr=n(33664),Cr=n(97687),Lr=n(52519);const Tr=w.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 8px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: 32px;
    background-color: #f5f5f5;
    border-radius: 8px;
  }
`,Ir=(0,w.Ay)($r)`
  font-weight: 400;
`,Pr=w.Ay.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 8px;
`,Br=(0,w.Ay)(Pr)`
  font-size: 14px;
`,Nr=(0,w.Ay)(Pr)`
  justify-content: space-between;
`,Rr=(0,w.Ay)(yt.A)`
  path {
    stroke: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
  }

  transition: transform 300ms ease-in-out;
`,Mr=(0,w.Ay)(S.vw).attrs(e=>{let{theme:t}=e;return{color:t.palette.primary.main,bgColor:t.palette.common.white}})``,Fr=(0,w.Ay)(zr.N_)`
  &:hover ${Rr} {
    transform: translateX(-10px);
    transition: transform 300ms ease-in-out;
  }
  color: #1f3038;
`,Or=e=>{let{offer:t}=e;const n=(0,w.DP)(),{t:i}=(0,v.Bd)(),r=(0,u.gl)(t),a=t.company_logo_url;return s.createElement(Fr,{to:(0,K.X2)(window.location.href,t.id)},s.createElement(Tr,null,s.createElement(Br,null,s.createElement(bt._L,{fill:n.palette.primary.main,size:14}),i("job_offers.published")+" "+new Date(t.lastProcessedDate).toLocaleString(Cr.Hb,{dateStyle:"full"})),s.createElement(Nr,null,s.createElement(Pr,null,s.createElement(s.Fragment,null,a&&s.createElement(Lr.X,{src:a}),s.createElement("h3",null,t.title))),s.createElement(Rr,{View:bt.nJ})),s.createElement(Sr,null),s.createElement(Pr,null,s.createElement(Mr,null,s.createElement(yt.A,{View:bt.nR,size:16}),s.createElement(Ir,null,t.contract_type)),r&&s.createElement(Mr,null,s.createElement(yt.A,{View:bt.ft,size:16}),s.createElement(Ir,null,r)))))},jr=w.Ay.h2`
  margin: 0;
  font-size: 24px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
`,Vr=w.Ay.span`
  color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
`,Dr=e=>{let{title:t,subtitle:n,CustomSectionTitle:i=jr,...r}=e;return s.createElement(i,r,t,n&&s.createElement(Vr,null," ",n))};var Hr=n(75992);const qr=e=>{const t=(0,u.dn)();return(t?.sections||[]).some(t=>t.name===e&&t.display)},Ur=e=>{const t=qr(e),n=(0,u.dn)();if(!n)return!1;const i=n[e];return!!i&&(t&&!(0,Hr.A)(i))},Xr=w.Ay.section`
  display: flex;
  flex-direction: row;
  gap: 24px;
  width: 100%;
  margin-top: 24px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    flex-direction: column-reverse;
    padding: 32px 16px 0 16px;
  }
`,Wr=w.Ay.div`
  height: auto;
  max-width: 50%;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    max-width: 100%;
  }
`,Jr=w.Ay.div`
  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    a {
      width: 100%;
    }
  }
`,Gr=w.Ay.img`
  height: 100%;
  border-radius: 8px;
  object-fit: cover;
  width: 100%;
`,Zr=w.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 48px;
  width: 100%;
  border-radius: 8px;
  background-color: #f5f5f5;
  padding: 48px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
    padding: 32px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    padding: 0;
    background-color: #fff;
    gap: 20px;
  }
`,Kr=w.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    gap: 20px;
  }
`,Qr=w.Ay.div`
  @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    &:not(:last-child) {
      border-bottom: 1px solid #e0e0e0;
      padding-bottom: 16px;
      margin-bottom: 16px;
    }
  }
`,Yr=e=>{let{offer:t,key:n}=e;return s.createElement(Qr,{key:n},s.createElement(Or,{offer:t}))},ea=()=>{const{t:e}=(0,v.Bd)(),{config:t}=(0,m._r)(),n=t.fr?.home?.offerPhoto?.src,i=qr("offerPhoto"),r=n&&i,{list:a}=(0,u.GV)(e=>e.lastJobOffers);return s.createElement(Vt,{limit:4},s.createElement(Xr,null,r&&s.createElement(Wr,null,s.createElement(Gr,{alt:"décoration de la section dernière offres",src:n})),a&&s.createElement(Zr,null,s.createElement(Dr,{title:e("career_website_landing.discover_offers")}),s.createElement(Kr,null,a.map(e=>s.createElement(Yr,{offer:e,key:e.reference}))),s.createElement(Jr,null,s.createElement($.$n,{size:"large",to:"/search",variant:"outlined"},e("career_website_landing.last_job_offers_section.see_all_2022"))))))},ta=(0,w.Ay)(k.qr)`
  &.swiper-slide {
    background-color: white;
    display: flex;
    flex-direction: column;
    padding: 48px 24px 24px 24px;
    gap: 10px;
    border-radius: 8px;
    height: auto;

    @media (min-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) and (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
      padding-top: 32px;
    }

    // mobile
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
      background-color: #f5f5f5;
    }
  }
`,na=w.Ay.section`
  background-color: #f5f5f5;
  border-radius: 8px;
  margin: 24px 0;
  padding: 48px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  gap: 24px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
    padding: 32px;
  }

  // mobile media query
  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    padding: 0 0 0 16px;
    overflow-x: hidden;
    background-color: #fff;
    margin: 24px 0 48px;

    .swiper-slide {
      &:last-child {
        margin-right: 16px;
      }
    }
  }
`,ia=w.Ay.p`
  font-size: 34px;
  color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
  margin: 0;
`,ra=w.Ay.div`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("smallDevicesLimit")}} {
    padding-right: 16px;
    width: 100%;
    a {
      width: 100%;
    }
  }
`,aa=w.Ay.p`
  font-size: 1rem;
  margin: 0;
`,la=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.dn)(),n=t?.recruitmentSteps,i=n?.list&&n.list?.length>1;return n?.list?.length?s.createElement(na,null,s.createElement(Dr,{title:n.title,subtitle:n.subTitle}),s.createElement(Ee,{blockName:"steps",smallBreakpoint:"smallDevicesLimit",isMultiSlides:i},n.list.map((e,t)=>s.createElement(ta,{key:t},s.createElement(ia,null," ",t+1),s.createElement(aa,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e,{USE_PROFILES:{html:!0}})}})))),s.createElement(ra,null,s.createElement($.$n,{size:"large",to:"/search",variant:"outlined"},e("career_website_landing.last_job_offers_section.see_all_2022")))):null},oa=w.Ay.div`
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
  flex: 1;
`,sa=(0,w.Ay)(be)`
  position: static;
  height: 100%;
  border-radius: 8px;
`,pa=(0,w.Ay)(k.qr)`
  height: auto;
`,ma=w.Ay.img`
  height: 100%;
  width: 100%;
  object-fit: cover;
`,ca=e=>{let{...t}=e;const n=(0,u.dn)(),i=n?.briefAndPictures?.diapositives||[];return s.createElement(oa,{className:t.className},s.createElement(sa,t,i.map((e,t)=>s.createElement(pa,{key:t},s.createElement(ma,{src:e.image,alt:e.title})))))},da=w.Ay.div`
  height: 100%;
  width: 100%;
  padding-top: 48px;
  padding-bottom: 24px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
    padding-bottom: 16px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    max-width: 100%;
    padding: 0 0 10px;
  }
`,ua=(0,w.Ay)(be)`
  --swiper-navigation-size: 2rem;
  --swiper-navigation-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  --swiper-pagination-bullet-inactive-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  --swiper-pagination-bullet-size: 0.875rem;

  &.swiper {
    position: initial;
  }

  ${he} {
    top: 64px;
    left: 48px;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
      top: 48px;
      left: 32px;
    }
  }

  .swiper-pagination {
    padding-left: 48px;
    text-align: left;
    bottom: 20px;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
      padding-left: 32px;
      bottom: 10px;
    }
  }
`,ga=w.Ay.div`
  padding-bottom: 48px;
  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    display: none;
  }
`,ha=(0,w.Ay)(k.qr)`
  height: 100%;
  position: initial;
`,xa=w.Ay.div`
  display: flex;
  flex-direction: column;
`,ba=w.Ay.p`
  font-size: 18px;
  font-weight: 500;
  margin: 0;
`,wa=w.Ay.div`
  ul {
    padding-left: 32px;
  }

  & > p:first-of-type {
    padding-top: 24px;
  }

  p {
    font-size: 16px;
    padding: 8px 0;
    margin: 0;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
      max-width: 100%;
      padding: 0;
    }
  }
`,fa=e=>{let{...t}=e;const n=(0,u.dn)(),i=n?.briefAndPictures?.diapositives||[],r=n?.briefAndPictures?.title,a=n?.briefAndPictures?.subtitle;return s.createElement(da,{className:t.className},s.createElement(ga,null,s.createElement(Dr,{title:r,subtitle:a})),s.createElement(ua,t,i.map((e,t)=>s.createElement(ha,{key:t},s.createElement(xa,null,s.createElement(ba,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.title,{USE_PROFILES:{html:!0}})}}),s.createElement(wa,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text,{USE_PROFILES:{html:!0},ADD_ATTR:["target","rel"]})}}))))))},ya=w.Ay.section`
  display: flex;
  margin-top: 24px;
  gap: 24px;
  padding-right: 24px;

  ${e=>{let{theme:t}=e;return t.breakpoints.between("tablet","laptop")}} {
    gap: 0;
    padding: 0 16px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-direction: column;
    padding: 20px 16px;
  }
`,Ea=w.Ay.div`
  position: relative;
  flex: 1;
  max-width: 30%;
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 64px 48px 0;
  display: flex;
  align-items: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    padding: 86px 32px 32px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    max-width: 100%;
    padding: 32px;
  }
`,va=w.Ay.div`
  flex: 2;
  max-width: 70%;

  ${e=>{let{theme:t}=e;return t.breakpoints.between("tablet","laptop")}} {
    padding-right: 16px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex: 1;
    max-width: 100%;
  }
`,Aa=w.Ay.div`
  ${e=>{let{theme:t}=e;return t.breakpoints.up("tablet")}} {
    display: none;
  }
`,ka=()=>{const e=(0,u.dn)(),t=e?.briefAndPictures?.title,n=e?.briefAndPictures?.subtitle,i=e?.briefAndPictures?.diapositives||[],{isBelowOrEqualToBreakpoint:r}=(0,we.d)(),a=r("md"),l=i.length>1,[o,p]=(0,s.useState)(void 0),[m,c]=(0,s.useState)(void 0);return s.createElement(ya,null,s.createElement(Aa,null,s.createElement(Dr,{title:t,subtitle:n})),s.createElement(va,null,s.createElement(ca,{isMultiSlides:l,enableNavigation:!1,enablePagination:!1,controller:{control:o},onSwiper:c,blockName:"brief-picture"})),s.createElement(Ea,null,s.createElement(fa,{isMultiSlides:l,enableNavigation:!a,controller:{control:m},onSwiper:p,blockName:"brief-text"})))},$a=(0,w.Ay)(ta)`
  &.swiper-slide {
    padding: 24px;
    align-items: center;
    justify-content: center;
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
      background-color: #f5f5f5;
    }
  }
`,_a=w.Ay.img`
  width: 100%;
`,Sa=()=>{const e=(0,u.wT)();if(!e?.certifications.length)return null;const{certifications:t,subTitle:n,title:i}=e;return s.createElement(na,null,s.createElement(Dr,{title:i,subtitle:n}),s.createElement(Ee,{blockName:"certifications"},s.createElement(s.Fragment,null,t.map((e,t)=>s.createElement($a,{key:`certif-${t}`},s.createElement(_a,{src:e.logo,alt:`certification numero ${t}`}))))))},za=(0,w.Ay)(ta)`
  &.swiper-slide {
    padding: 0;
    align-items: center;
    justify-content: center;
    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints?.values.smallDevicesLimit}px`}}) {
      background-color: #f5f5f5;
    }
  }
`,Ca=w.Ay.img`
  width: 100%;
  height: 100%;
  border-radius: 8px;
`,La=w.Ay.a`
  cursor: pointer;
  display: block;
  width: 100%;
  height: 100%;
`,Ta=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.dn)(),n=t?.gallery,i=n?.pictures||[],[r,a]=(0,s.useState)(!1),[l,o]=(0,s.useState)(0);return n&&0!==i.length?s.createElement(s.Fragment,null,s.createElement(na,null,s.createElement(Dr,{title:n.title||e("landing_page.gallery"),subtitle:n.subTitle||""}),s.createElement(Ee,{blockName:"gallery"},i.map((e,t)=>s.createElement(za,{key:t},s.createElement(La,{onClick:()=>(e=>{o(e),a(!0)})(t)},s.createElement(Ca,{src:e.srcFullSize,alt:e.title||`Image ${t+1}`})))))),r&&s.createElement(ze,{open:r,onClose:()=>a(!1),title:n.title||e("landing_page.gallery"),subtitle:n.subTitle,items:i,initialSlide:l,blockName:"gallery-modal"})):null};var Ia=n(33106),Pa=n(55481),Ba=n(13532),Na=n(92241);const Ra=w.Ay.footer`
  width: 100%;
  padding: 56px 48px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin-bottom: 4rem;
  }

  background-color: white;
  ${e=>{let{theme:t}=e;return`\n    * {\n      color: ${(0,_.Vh)("#fff",t.palette)};\n    }\n  `}}
`,Ma=w.Ay.div`
  display: flex;
  margin: 30px 0px 56px;
  & > * {
    margin: 0 16px !important;
    text-align: center;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    flex-direction: column;
    align-items: center;
    margin: 24px 0px 32px;
    * {
      margin: 16px 0px !important;
    }
  }
`,Fa=w.Ay.img`
  display: block;
  height: auto;
  width: 156px;
  max-height: 80px;
  object-fit: contain;
`,Oa=w.Ay.div`
  display: flex;
  align-items: center;
  margin-bottom: 12px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    flex-direction: column;
    align-items: center;
    *:first-child {
      margin-right: 0px;
      margin-bottom: 8px;
    }
  }
`,ja=w.Ay.span``,Va=w.Ay.span`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    span {
      display: block;
      text-align: center;
      margin-bottom: 8px;
    }
    ${ja} {
      display: none;
    }
  }
`,Da=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.z)(),n=(0,u.zk)(),i=(0,u.Ou)(),r=e("career_footer_links.required_links",{defaultValue:[],returnObjects:!0}),a=[...i];switch(t){case d.ch.CVC_JOB_OFFERS:case d.ch.CVC_SC:case d.ch.CVC_CORE:}return a.push(...r),s.createElement(Ma,null,n.map(e=>(0,u.UC)(e)?s.createElement(Na.E,{key:e.configKey,to:e.url},e.label):s.createElement(Pa.N,{key:e.configKey,href:e.url,target:"_blank"},e.label)),a.map((e,t)=>"id"in e&&"cookie_handler"===e.id?s.createElement($.xy,{key:t,onClick:()=>window.cvc_orejime.show()},e.label):"url"in e?s.createElement(Pa.N,{key:t,href:e.url,target:"_blank"},e.label):null))},Ha=e=>{let{className:t}=e;const{config:n}=(0,m._r)(),{t:i}=(0,v.Bd)();return s.createElement(Ra,{"data-print-hidden":!0,className:t},s.createElement(Na.E,{to:x.J.HOME},s.createElement(Fa,{src:(0,Ia.pl)(n,Ia.ex.DARK),alt:i("seo_markup.career_site_home_page.title",{clientName:n.company_name})})),s.createElement(Da,null),!n.features?.hide_powered_by&&s.createElement(Oa,null,s.createElement("span",null,i("career_footer.powered_by")),s.createElement(Pa.N,{target:"_blank",href:"https://magnet.work/"},s.createElement(Ba.e,{isWhite:!1}))),s.createElement(Va,null,s.createElement("span",null,"© ",(new Date).getFullYear()," ",i("career_footer.copyright")),n.photoVideoCredits&&s.createElement(s.Fragment,null,s.createElement(ja,null," - "),s.createElement("span",null,i("career_footer.photos_videos_credits")," :"," ",n.photoVideoCredits))))};var qa=n(35133),Ua=n(97134),Xa=n(29285),Wa=n(32673),Ja=n(47566),Ga=n(80012),Za=n(93444);const Ka=(0,w.Ay)(mr)`
  padding: 1.8vh 1.5vw;
`,Qa=(0,w.Ay)(qa.A)`
  border: none;

  & .MuiOutlinedInput-root {
    border-radius: 8px;
    padding: 0.875vh 1.1vw;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
      padding: 8px 18px;
    }

    &.Mui-focused fieldset {
      border: 1px solid ${De.c3[600]};
    }
    &:hover fieldset {
      border: 1px solid ${De.c3[600]};
    }
  }
`,Ya=(0,w.Ay)(Ua.A)`
  background-color: #ffffff;
  border-radius: 8px;
`,el=(0,w.Ay)(Xa.A)`
  .MuiAutocomplete-paper {
    border-radius: 0 0 8px 8px;
    box-shadow: 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
  }

  .MuiAutocomplete-listbox {
    border: 1px solid ${De.c3[200]};
    border-radius: 0 0 8px 8px;
    padding: 16px;
  }

  .MuiAutocomplete-option {
    border-radius: 4px;
    padding: 12px 16px;
    transition: ${e=>{let{theme:t}=e;return`all ${t.transitions.duration.shorter}ms ease`}};

    &.Mui-focused {
      background-color: ${e=>{let{theme:t}=e;const n=t.palette.primary.main;return(0,Ga.X4)(n,.2)}};
    }
  }
`;function tl(e){let{inputValue:t,loading:n,onChange:i,onClick:r,onInputChange:a,options:l,value:o}=e;const{t:p}=(0,v.Bd)();return s.createElement(Ua.A,{spacing:2},s.createElement(Qa,{"data-testid":"job-offers-search-bar",fullWidth:!0,freeSolo:!0,onChange:i,onInputChange:a,value:o,inputValue:t,isOptionEqualToValue:(e,t)=>e.label===t,options:l,loading:!1,clearText:p("job_offers.search_bar.clear_text"),PopperComponent:el,renderInput:e=>{let{InputProps:{ref:t,...i},...r}=e;return s.createElement(Ya,{direction:"row",alignItems:"flex-end",ref:t,spacing:1},s.createElement(Wa.A,(0,ue.A)({},r,{placeholder:p("job_offers.search_bar.placeholder_2022"),InputLabelProps:{shrink:!1},InputProps:{...i,endAdornment:s.createElement(s.Fragment,null,n?s.createElement(Ja.A,{color:"inherit",size:20}):null,i.endAdornment)},variant:"outlined"})))}}),s.createElement(Ka,{onClick:r,buttonText:p("landing_page.search_bar.discover_job_offers")}))}const nl=()=>s.createElement(Za.Rq,{view:tl,smallSearchBar:!0}),il=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;

  ${li.uM} {
    position: static;
  }

  ${se} {
    width: auto;
    margin-bottom: ${e=>{let{theme:t}=e;return t.template!==d.tC.BENTO_2024&&"1.9rem"}};
    background-color: transparent;
  }
`,rl=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 32px;
  margin: 0 auto;
  height: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    gap: 16px;
  }

  ${se} {
    .MuiBox-root {
      padding: 0;
    }
  }
`,al=(0,w.Ay)(O.hE)`
  font-size: 1.4rem;
  margin: 0;
  width: 100%;
  text-align: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    font-size: 1.2rem;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    font-size: 1rem;
    text-align: left;
  }
`,ll=(0,w.Ay)(R.A)`
  width: 200px;
  height: 26px;
  background-color: lightgrey;
`,ol=(0,w.Ay)(F.A)`
  font-size: 1.125rem;
  margin: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    font-size: 1rem;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    font-size: 0.875rem;
    width: 100%;
    text-align: left;
  }
`,sl=w.Ay.div`
  width: 100%;
  margin: 0;
  input::placeholder {
    font-size: 1rem !important; // needs important to override #cvcatcher-app global styles
  }
`,pl=w.Ay.div`
  display: flex;
  gap: 0 16px;
  align-items: center;
  text-align: center;
  text-transform: uppercase;
  margin: 0;
  width: 100%;

  &::before,
  &::after {
    content: "";
    flex-grow: 1;
    width: auto;
    height: 1px;
    background-color: ${De.c3[200]};
  }
`,ml=(0,w.Ay)(F.A)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 3rem;
  height: 2vh;
  text-align: center;
  font-weight: bold;
  font-size: 16px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    height: 2rem;
  }
`,cl=(0,w.Ay)(pe)`
  ${oi.J_} {
    padding: 2vh 1.5vw;
  }
  ${oi.D6} {
    font-size: 1rem;
  }

  ${oi.Kd} {
    display: none;
  }
`,dl=()=>{const{config:e}=(0,m._r)(),{t}=(0,v.Bd)(),{total:n,isFetching:i}=(0,u.GV)(e=>e.lastJobOffers),r=window.innerHeight>700;return s.createElement(il,null,s.createElement(rl,null,s.createElement(al,{variant:"h2",autoContrast:!0},t("career_website_landing.search_section.title.bottom_line",{client_name:e.company_name})),i?s.createElement(ll,null):s.createElement(ol,{autoContrast:!0},t("career_website_landing.search_section.title.top_line",{count:n})),s.createElement(sl,null,s.createElement(nl,null)),r?s.createElement(s.Fragment,null,s.createElement(pl,null,s.createElement(ml,{variant:"span",color:De.c3[500]},t("career_website_landing.search_section.or"))),s.createElement(pe,{displayAnalysisInModal:!0})):s.createElement(cl,{displayAnalysisInModal:!0})))},ul=w.Ay.button`
  position: fixed;
  bottom: 5%;
  left: 50%;
  transform: translateX(-50%);
  width: 88%;
  z-index: 1000;
  border-radius: 8px;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
`,gl=w.Ay.div`
  display: flex;
  padding: 20px;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  gap: 15px;
`,hl=(0,w.Ay)(Mi.A)`
  .MuiDrawer-paper {
    border-radius: 8px 8px 0 0;
  }
`,xl=(0,w.Ay)(M.A)`
  width: 100%;
  background-color: white;
  padding: 16px 20px;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
`,bl=w.Ay.button`
  align-self: flex-end;
  background: none;
  border: none;
  cursor: pointer;
  margin-bottom: 10px;
`,wl=(0,w.Ay)(j.g)`
  margin: 30px 0 15px 0;
  text-align: center;
  font-size: 14px;
  font-weight: 400;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    margin: 20px 0 15px 0;
  }
`,fl=()=>{const{t:e}=(0,v.Bd)(),[t,n]=(0,s.useState)(!1),i=()=>n(!0),r=()=>n(!1);return s.createElement(s.Fragment,null,s.createElement(ul,{onClick:i},s.createElement(gl,null,s.createElement(bt.C0,{fill:"#ffffff"}),s.createElement("span",null," ",e("landing_page.floating_search_button")))),s.createElement(hl,{anchor:"bottom",open:t,onClose:r,onOpen:i,disableSwipeToOpen:!0},s.createElement(xl,null,s.createElement(bl,{type:"button",onClick:()=>r()},s.createElement(bt.MR,{width:"24px",height:"24px"})),s.createElement(dl,null),s.createElement(wl,{to:x.J.SEARCH,"data-testid":"cvc-career-landing-btn-all-offer",hoverColor:De.c3[900]},e("career_website_landing.search_section.see_all_2022")))))},yl=w.Ay.main`
  height: max(100vh, 600px);
  display: flex;
  gap: 1.5rem;
  overflow-y: auto;
  padding: 2rem;
  width: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("thirteenInchScreen")}} {
    padding: 1.5rem;
  }
`,El=w.Ay.main`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row;
  gap: 44px;
`,vl=w.Ay.section`
  display: flex;
  margin-top: 24px;
  gap: 24px;
`,Al=w.Ay.div`
  position: relative;
  flex: ${e=>{let{flex:t}=e;return t}};
  display: ${e=>{let{advantagesListLength:t,displayAdvantagesBlock:n}=e;return t&&n?"flex":"none"}};
  max-width: ${e=>{let{videoUrl:t,displayVideoBlock:n,advantagesMaxWidth:i}=e;return t&&n?i:"100%"}};
  align-items: center;
`,kl=w.Ay.div`
  flex: ${e=>{let{flex:t}=e;return t}};
  display: ${e=>{let{videoUrl:t,displayVideoBlock:n}=e;return t&&n?"block":"none"}};
  max-width: ${e=>{let{advantagesListLength:t,displayAdvantagesBlock:n,videoMaxWidth:i}=e;return t&&n?i:"100%"}};
`;let $l=function(e){return e.LargerAdvantages="largerAdvantages",e.Equal="equal",e.LargerVideo="largerVideo",e}({});const _l=e=>{let{AdvantagesView:t,VideoView:n,sizeRatio:i=$l.Equal,...r}=e;const a=(0,u.dn)(),l=a?.advantages?.list||[],o=a?.videoTemplate?.url,p=Ur("videoTemplate"),m=Ur("advantages"),{advantagesFlex:c,videoFlex:d}=(()=>{switch(i){case $l.LargerAdvantages:return{advantagesFlex:2,videoFlex:1};case $l.LargerVideo:return{advantagesFlex:1,videoFlex:2};case $l.Equal:default:return{advantagesFlex:1,videoFlex:1}}})(),{advantagesMaxWidth:g,videoMaxWidth:h}=(()=>{switch(i){case $l.LargerAdvantages:return{advantagesMaxWidth:"66%",videoMaxWidth:"33%"};case $l.LargerVideo:return{advantagesMaxWidth:"33%",videoMaxWidth:"66%"};case $l.Equal:default:return{advantagesMaxWidth:"50%",videoMaxWidth:"50%"}}})();return s.createElement(vl,r,m&&s.createElement(Al,{videoUrl:o,advantagesListLength:l.length,displayVideoBlock:p,displayAdvantagesBlock:m,flex:c,advantagesMaxWidth:g},s.createElement(t,null)),p&&s.createElement(kl,{videoUrl:o,advantagesListLength:l.length,displayVideoBlock:p,displayAdvantagesBlock:m,flex:d,videoMaxWidth:h},s.createElement(n,null)))},Sl=(0,w.Ay)(na)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("smallDevicesLimit")}} {
    margin-top: 46px;
  }
`,zl=(0,w.Ay)(Ee)`
  .swiper-slide {
    padding-top: 36px;
  }
`,Cl=(0,w.Ay)(O.hE)`
  font-size: 1rem;
  margin: 0;
  margin-bottom: 16px;
`,Ll=w.Ay.p`
  font-size: 1rem;
  margin: 0;
`,Tl=()=>{const e=(0,u.dn)(),t=e?.advantages;if(!t?.list?.length)return null;const n=t?.list&&t.list?.length>1;return s.createElement(Sl,null,s.createElement(Dr,{title:t.title,subtitle:t.subTitle}),s.createElement(zl,{blockName:"advantages",smallBreakpoint:"smallDevicesLimit",isMultiSlides:n},t.list.map((e,t)=>s.createElement(ta,{key:t},s.createElement(Cl,{variant:"h4",dangerouslySetInnerHTML:{__html:E.A.sanitize(e.title,{USE_PROFILES:{html:!0}})}}),s.createElement(Ll,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text,{USE_PROFILES:{html:!0}})}})))))},Il=(0,w.Ay)(tn)`
  border-radius: 8px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    ${Kt} {
      padding: 18px 18px 18px 20px;
    }
  }
`,Pl=()=>s.createElement(Il,{playIconPosition:en.BottomLeft}),Bl=w.Ay.div`
  width: 100%;
`,Nl=(0,w.Ay)(be)`
  position: static;
  border-radius: 8px;
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  --swiper-pagination-bullet-inactive-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  --swiper-pagination-bullet-size: 0.875rem;
  --swiper-navigation-size: 2rem;

  .swiper-pagination {
    padding-left: 48px;
    text-align: left;
  }
`,Rl=(0,w.Ay)(k.qr)`
  height: 100%;
`,Ml=w.Ay.div`
  padding: 0;
  display: flex;
  flex-direction: column;
`,Fl=w.Ay.p`
  font-size: 18px;
  font-weight: 500;
  margin: 0;
`,Ol=w.Ay.p`
  font-size: 16px;
  margin: 28px 0;
`,jl=w.Ay.div`
  padding-bottom: 32px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    padding-bottom: 24px;
  }
`,Vl=(0,w.Ay)(S.o5)`
  font-size: 24px;
  font-weight: 700;
  margin: 0;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    font-size: 22px;
  }
`,Dl=w.Ay.span`
  color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
`,Hl=e=>{let{title:t,subtitle:n}=e;return s.createElement(jl,null,s.createElement(Vl,{variant:"h2"},t,n&&s.createElement(Dl,null," ",n)))},ql=e=>{let{enableNavigation:t=!0,enablePagination:n=!0,...i}=e;const r=(0,u.dn)(),a=r?.advantages?.list||[],l=r?.advantages?.title,o=r?.advantages?.subTitle,p=a.length>1;return a.length<1?null:s.createElement(Bl,i,l&&s.createElement(Hl,{title:l,subtitle:o}),s.createElement(Nl,{enablePagination:n,enableNavigation:t,blockName:"adv",isMultiSlides:p},a.map((e,t)=>s.createElement(Rl,{key:t},s.createElement(Ml,null,s.createElement(Fl,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.title,{USE_PROFILES:{html:!0}})}}),s.createElement(Ol,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text,{USE_PROFILES:{html:!0}})}}))))))},Ul=(0,w.Ay)(ql)`
  ${ge} {
    --swiper-navigation-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  }

  ${he} {
    top: 64px;
    left: 48px;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
      top: 48px;
      left: 32px;
    }
  }

  ${Nl} {
    position: initial;
    .swiper-pagination {
      padding-left: 0;
      left: 48px;
      bottom: 20px;

      @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
        left: 32px;
      }
    }
  }
`,Xl=()=>s.createElement(Ul,{enableNavigation:!0,enablePagination:!0}),Wl=()=>s.createElement(Ul,{enableNavigation:!1}),Jl=(0,w.Ay)(_l)`
  ${Al} {
    padding: 94px 48px 48px;
    border-radius: 8px;
    background-color: ${_.WK};

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
      padding: 94px 32px 32px;
    }
  }
`,Gl=(0,w.Ay)(_l)`
  flex-direction: column;
  padding: 20px 16px;

  ${Al} {
    max-width: 100%;
    border-radius: 8px;
    background-color: ${_.WK};
    padding: 32px;
  }

  ${kl} {
    flex: 1;
    max-width: 100%;
  }
`,Zl=()=>Ur("videoTemplate")?s.createElement(Jl,{AdvantagesView:Xl,VideoView:Pl,sizeRatio:$l.LargerVideo}):s.createElement(Tl,null),Kl=()=>Ur("videoTemplate")?s.createElement(Gl,{AdvantagesView:Wl,VideoView:Pl,sizeRatio:$l.LargerVideo}):s.createElement(Tl,null),Ql=(0,w.Ay)(be)`
  width: 100%;
  height: 100%;

  .swiper-pagination {
    display: none;
  }

  ${he} {
    left: initial;
    right: 36px;
    bottom: 36px;

    .swiper-button-prev,
    .swiper-button-next {
      color: #ffffff;
    }
  }
`,Yl=(0,w.Ay)(k.qr)`
  height: auto;
`,eo=w.Ay.div`
  display: flex;
  gap: 16px;
  height: 100%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    flex-direction: column;
  }
`,to=w.Ay.div`
  width: 100%;
  height: 100%;
  border-radius: 8px;
`,no=(0,w.Ay)(to)`
  background-color: #000000;
  width: 100%;

  .react-player__preview {
    position: relative;
    border-radius: 8px;

    &::before {
      border-radius: 8px;
      content: "";
      display: block;
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
      background-color: rgba(0, 0, 0, 0.33);
    }
  }
`,io=w.Ay.div`
  height: 100%;
  width: 100%;
  border-radius: 8px;
  position: relative;
  background-size: cover;
  background-position: center center;
  background-image: url(${e=>{let{imagePath:t}=e;return t}});
`,ro=(0,w.Ay)(Yt)`
  ${e=>{let{theme:t}=e;return t.breakpoints.between("tablet","desktop")}} {
    top: 50%;
  }

  ${Kt} {
    padding: 22px 22px 22px 24px;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
      padding: 18px 18px 18px 20px;
    }
  }
`,ao=(0,w.Ay)(Xt)`
  left: 16px;
  top: 16px;
`,lo=e=>{let{onClick:t}=e;return s.createElement(ao,{onClick:t},s.createElement(bt.g1,{fill:"#fff"}))},oo=e=>{let{controller:t,onSwiper:n,isMultiSlides:i,swiperContent:r,...a}=e;const{isBelowOrEqualToBreakpoint:l}=(0,we.d)(),o=l("md");return s.createElement(Ql,(0,ue.A)({onSwiper:n,controller:t,isMultiSlides:i,enableNavigation:!o,blockName:"team"},a),r.map((e,t)=>s.createElement(Yl,{key:t},t=>{let{isActive:n}=t;return s.createElement(eo,null,e.video?s.createElement(no,null,s.createElement(Wt,{StopIconComponent:lo,isActive:n,url:e.video,preview:e.images?.[1],playIcon:s.createElement(ro,null)})):s.createElement(to,null,s.createElement(io,{imagePath:e.images[1]})))})))},so=(0,w.Ay)(be)`
  --swiper-pagination-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
  --swiper-pagination-bullet-inactive-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  border-radius: initial;
  --swiper-navigation-size: 2rem;
  height: 100%;

  .swiper-button-prev,
  .swiper-button-next {
    display: none;
  }
  .swiper-pagination {
    display: none;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      bottom: 16px;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    &.swiper-horizontal > .swiper-pagination-bullets {
      display: block;
      text-align: left;
      left: 28px;
    }
  }
`,po=w.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  height: 100%;
`,mo=w.Ay.div`
  display: flex;
  gap: 16px;
  width: 100%;
  flex-basis: 66%;
  height: 100%;
`,co=w.Ay.div`
  width: 50%;
  height: 100%;
`,uo=w.Ay.div`
  height: 100%;
  width: 100%;
  border-radius: 8px;
  position: relative;
  background-size: cover;
  background-position: top center;
  background-image: url(${e=>{let{imagePath:t}=e;return t}});
`,go=w.Ay.div`
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  gap: 16px;
  padding: 32px;
  background-color: ${_.WK};
  justify-content: center;

  ${e=>{let{withTestimony:t}=e;return`\n      flex-basis: ${t?"66%":"35%"};\n  `}}

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-basis: 45%;
  }
`,ho=w.Ay.p`
  font-size: 16px;
  margin: 0;
`,xo=(0,w.Ay)(k.qr)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding-right: 0;
  }
`,bo=w.Ay.p`
  font-size: 20px;
  margin: 0;
  font-weight: 600;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    font-size: 18px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    font-size: 16px;
    margin-bottom: 0;
  }
`,wo=(0,w.Ay)(bo)`
  font-size: 18px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    font-size: 16px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    font-size: 14px;
  }
`,fo=(0,w.Ay)(Dr)`
  margin-bottom: 8px;
`,yo=e=>{let{onSwiper:t,controller:n,isMultiSlides:i,swiperContent:r,title:a,subTitle:l,hasAtLeastOneSlideWithoutTestimony:o}=e;return r.length<1?null:s.createElement(so,{onSwiper:t,controller:n,isMultiSlides:i,blockName:"team"},r.map((e,t)=>{const n=!!e.testimony;return s.createElement(xo,{key:t},s.createElement(po,null,s.createElement(mo,null,s.createElement(co,null,s.createElement(uo,{imagePath:e.images[0]})),s.createElement(co,null,s.createElement(uo,{imagePath:e.images[2]}))),s.createElement(go,{withTestimony:n},o&&a&&s.createElement(Ve.rb,{up:!0},s.createElement(fo,{title:a,subtitle:l})),s.createElement(bo,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.name,{USE_PROFILES:{html:!0}})}}),s.createElement(wo,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.job,{USE_PROFILES:{html:!0}})}}),e.testimony&&s.createElement(ho,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.testimony,{USE_PROFILES:{html:!0}})}}))))}))},Eo=w.Ay.section`
  display: flex;
  gap: 16px;
  margin-top: 24px;
  align-items: stretch;
  min-height: 500px;
  max-height: max(75vh, 100%);
  width: 100%;
  position: relative;
  padding-right: 16px;

  ${e=>{let{theme:t}=e;return t.breakpoints.between("tablet","laptop")}} {
    padding: 0 16px;
    gap: 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-direction: column;
    padding: 0 16px;
    max-height: 120vh;
    margin-top: 0;
  }
`,vo=w.Ay.div`
  aspect-ratio: 3/2;
  width: 60%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    width: 40%;
    min-height: 50vh;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.between("tablet","laptop")}} {
    padding: 0 8px 0 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    width: 100%;
    height: 35vh;
  }
`,Ao=w.Ay.div`
  width: 40%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    width: 60%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.between("tablet","laptop")}} {
    padding: 0 0 0 8px;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    width: 100%;
  }
`,ko=(0,w.Ay)(Dr)`
  margin: 32px auto 8px 0;
`,$o=(0,w.Ay)(Dr)`
  position: absolute;
  bottom: 40%;
  margin-left: 32px;
  z-index: 11;
`,_o=()=>{const e=(0,u.dn)(),{title:t,subTitle:n,list:i=[]}=e?.team||{},r=i.length>1,a=!!i.find(e=>!e.testimony),[l,o]=(0,s.useState)(void 0),[p,m]=(0,s.useState)(void 0);return s.createElement(Eo,null,t&&s.createElement(Ve.jp,{down:!0},s.createElement(ko,{title:t,subtitle:n})),s.createElement(vo,null,s.createElement(oo,{onSwiper:o,controller:{control:p},swiperContent:i,isMultiSlides:r})),s.createElement(Ao,null,!a&&t&&s.createElement(Ve.rb,{up:!0},s.createElement($o,{title:t,subtitle:n})),s.createElement(yo,{onSwiper:m,controller:{control:l},swiperContent:i,isMultiSlides:r,title:t,subTitle:n,hasAtLeastOneSlideWithoutTestimony:a})))};var So=n(81554),zo=n(59193),Co=n(85761),Lo=n(79273);const To=w.Ay.span`
  display: flex;
  align-items: center;
  justify-content: center;
  ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.values.smallDevicesLimit}px) {\n        margin-left: 0;\n        padding: 0;\n      }\n    `}}
`,Io=(0,w.Ay)(yt.A)`
  ${e=>{let{open:t,theme:n}=e;return`\n    transition: all ${n.transitions.duration.short}ms ease;\n    ${t&&"transform: rotateZ(180deg);"}\n  `}}
`,Po=w.Ay.button`
  background: #ffffff;
  border: none;
  border-radius: 4px;
  gap: 11px;
  padding: 8px 11px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: space-between;
`,Bo=(0,zo.Ay)(So.Ay)`
  margin-top: 8px;
  max-height: 310px;

  ${e=>{let{template:t=d.tC.BENTO_2024}=e;return t===d.tC.PIPE_2025?"\n          margin-left: 0;\n        ":"\n          margin-left: 52px;\n        "}}
`,No=w.Ay.div`
  padding: 16px;
  margin: 0;
  min-width: 127px;
  min-height: 118px;
  display: flex;
  gap: 8px;
  flex-direction: column;
  justify-content: space-evenly;
`,Ro=(0,w.Ay)(S.Li)`
  cursor: pointer;
  user-select: none;
  padding: 8px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  ${e=>{let{isSelected:t,theme:n}=e;const i=(0,_.x6)(n.palette,_.ll,_.qf),r=(0,_.Vh)(i,n.palette);return`\n    ${t&&`\n        background-color: ${i};\n        color: ${r};\n      `}\n    transition: all ${n.transitions.duration.shorter}ms ease;\n    &:hover, &:focus {\n        background-color: ${i};\n        color: ${r};\n    };\n  `}}
`,Mo=w.Ay.span`
  margin-left: 8px;
`,Fo=w.Ay.div`
  display: flex;
  align-items: center;
  overflow: visible;
  position: absolute;
  right: 20px;
  top: 20px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.smallDevicesLimit}px`}}) {
    left: 16px;
    top: 28px;
  }
`,Oo=(0,w.Ay)(e=>{let{language:t,selected:n,className:i}=e;const{t:r}=(0,v.Bd)(),{isSearchPage:a}=(0,u.a8)(),l=e=>{window.location.href=(e=>{const t=new URL(window.location.href);return t.pathname=`/${e}`,a&&(t.pathname+=x.J.SEARCH),t.toString()})(e)};return s.createElement(Ro,{key:t,isSelected:n,onClick:()=>l(t),className:i},s.createElement(Lo.d,{lang:t}),s.createElement(Mo,null,r(`languages_names.${t}`)))})``;const jo=(0,w.Ay)(function(e){let{className:t,menuItem:n=Oo}=e;const{config:i}=(0,m._r)(),{i18n:r}=(0,v.Bd)(),a=i.supported_languages,[l,o]=s.useState(null),p=Boolean(l),c=(0,s.useCallback)(()=>{o(null)},[]);return(0,s.useEffect)(()=>(document.addEventListener("scroll",c),()=>document.removeEventListener("scroll",c)),[c]),s.createElement(Fo,{className:t},s.createElement(Ve.ad,null,s.createElement(Po,{onClick:e=>{o(e.currentTarget)},"data-testid":"cvc-languages-selector-button"},s.createElement(Lo.d,{lang:r.language}),(0,Co.A)(r.language),s.createElement(To,null,s.createElement(Io,{View:bt.rI,size:24,fill:_.QZ,open:p,withContrast:!0})))),s.createElement(Bo,{template:i.template,open:p,anchorEl:l,onClose:c,disableScrollLock:!0,anchorOrigin:{vertical:"bottom",horizontal:"center"},transformOrigin:{vertical:"top",horizontal:"right"},PaperProps:{style:{borderRadius:i.template===d.tC.PIPE_2025?"24px":"4px",scrollbarWidth:"none"}}},s.createElement(No,null,a.map(e=>{return s.createElement(n,{selected:(t=e,t===r.language),key:e,language:e});var t}))))})``,Vo=w.Ay.header`
  width: 100%;
  margin-top: 32px;
  display: flex;
  justify-content: center;
  z-index: 2;
  position: ${e=>{let{position:t}=e;return t}};
  background-color: ${e=>{let{theme:t,transparent:n}=e;return n?"transparent":t.palette.primary.main}};

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    margin-top: 16px;
  }
`,Do=w.Ay.h1`
  margin: 0;

  span {
    display: block;
    height: 0;
    text-indent: -9999px;
  }

  img {
    display: block;
    height: auto;
    width: 100%;
    max-height: 175px;
    max-width: 250px;
    object-fit: contain;
  }
`,Ho=e=>{let{position:t="absolute",transparent:n=!1,className:i,children:r}=e;return s.createElement(Vo,{"data-print-hidden":!0,transparent:n,position:t,className:i},r)};Ho.LanguageSelector=e=>(0,u.XV)()?s.createElement(jo,e):null,Ho.RouterLink=e=>{let{logoType:t=Ia.ex.LIGHT,className:n}=e;const{config:i}=(0,m._r)(),{t:r}=(0,v.Bd)(),a=(0,u.Pn)(),l=r("seo_markup.career_site_home_page.title",{clientName:i.company_name});return s.createElement(Na.E,{to:x.J.HOME,className:n},s.createElement(Do,null,s.createElement("span",null,l),a&&s.createElement("img",{src:(0,Ia.XH)(i,t),alt:`Logo ${i.company_name}`})))};const qo=(0,w.Ay)(Ho.RouterLink)`
  padding-top: 16px;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("largeDesktop")}} {
    img {
      max-width: 195px;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    img {
      max-width: 175px;
    }
  }
`,Uo=()=>s.createElement(Ho,{position:"static",transparent:!0},s.createElement(Ho.LanguageSelector,null),s.createElement(qo,{logoType:Ia.ex.DARK})),Xo=w.Ay.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-radius: 8px;
  background-color: #f5f5f5;
  position: sticky;
  height: 100%;
  gap: 56px;
  padding: 2rem;
  overflow: auto;
  top: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("thirteenInchScreen")}} {
    padding: 2rem 1.5rem;
  }
`,Wo=()=>s.createElement(Xo,null,s.createElement(Uo,null),s.createElement(dl,null)),Jo=(0,w.Ay)(Ho.LanguageSelector)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    top: 0;
  }
`,Go=(0,w.Ay)(Ho.RouterLink)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding-top: 16px;

    img {
      max-width: 165px;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    img {
      max-width: 125px;
    }
  }
`,Zo=()=>s.createElement(Ho,{transparent:!0},s.createElement(Jo,null),s.createElement(Go,null)),Ko=w.Ay.div`
  flex: 3;
  min-width: 0;
`,Qo=w.Ay.div`
  width: 100%;
`,Yo=()=>s.createElement(s.Fragment,null,s.createElement(ei,null,s.createElement(Y,null),s.createElement(yl,null,s.createElement(Ko,null,s.createElement(xr,null),Ur("keyInformations")&&s.createElement(kr,null),s.createElement(ea,null),s.createElement(Zl,null),Ur("recruitmentSteps")&&s.createElement(la,null),Ur("briefAndPictures")&&s.createElement(ka,null),Ur("team")&&s.createElement(_o,null),Ur("employerCertifications")&&s.createElement(Sa,null),Ur("gallery")&&s.createElement(Ta,null),s.createElement(Ha,null)),s.createElement(Wo,null)))),es=()=>s.createElement(s.Fragment,null,s.createElement(ti,null,s.createElement(Y,null),s.createElement(Zo,null),s.createElement(El,null,s.createElement(Qo,null,s.createElement(xr,null),Ur("keyInformations")&&s.createElement(kr,null),s.createElement(ea,null),s.createElement(Kl,null),Ur("recruitmentSteps")&&s.createElement(la,null),Ur("briefAndPictures")&&s.createElement(ka,null),Ur("team")&&s.createElement(_o,null),Ur("employerCertifications")&&s.createElement(Sa,null),Ur("gallery")&&s.createElement(Ta,null),s.createElement(Ha,null)),s.createElement(fl,null)))),ts=()=>{const{isBelowOrEqualToBreakpoint:e}=(0,we.d)(),t=e("laptop");return s.createElement(ae,{view:t?es:Yo})},ns=(0,w.Ay)(be)`
  height: 100vh;
  ${bn};

  ${he} {
    position: relative;
    margin-top: calc(var(--swiper-navigation-size) / 2);
  }

  .swiper-pagination-bullets {
    bottom: 0;
    padding: 76px;
    text-align: left;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
      padding: 3rem;
    }

    ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
      text-align: center;
      margin-left: 0;
    }
  }
`,is=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  gap: 28px;
  padding: 8rem 5rem;
  height: 100%;
  max-width: 50vw;

  & > * {
    z-index: 10;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("desktop")}} {
    gap: 24px;
    padding: 5rem 3rem;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 5rem 1.5rem;
    max-width: 100%;
    text-align: center;
  }
`,rs=(0,w.Ay)(S.o5)`
  font-size: 40px;
  font-weight: 700;
  line-height: 1.2;
  margin: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    font-size: 32px;
  }
`,as=(0,w.Ay)(S.o5)`
  font-size: 16px;
  line-height: 1.5;
  font-weight: 600;
  margin: 0;

  p {
    margin: 0;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    font-weight: 400;
  }
`,ls=e=>{let{title:t,paragraph:n}=e;return s.createElement(s.Fragment,null,s.createElement(rs,{autoContrast:!0,variant:"h2",dangerouslySetInnerHTML:{__html:E.A.sanitize(t,{USE_PROFILES:{html:!0}})}}),n&&s.createElement(as,{autoContrast:!0,variant:"p",dangerouslySetInnerHTML:{__html:E.A.sanitize(n,{USE_PROFILES:{html:!0}})}}))},os=()=>{const e=(0,u.XB)(),{isBelowOrEqualToBreakpoint:t}=(0,u.dv)(),n=(0,u.Ee)(),i=e.length>1,r=t("laptop");return s.createElement(ns,{blockName:"cover",enableNavigation:!1,isMultiSlides:i,navigation:{prevEl:"#swiper-cover-prev",nextEl:"#swiper-cover-next"}},e.map((e,t)=>s.createElement(k.qr,{key:t},s.createElement(S.DN,{alt:`photo carousel numéro ${t}`,src:e.bgImage,bgPosition:e.bgPosition}),s.createElement(is,null,n&&s.createElement(y.A,{disableGutters:!0},s.createElement(S.tm,null)),i&&!r&&s.createElement(he,null,s.createElement("div",{id:"swiper-cover-prev",className:"swiper-button-prev"}),s.createElement("div",{id:"swiper-cover-next",className:"swiper-button-next"})),s.createElement(ls,{title:e.title,paragraph:e.paragraph})))))},ss=(0,w.Ay)(Oo)`
  border-radius: 24px;
  padding: 8px 18px;
`,ps=(0,w.Ay)(Ho)`
  ${e=>{let{theme:t}=e;return t.breakpoints.between("laptop","desktop")}} {
    width: 75%;
  }
`,ms=(0,w.Ay)(Ho.LanguageSelector)`
  left: 24px;
  right: 0;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    top: 0;
  }

  button {
    background-color: transparent;
    border-radius: 100px;
    border: 1px solid #fff;
    color: ${e=>{let{theme:t}=e;return t.palette.text.dark.primary}};
  }
`,cs=(0,w.Ay)(Ho.RouterLink)`
  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding-top: 96px;

    img {
      max-width: 185px;
    }
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("mobile")}} {
    padding-top: 32px;

    img {
      max-width: 145px;
    }
  }
`,ds=e=>s.createElement(ps,(0,ue.A)({transparent:!0},e),s.createElement(ms,{menuItem:ss}),s.createElement(cs,null)),us=w.Ay.div`
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
  flex: 1;
`,gs=(0,w.Ay)(be)`
  .swiper-slide {
    height: auto;
  }

  ${he} {
    --swiper-navigation-size: 2.5rem;
    right: 48px;
    left: initial;
    bottom: 48px;

    .swiper-button-prev,
    .swiper-button-next {
      position: static;
      display: inline-block;
      vertical-align: middle;
      color: #fff;

      @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
        display: none;
      }
    }
  }

  height: 100%;
  border-radius: 16px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    border-radius: 0;
    .swiper-pagination {
      bottom: 24px;
    }

    ${bn};
  }
`,hs=w.Ay.img`
  height: 100%;
  width: 100%;
  object-fit: cover;
  border-radius: 16px;
  z-index: 0;
  display: block;
  position: relative;

  ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.values.pipe2025SmallDevicesLimit}px) {\n        border-radius: 0px;\n      }\n  `}}
`,xs=w.Ay.div`
  position: relative;
  display: inline-block;
  width: 100%;
  height: 100%;
  max-height: 650px;

  &::before {
    content: "";
    position: absolute;
    border-radius: 16px;
    z-index: 1;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: radial-gradient(
      circle at bottom right,
      rgba(0, 0, 0, 0.3),
      transparent 80%
    );
    pointer-events: none;
  }
`,bs=e=>s.createElement(xs,null,s.createElement(hs,e)),ws=e=>{let{imageSwiper:t,setTextSwiper:n,isMultiSlides:i}=e;const r=(0,u.dn)(),{isBelowOrEqualToBreakpoint:a}=(0,we.d)(),l=a("pipe2025SmallDevicesLimit"),o=r?.briefAndPictures?.diapositives||[];return s.createElement(us,null,s.createElement(gs,{spaceBetween:4,blockName:"company-brief",isMultiSlides:i,enablePagination:l&&i,enableNavigation:!l&&i,onSwiper:n,controller:{control:t}},o.map((e,t)=>s.createElement(k.qr,{key:t},s.createElement(bs,{src:e.image,alt:e.title})))))},fs=w.Ay.div`
  width: 100%;
  height: 100%;
  border-radius: 8px;
  padding: 24px 0;
  position: relative;
  align-content: center;
  --swiper-navigation-size: 2rem;
  --swiper-navigation-color: #000;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 8px 0;
  }
`,ys=(0,w.Ay)(be)`
  border-radius: 8px;

  ${xn};

  .swiper-pagination {
    padding-left: 2.25vw;
    text-align: left;
    bottom: 0;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      margin-left: 32px;
      bottom: 32px;
    }
  }
`,Es=(0,w.Ay)(k.qr)`
  height: 100%;
`,vs=w.Ay.div`
  padding: 0 2.25vw;
  display: flex;
  flex-direction: column;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 0 32px;
  }
`,As=w.Ay.p`
  font-size: 20px;
  font-weight: bold;
  margin: 0;
`,ks=w.Ay.p`
  font-size: 16px;
  margin-bottom: 28px;
  margin-top: 8px;
`,$s=e=>{let{textSwiper:t,setImageSwiper:n,isMultiSlides:i}=e;const r=(0,u.dn)(),{isBelowOrEqualToBreakpoint:a}=(0,we.d)(),l=a("tablet"),{diapositives:o=[]}=r?.briefAndPictures||{};return s.createElement(fs,null,s.createElement(ys,{blockName:"brief-text",isMultiSlides:i,onSwiper:n,controller:{control:t},enablePagination:!l&&i,enableNavigation:l&&i},o.map((e,t)=>s.createElement(Es,{key:t},s.createElement(vs,null,s.createElement(As,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.title,{USE_PROFILES:{html:!0}})}}),s.createElement(ks,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text,{USE_PROFILES:{html:!0},ADD_ATTR:["target","rel"]})}}))))))},_s=(0,w.Ay)(O.hE)`
  font-size: 22px;
  margin: 0;
  z-index: 11;
`,Ss=e=>{let{title:t,subTitle:n,...i}=e;return t?s.createElement(_s,(0,ue.A)({variant:"h2"},i),t,n&&s.createElement(s.Fragment,null," ",n)):null},zs=w.Ay.div`
  display: flex;
  gap: 24px;
  margin-top: 64px;
  align-items: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex-direction: column;
  }
`,Cs=w.Ay.div`
  flex: 1;
  max-width: 30%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    max-width: 50%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    max-width: 100%;
  }
`,Ls=w.Ay.div`
  flex: 2;
  max-width: 68%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    max-width: 50%;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    flex: 1;
    max-width: 100%;
  }
`,Ts=(0,w.Ay)(Ss)`
  padding-left: 2.25vw;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    margin-right: auto;
    padding-left: 32px;
  }
`,Is=()=>{const e=(0,u.dn)(),{title:t,subtitle:n}=e?.briefAndPictures||{};return s.createElement(Ts,{title:t,subTitle:n})},Ps=()=>{const e=(0,u.dn)(),t=(e?.briefAndPictures?.diapositives||[]).length>1,[n,i]=(0,s.useState)(void 0),[r,a]=(0,s.useState)(void 0);return s.createElement(zs,null,s.createElement(Ve.jp,{down:!0},s.createElement(Is,null)),s.createElement(Ls,null,s.createElement(ws,{isMultiSlides:t,imageSwiper:n,setTextSwiper:a})),s.createElement(Cs,null,s.createElement(Ve.rb,{up:!0},s.createElement(Is,null)),s.createElement($s,{isMultiSlides:t,textSwiper:r,setImageSwiper:i})))},Bs=(0,w.Ay)(be)`
  .swiper-button-prev,
  .swiper-button-next {
    background-color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
  }
`,Ns=w.Ay.div`
  border-radius: 100px;
  border: 1px solid ${De.c3[900]};
  background-color: #fff;
  display: flex;
  justify-content: center;
  gap: 20px;
  align-items: center;
  padding: 24px;
`,Rs=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  white-space: nowrap;

  * {
    font-size: 14px;
    line-height: 1.5;
  }
`,Ms=(0,w.Ay)(S.o5)`
  margin: 0;
  font-weight: 600;
`,Fs=w.Ay.span`
  p {
    margin: 0;
  }
`,Os=w.Ay.div`
  background-color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
  padding: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  height: 40px;
  width: 40px;

  svg {
    fill: ${e=>{let{theme:t}=e;return t.palette.getContrastText(t.palette.primary.main)}};
  }
`,js=e=>{let{name:t}=e;const n=ft[t]||ft.people,i=s.forwardRef((e,t)=>s.createElement(n,(0,ue.A)({},e,{ref:t})));return i.displayName="WrappedIcon",s.createElement(S.h_,{View:i,size:24})},Vs=e=>{let{icon:t,title:n,description:i}=e;return s.createElement(Ns,null,s.createElement(Os,null,s.createElement(js,{name:t})),s.createElement(Rs,null,s.createElement(Ms,{variant:"h4",autoContrast:!0},n),s.createElement(Fs,{dangerouslySetInnerHTML:{__html:E.A.sanitize(i,{USE_PROFILES:{html:!0}})}})))},Ds=(0,w.Ay)(Bs)`
  margin-bottom: 30px;
`,Hs=w.Ay.div`
  display: flex;
  gap: 4rem;
  justify-content: center;
  align-items: center;
  width: 100%;

  ${e=>{let{position:t,isSmallScreen:n}=e;return`\n    position: ${t};\n    ${"absolute"===t?`bottom: ${n?"-16px":"16px"};`:""};\n  `}}
`,qs=()=>{const{isBelowBreakpoint:e}=(0,u.dv)(),t=e("laptop"),n=(0,u.dn)(),i=Ur("parallax"),r=n?.keyInformations;return r?.length?s.createElement(Hs,{position:i?"absolute":"relative",isSmallScreen:t},t?s.createElement(Ds,{blockName:"key-informations",slidesPerView:"auto",spaceBetween:32},r.map(e=>{let{icon:t,title:n,description:i}=e;return s.createElement(k.qr,{key:n,style:{width:"auto"}},s.createElement(Vs,{icon:t,title:n,description:E.A.sanitize(i,{USE_PROFILES:{html:!0}})}))})):s.createElement(s.Fragment,null,r.map(e=>{let{icon:t,title:n,description:i}=e;return s.createElement(Vs,{key:n,icon:t,title:n,description:E.A.sanitize(i,{USE_PROFILES:{html:!0}})})}))):null},Us=w.Ay.div`
  margin-top: 48px;
  position: relative;
  display: flex;
  justify-content: center;

  .parallax-banner {
    border-radius: 16px;
    ${e=>{let{theme:t}=e;return`\n      @media (max-width: ${t.breakpoints.values.pipe2025SmallDevicesLimit}px) {\n        border-radius: 0px;\n      }\n    `}}
  }
`,Xs=(0,w.Ay)(Us)`
  ${e=>{let{theme:t}=e;return`\n    @media (max-width: ${t.breakpoints.values.pipe2025SmallDevicesLimit}px) {\n      margin-top: 12px;\n    }\n  `}}
`,Ws=()=>{const e=Ur("keyInformations"),t=Ur("parallax"),n=(0,u.dn)(),{keyInformations:i=[],parallax:r}=n||{},a=i&&i.length>1&&r?.src?Us:Xs;return s.createElement(a,null,t&&s.createElement(Oe,null),e&&s.createElement(qs,null))};var Js=n(35648);const Gs=(0,w.Ay)(qa.A)`
  border: none;

  & .MuiOutlinedInput-root {
    border-radius: 100px;
    padding: 10px 0 10px 18px !important;

    &.Mui-focused fieldset {
      border: 1px solid ${De.c3[600]};
    }
    &:hover fieldset {
      border: 1px solid ${De.c3[600]};
    }
  }
`,Zs=(0,w.Ay)(Xa.A)`
  .MuiAutocomplete-paper {
    margin: 12px;
    border-radius: 16px;
  }

  .MuiAutocomplete-listbox {
    border: 1px solid ${De.c3[200]};
    border-radius: 0 0 8px 8px;
    padding: 16px;
  }

  .MuiAutocomplete-option {
    border-radius: 4px;
    padding: 12px 16px;
    transition: ${e=>{let{theme:t}=e;return`all ${t.transitions.duration.shorter}ms ease`}};

    &.Mui-focused {
      background-color: ${e=>{let{theme:t}=e;const n=t.palette.primary.main;return(0,Ga.X4)(n,.2)}};
    }
  }
`,Ks=(0,w.Ay)($.$n)`
  padding: 12px;
  margin: 0 6px;
  min-width: 0;
`;function Qs(e){let{inputValue:t,loading:n,onChange:i,onClick:r,onInputChange:a,options:l,value:o}=e;const{t:p}=(0,v.Bd)();return s.createElement(Ua.A,{spacing:2},s.createElement(Gs,{"data-testid":"job-offers-search-bar",fullWidth:!0,freeSolo:!0,onChange:i,onInputChange:a,value:o,inputValue:t,isOptionEqualToValue:(e,t)=>e.label===t,options:l,loading:!1,clearText:p("job_offers.search_bar.clear_text"),PopperComponent:Zs,renderInput:e=>{let{InputProps:{ref:t,...i},...a}=e;return s.createElement(Ua.A,{direction:"row",alignItems:"flex-end",ref:t,spacing:1},s.createElement(Wa.A,(0,ue.A)({},a,{placeholder:p("job_offers.search_bar.placeholder_2022"),InputLabelProps:{shrink:!1},InputProps:{...i,endAdornment:s.createElement(Js.A,{position:"end"},n?s.createElement(Ja.A,{color:"inherit",size:20}):null,s.createElement(Ks,{onClick:r,rounded:!0,size:"large"},s.createElement(yt.A,{size:24,View:bt.C0,withContrast:!0})))},variant:"outlined"})))}}))}const Ys=()=>s.createElement(Za.Rq,{view:Qs,smallSearchBar:!0}),ep=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;

  ${li.uM} {
    position: static;
  }

  ${se} {
    background-color: transparent;
  }
`,tp=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  height: 100%;
  width: 100%;

  ${oi.D6} {
    font-size: 1rem;
    margin-top: 0;
    margin-bottom: 0.5rem;
  }

  .MuiBox-root {
    padding: 0;
  }
`,np=()=>s.createElement(ep,null,s.createElement(tp,null,s.createElement(pe,{displayAnalysisInModal:!0}))),ip=(0,w.Ay)(F.A)`
  font-size: 1.25rem;
  font-weight: 700;
  line-height: 1.5;
  margin: 0;
`,rp=(0,w.Ay)(F.A)`
  font-size: 1rem;
  line-height: 1.5;
  margin: 0;
`,ap=(0,w.Ay)(R.A)`
  width: 200px;
  height: 32px;
  background-color: lightgrey;
`,lp=w.Ay.div`
  input::placeholder {
    font-size: 1rem !important; // needs important to override #cvcatcher-app global styles
  }
`,op=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.GV)(V.Vd),n=(0,u.GV)(V.HA);return s.createElement(Ua.A,{direction:"column",spacing:.5},s.createElement(ip,null,e("career_website_landing.discover_offers")),t?s.createElement(ap,null):s.createElement(rp,null,e("career_website_landing.search_section.title.top_line",{count:n||0})))},sp=e=>{let{containerHeight:t}=e;const n=window.innerHeight>t;return s.createElement(s.Fragment,null,s.createElement(op,null),s.createElement(lp,null,s.createElement(Ys,null)),n&&s.createElement(np,null))},pp=w.Ay.div`
  display: flex;
  flex-direction: column;
  gap: 12px;

  ${e=>{let{isMobile:t}=e;return t&&`\n    padding: 32px 24px;\n    border: 1px solid ${_.p6};\n    border-radius: 16px;\n    margin-bottom: 16px\n    gap: 8px;\n  `}}
`,mp=(0,w.Ay)($r)`
  font-weight: 400;
`,cp=(0,w.Ay)(F.A)`
  margin: 0;
  font-size: 16px;
`,dp=w.Ay.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
`,up=(0,w.Ay)(dp)`
  justify-content: flex-start;
`,gp=w.Ay.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
`,hp=(0,w.Ay)(zr.N_)`
  color: black;
`,xp=(0,w.Ay)($.$n)`
  min-width: 0;
  padding: 8px;
`,bp=(0,w.Ay)(S.vw).attrs(e=>{let{theme:t}=e;return{color:t.palette.primary.main,bgColor:t.palette.common.white,borderColor:t.palette.primary.main}})``,wp=e=>{let{offer:t,isMobile:n=!1}=e;const i=(0,u.gl)(t),r=t.company_logo_url;return s.createElement(hp,{to:(0,K.X2)(window.location.href,t.id)},s.createElement(pp,{isMobile:n},s.createElement(up,null,s.createElement(s.Fragment,null,r&&s.createElement(Lr.X,{src:r}),s.createElement(cp,{as:"h3"},t.title))),s.createElement(dp,null,s.createElement(gp,null,s.createElement(bp,null,s.createElement(yt.A,{View:bt.nR,size:16}),s.createElement(mp,null,t.contract_type)),i&&s.createElement(bp,null,s.createElement(yt.A,{View:bt.ft,size:16}),s.createElement(mp,null,i))),s.createElement("div",null,s.createElement(xp,{rounded:!0,size:"large"},s.createElement(yt.A,{View:bt.uI,size:20,withContrast:!0}))))))};var fp=n(75273),yp=n(71091),Ep=n(27502);const vp=(0,w.Ay)(fp.q)`
  flex-direction: column;
  gap: 16px;
  margin-bottom: 16px;

  ${fp.P} {
    height: 84px;
    border-radius: 16px;
    width: 100%;
    margin: 0;
  }
`,Ap=w.Ay.section`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  width: 100%;
`,kp=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  width: 100%;
`,$p=(0,w.Ay)(S.o5)`
  font-size: 16px;
  margin: 0;
  text-align: center;
`,_p=(0,w.Ay)($p)`
  font-weight: 600;
`,Sp=(0,w.Ay)($p)`
  font-weight: 400;
`,zp=w.Ay.section`
  display: flex;
  flex-direction: column;
  gap: 24px;
  width: 100%;
`,Cp=w.Ay.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`,Lp=w.Ay.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  gap: 1.5rem;
`,Tp=(0,w.Ay)($.$n).attrs({size:"large",rounded:!0})`
  padding: 10px 28px;
`,Ip=(0,w.Ay)(Ua.A)`
  gap: 1.5rem;

  @media (max-height: 830px) {
    gap: 1rem;
  }

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    padding: 0;
  }
`,Pp=(0,w.Ay)(jr)`
  font-size: 1.125rem;
`,Bp=(0,w.Ay)(Tp)`
  padding: 18px 32px;
`,Np=()=>{const{config:e}=(0,m._r)(),t=(0,yp.B)(e),{t:n}=(0,v.Bd)();return s.createElement(Ap,null,s.createElement(bt.C0,{width:48,height:48}),s.createElement(_p,null,n("result_page.no_results")),t&&s.createElement(kp,null,s.createElement(Sp,null,n("career_website_landing.last_job_offers_section.submit_spontaneous_application")),s.createElement(Bp,{icon:bt.mD,iconPosition:"left",to:{pathname:x.J.SEARCH,hash:"#spontaneous-application"}},n("job_details_page.apply"))))},Rp=e=>{let{limit:t=3,...n}=e;const{isBelowOrEqualToBreakpoint:i}=(0,we.d)(),r=i("laptop"),{t:a}=(0,v.Bd)(),{list:l,isFetching:o,total:p}=(0,u.GV)(e=>e.lastJobOffers);return s.createElement(zp,n,s.createElement(Vt,{limit:t},s.createElement(Cp,null,s.createElement(Dr,{CustomSectionTitle:Pp,title:a("career_website_landing.last_job_offers_section.title_2022")}),!r&&0!==p&&s.createElement(Tp,{to:x.J.SEARCH,variant:"outlined"},a("career_website_landing.last_job_offers_section.see_all_2025"))),0!==p?s.createElement(Lp,null,o?s.createElement(vp,{skeletonCount:3}):s.createElement(Ip,{divider:r?void 0:s.createElement(Ep.A,null)},l.map(e=>s.createElement(wp,{key:e.reference,offer:e,isMobile:r}))),r&&s.createElement(Tp,{to:x.J.SEARCH},a("career_website_landing.last_job_offers_section.see_all_2025"))):s.createElement(Np,null)))};var Mp=n(35772);const Fp=w.Ay.div`
  z-index: 9;
  position: absolute;
  background-color: #fff;
  border-radius: 16px 16px 0 0;
  right: 4vw;
  bottom: 0;
  height: fit-content;
  max-height: calc(100vh - 1rem);
  max-width: 35vw;
  overflow: hidden;

  ${oi.J_} {
    padding: 1rem 1.5rem;
    text-align: left;
    border-radius: 16px;
    width: 100%;

    &.highlight,
    &:hover {
      border-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}};
      background-color: ${e=>{let{theme:t}=e;return`${(0,_.x6)(t.palette,_.Fl,_.Xs)}1A`}};
    }

    ${oi.bd} {
      flex-direction: row;
      text-align: left;
      gap: 12px;

      ${Mp.oe};
    }
  }
`,Op=w.Ay.div`
  display: flex;
  flex-direction: column;
  padding: 1.5em 2rem;
  border-radius: 16px 16px 0 0;
  background-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.Fl,_.Xs)}}0D;
  gap: 1.5rem;
`,jp=w.Ay.div`
  padding: 1rem 2rem;
  overflow-y: auto;
`,Vp=()=>{const e=(0,u.GV)(V.Vd),t=(0,s.useRef)(null),[n,i]=(0,s.useState)(0);return(0,s.useEffect)(()=>{!e&&t.current&&i(t.current.clientHeight)},[e]),s.createElement(Fp,{ref:t},s.createElement(Op,null,s.createElement(sp,{containerHeight:n})),s.createElement(jp,null,s.createElement(Rp,null)))},Dp=w.Ay.section`
  margin-top: 84px;
  position: relative;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    padding: 0 32px;
    margin-top: 0;
  }
`,Hp=(0,w.Ay)(Ss)`
  position: absolute;
  top: 10%;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    position: initial;
    text-align: left;
    margin-top: 0px;
    margin-bottom: 24px;
  }
`,qp=()=>{const e=(0,u.dn)(),{title:t,subTitle:n}=e?.team||{};return s.createElement(Hp,{title:t,subTitle:n})},Up=()=>{const e=(0,u.dn)(),t=e?.team?.list||[];return s.createElement(Dp,null,s.createElement(qp,null),s.createElement(Sn,{swiperContent:t}))},Xp=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`,Wp=w.Ay.form`
  display: flex;
  justify-content: center;
  gap: 24px;
  width: 100%;
  flex-wrap: wrap;
  margin-top: 48px;
`,Jp=w.Ay.div`
  position: relative;
  display: flex;
  align-items: center;
  flex: 1;
  max-width: 240px;

  &:hover,
  &:active,
  &:focus {
    opacity: 0.85;
  }

  ${e=>{let{theme:t}=e;return`\n    transition: all ${t.transitions.duration.short}ms ease;\n  `}}
`,Gp=w.Ay.input`
  position: absolute;
  opacity: 0;
  height: 100%;
  width: 100%;
  cursor: pointer;
`,Zp=w.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  border-radius: 16px;
  padding: 32px;
  width: 100%;
  height: 100%;
  border: 1px solid ${_.p6};
  ${e=>{let{theme:t}=e;return`\n    svg {\n      fill: ${t.palette.primary.main};\n    }\n  `}}
`,Kp=(0,w.Ay)(S.fz)`
  margin-top: 4px;
  margin-bottom: 0px;
  max-width: 120px;
  font-weight: 500;
  font-size: 0.815rem;
`,Qp=w.Ay.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: start;
  gap: 8px;
`,Yp=(0,w.Ay)(O.hE)`
  margin: 0;
  font-size: 1.5rem;
`,em=(0,w.Ay)(S.fz)`
  margin: 0;
  font-size: 0.875rem;
  font-weight: 400;
`,tm=e=>{let{onFileChange:t}=e;const{t:n}=(0,v.Bd)();return s.createElement(Xp,null,s.createElement(Qp,null,s.createElement(Yp,{variant:"h3"},n("widget.file_input.main_text")),s.createElement(em,null,n("widget.file_input.sub_text"))),s.createElement(Wp,{action:"#",id:"dropzone-area"},s.createElement(Jp,null,s.createElement(Gp,{"data-testid":"cvc-resume-upload-input",type:"file",onChange:e=>{t(e.target.files)}}),s.createElement(Zp,null,s.createElement(S.h_,{View:bt.qb,size:48}),s.createElement(Kp,{autoContrast:!0},n("upload_zone.mobile_upload_2022")))),s.createElement(Jp,null,s.createElement(Gp,{"data-testid":"cvc-resume-upload-input",type:"file",accept:"image/*",capture:!0,onChange:e=>{t(e.target.files)}}),s.createElement(Zp,null,s.createElement(S.h_,{View:bt.PE,size:48}),s.createElement(Kp,{autoContrast:!0},n("upload_zone.mobile_camera_2022"))))))};tm.propTypes={onFileChange:Ke().func.isRequired,uploadTitle:Ke().string};const nm=(0,w.Ay)($.$n)`
  display: flex;
  gap: 4px;
  align-items: center;
  justify-content: center;

  ${e=>{let{theme:t}=e;return`\n      color: ${(0,_.Vh)(t.palette.primary.main,t.palette)} !important;\n      fill: ${(0,_.Vh)(t.palette.primary.main,t.palette)} !important;\n    `}}
`,im=(0,w.Ay)(Mi.A)`
  .MuiDrawer-paper {
    border-radius: 8px 8px 0 0;
  }
`,rm=(0,w.Ay)(M.A)`
  width: 100%;
  background-color: white;
  padding: 16px 20px;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;

  ${se} {
    padding: 0;
    padding-bottom: 32px;
  }
`,am=w.Ay.button`
  align-self: flex-end;
  background: none;
  border: none;
  cursor: pointer;
  margin-bottom: 10px;
`,lm=()=>{const{t:e}=(0,v.Bd)(),[t,n]=(0,s.useState)(!1),i=()=>n(!0),r=()=>n(!1);return s.createElement(s.Fragment,null,s.createElement(nm,{onClick:i,icon:bt.nR,iconPosition:"left",rounded:!0,size:"large"},e("widget.file_input.main_text")),s.createElement(im,{anchor:"bottom",open:t,onClose:r,onOpen:i,disableSwipeToOpen:!0},s.createElement(rm,null,s.createElement(am,{type:"button",onClick:()=>r()},s.createElement(bt.MR,{width:"24px",height:"24px"})),s.createElement(pe,{displayAnalysisInModal:!0,mobileUploadZoneView:tm}))))},om=w.Ay.div`
  z-index: 12;
  position: sticky;
  top: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 32px;
  max-height: 78px;
`,sm=w.Ay.div`
  flex-grow: 1;
  max-width: 750px;
  z-index: 12;

  ${Ks} {
    padding: 16px;
  }

  & .MuiOutlinedInput-root {
    background-color: white;
    height: 68px;
  }

  input::placeholder {
    font-size: 1rem !important; // needs important to override #cvcatcher-app global styles
  }
`,pm=w.Ay.div`
  z-index: 12;
  ${oi.J_} {
    border-radius: 100px;
    padding: 12px 24px;
    background-color: white;

    ${oi.bd} {
      flex-direction: row;
      gap: 16px;

      ${Mp.oe}
    }
  }

  ${se} {
    background-color: transparent;
  }

  ${oi.Kd} {
    display: none;
  }

  ${oi.D6} {
    font-size: 1rem;
  }
`,mm=(0,w.Ay)(sm)`
  position: sticky;
  top: 0;
  z-index: 12;
  padding: 16px;
  margin-top: -48px;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;

  & .MuiOutlinedInput-root {
    height: 64px;
  }

  > div {
    width: 75%;
    min-width: 284px;
  }
`,cm=(0,w.Ay)(pm)`
  position: fixed;
  bottom: 24px;
  right: 24px;
`,dm=w.Ay.div`
  z-index: 13;
  ${li.uM} {
    ${li.Kq};
  }
`,um=()=>{const e=(0,s.useRef)(null),[t,n]=s.useState(!1);return(0,s.useEffect)(()=>{function t(){e.current&&window.scrollY>.3*window.innerHeight?n(!0):n(!1)}return window.addEventListener("scroll",t),()=>window.removeEventListener("scroll",t)},[]),s.createElement(dm,{ref:e},s.createElement(ai.A,{in:t},s.createElement("div",null,s.createElement(pe,null))))},gm=()=>{const e=(0,w.DP)();return s.createElement(s.Fragment,null,s.createElement(Ve.rb,{down:!0},s.createElement(mm,null,s.createElement(Ys,null)),s.createElement(cm,null,s.createElement(lm,null))),s.createElement(Ve.ad,{minWidth:e.breakpoints.values.laptop,maxWidth:1480},s.createElement(um,null)),s.createElement(Ve.ad,{minWidth:1481,up:!0},s.createElement(om,null,s.createElement(sm,null,s.createElement(Ys,null)),s.createElement(pm,null,s.createElement(pe,{displayAnalysisInModal:!0})))))},hm=(0,w.Ay)(ql)`
  ${ge} {
    --swiper-navigation-color: ${e=>{let{theme:t}=e;return(0,_.x6)(t.palette,_.CF,_.Xs)}};
  }

  ${he} {
    top: 15px;
  }
  ${Nl} {
    position: initial;
    .swiper-pagination {
      bottom: 0;
    }

    ${xn};
  }
`,xm=(0,w.Ay)(hm)`
  padding-right: 5vw;
  .swiper-button-prev,
  .swiper-button-next {
    top: 0;
  }

  .swiper-button-prev {
    left: 0;
  }
  .swiper-button-next {
    left: 58px;
  }

  ${Nl} {
    .swiper-pagination {
      margin-left: -4px;
      padding-left: 0;
    }
  }

  ${Dl} {
    color: ${e=>{let{theme:t}=e;return t.palette.text.primary}};
  }
`,bm=(0,w.Ay)(hm)`
  padding: 0 32px;
  margin-top: 48px;
  .swiper-button-prev,
  .swiper-button-next {
    display: none;
  }

  ${Nl} {
    .swiper-pagination {
      padding-left: 28px;
    }
  }

  ${Dl} {
    color: ${e=>{let{theme:t}=e;return t.palette.text.primary}};
  }
`,wm=()=>s.createElement(xm,{enableNavigation:!0}),fm=()=>s.createElement(bm,{enableNavigation:!1}),ym=(0,w.Ay)(tn)`
  border-radius: 16px;
`,Em=(0,w.Ay)(tn)`
  ${Kt} {
    padding: 18px 18px 18px 20px;
  }
`,vm=()=>s.createElement(ym,{playIconPosition:en.Center}),Am=()=>s.createElement(Em,{playIconPosition:en.Center}),km=w.Ay.div`
  margin-top: 82px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
    margin-top: 42px;
  }
`,$m=w.Ay.div`
  margin-bottom: 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`,_m=(0,w.Ay)(O.hE)`
  font-size: 1.5rem;
  margin: 0;
`,Sm=(0,w.Ay)(S.fz)`
  font-size: 1.125rem;
  margin-top: 16px;
`,zm=(0,w.Ay)(Ee)`
  .swiper {
    padding: 4px 2px;

    ${e=>{let{theme:t}=e;return t.breakpoints.down("tablet")}} {
      padding: 4px 24px;
    }
  }
`,Cm=e=>{let{blockName:t,bottom:n,children:i,subTitle:r,swipperProps:a,title:l,...o}=e;return s.createElement(km,o,s.createElement($m,null,s.createElement(_m,{variant:"h2",dangerouslySetInnerHTML:{__html:E.A.sanitize(l,{USE_PROFILES:{html:!0}})}}),r&&s.createElement(Sm,null,r)),s.createElement(zm,(0,ue.A)({blockName:t,spaceBetween:24,smallBreakpoint:"pipe2025SmallDevicesLimit"},a?{swipperProps:a}:{}),i),n)},Lm=(0,w.Ay)(O.hE)`
  font-size: 1rem;
  margin: 0;
  margin-bottom: 16px;
`,Tm=w.Ay.p`
  font-size: 1rem;
  margin: 0;
`,Im=(0,w.Ay)(ta)`
  &.swiper-slide {
    border: 1px solid ${_.p6};
    border-radius: 16px;
    background-color: transparent;
    max-width: 50%;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
      max-width: 60%;
    }
  }
`,Pm=()=>{const e=(0,u.dn)(),t=e?.advantages;return t?.list?.length?s.createElement(Cm,{blockName:"advantages",title:t.title,subTitle:t.subTitle},t.list.map((e,t)=>s.createElement(Im,{key:t},s.createElement(Lm,{variant:"h4",dangerouslySetInnerHTML:{__html:E.A.sanitize(e.title,{USE_PROFILES:{html:!0}})}}),s.createElement(Tm,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e.text,{USE_PROFILES:{html:!0}})}})))):null},Bm=(0,w.Ay)(_l)`
  margin: 48px 0;

  ${Al} {
    padding-top: 48px;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.thirteenInchScreen}px`}}) {
      padding-top: 64px;
    }
  }
`,Nm=(0,w.Ay)(_l)`
  flex-direction: column;
  margin: 0;

  ${Al} {
    max-width: 100%;
  }

  ${kl} {
    flex: 1;
    max-width: 100%;
  }
`,Rm=()=>Ur("videoTemplate")?s.createElement(Bm,{AdvantagesView:wm,VideoView:vm,sizeRatio:$l.Equal}):s.createElement(Pm,null),Mm=()=>Ur("videoTemplate")?s.createElement(Nm,{AdvantagesView:fm,VideoView:Am,sizeRatio:$l.Equal}):s.createElement(Pm,null),Fm=w.Ay.div`
  margin-top: 64px;
  margin-bottom: 12px;
  position: relative;

  .swiper {
    padding-bottom: 2px;
    padding-right: 2px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    margin-bottom: 32px;
    padding: 0 16px;
  }

  --swiper-navigation-size: 2rem;
  --swiper-navigation-color: #000;
`,Om=(0,w.Ay)(Ee)`
  margin-top: 32px;

  .swiper-wrapper {
    padding-bottom: 2px;
    width: auto;
    margin: auto;
  }

  .swiper-slide {
    max-width: 286px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    margin: 0;

    .swiper-slide {
      max-width: 220px;
    }

    .swiper-wrapper {
      justify-content: left;
    }
  }
`,jm=(0,w.Ay)(k.qr)`
  border: 1px solid ${_.p6};
  border-radius: 16px;
  &.swiper-slide {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 36px 24px;
    height: auto;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
      padding: 48px 0;
    }

    &:last-child {
      margin-right: 0 !important;
    }
  }
`,Vm=w.Ay.img`
  width: 100%;
  max-width: 126px;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    max-width: 128px;
  }
`,Dm=(0,w.Ay)(O.hE)`
  font-weight: 700;
  margin: 0;
  font-size: 1.5rem;
  text-align: center;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    margin-bottom: 36px;
    padding-left: 32px;
  }
`,Hm=(0,w.Ay)(Dm)`
  font-size: 1.125rem;
  font-weight: 400;
  margin-top: 16px;
`,qm=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.wT)();if(!t?.certifications.length)return null;const{certifications:n,subTitle:i,title:r}=t;return s.createElement(Fm,null,s.createElement(Dm,{variant:"h2"},r||e("landing_page.certifications")),i&&s.createElement(Hm,{variant:"h2"},i),s.createElement(Om,{blockName:"certif",slidesPerView:"auto",smallBreakpoint:"pipe2025SmallDevicesLimit",enablePagination:!1,enableNavigation:!1,centerInsufficientSlides:!0,breakpoints:{}},n.map((e,t)=>s.createElement(jm,{key:`certif-${t}`},s.createElement(Vm,{src:e.logo,alt:`certification numero ${t}`})))))},Um=w.Ay.p`
  font-size: 34px;
  color: ${e=>{let{theme:t}=e;return t.palette.primary.main}};
  margin: 0;
`,Xm=w.Ay.p`
  font-size: 0.875rem;
  margin: 0;
`,Wm=(0,w.Ay)(ta)`
  &.swiper-slide {
    border: 1px solid ${_.p6};
    border-radius: 16px;
    background-color: transparent;
    max-width: 50%;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
      max-width: 60%;
    }
  }

  ${Um} {
    margin-bottom: 8px;
  }
`,Jm=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.dn)(),n=t?.recruitmentSteps;return n?.list?.length?s.createElement(Cm,{blockName:"steps",title:n.title||`${e("career_website_landing.steps_section.title.top_line")}&nbsp;${e("career_website_landing.steps_section.title.bottom_line")}`,subTitle:n.subTitle},n.list.map((e,t)=>s.createElement(Wm,{key:t},s.createElement(Um,null," ",t+1),s.createElement(Xm,{dangerouslySetInnerHTML:{__html:E.A.sanitize(e,{USE_PROFILES:{html:!0}})}})))):null},Gm=w.Ay.div`
  margin-top: 64px;
  margin-bottom: 12px;
  position: relative;

  .swiper {
    padding-bottom: 2px;
    padding-right: 2px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    margin-bottom: 32px;
    padding: 0 16px;
  }

  --swiper-navigation-size: 2rem;
  --swiper-navigation-color: #000;
`,Zm=(0,w.Ay)(Ee)`
  margin-top: 32px;

  .swiper-wrapper {
    padding-bottom: 2px;
    width: auto;
    margin: auto;
  }

  .swiper-slide {
    max-width: 286px;
  }

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    margin: 0;

    .swiper-slide {
      max-width: 220px;
    }

    .swiper-wrapper {
      justify-content: left;
    }
  }
`,Km=(0,w.Ay)(k.qr)`
  border-radius: 16px;
  &.swiper-slide {
    display: flex;
    justify-content: center;
    align-items: center;
    height: auto;

    @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
      padding: 48px 0;
    }

    &:last-child {
      margin-right: 0 !important;
    }
  }
`,Qm=w.Ay.img`
  width: 100%;
  border-radius: 16px;
`,Ym=w.Ay.a`
  cursor: pointer;
`,ec=(0,w.Ay)(O.hE)`
  font-weight: 700;
  margin: 0;
  font-size: 1.5rem;
  text-align: center;

  @media (max-width: ${e=>{let{theme:t}=e;return`${t.breakpoints.values.pipe2025SmallDevicesLimit}px`}}) {
    margin-bottom: 36px;
    padding-left: 32px;
  }
`,tc=(0,w.Ay)(ec)`
  font-size: 1.125rem;
  font-weight: 400;
  margin-top: 16px;
`,nc=()=>{const{t:e}=(0,v.Bd)(),t=(0,u.dn)(),n=t?.gallery,i=n?.pictures||[],[r,a]=(0,s.useState)(!1),[l,o]=(0,s.useState)(0);return n&&i.length?s.createElement(Gm,null,s.createElement(ec,{variant:"h2"}," ",n.title||e("landing_page.gallery")),n.subTitle&&s.createElement(tc,{variant:"h2"},n.subTitle),s.createElement(Zm,{blockName:"gallery",smallBreakpoint:"pipe2025SmallDevicesLimit",enablePagination:!1,enableNavigation:!1,centerInsufficientSlides:!0,breakpoints:{}},i.map((e,t)=>s.createElement(Km,{key:t},s.createElement(Ym,{onClick:()=>(e=>{o(e),a(!0)})(t)},s.createElement(Qm,{src:e.srcFullSize,alt:e.title||`gallery item ${t}`}))))),r&&s.createElement(ze,{open:r,onClose:()=>a(!1),title:n.title||e("landing_page.gallery"),subtitle:n.subTitle,items:i,initialSlide:l,blockName:"gallery-modal"})):null},ic=w.Ay.main`
  width: 100%;
  position: relative;
`,rc=w.Ay.div`
  position: relative;
`,ac=w.Ay.div`
  margin: 32px;
  display: flex;
  flex-direction: column;
  align-items: center;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    margin-top: 0px;
  }
`,lc=(0,w.Ay)(Rp)`
  margin-top: 24px;
`,oc=(0,w.Ay)(Rp)`
  padding: 0 16px;
`,sc=w.Ay.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`,pc=w.Ay.div`
  width: 75%;
  display: flex;
  flex-direction: column;
  word-break: break-word;

  ${e=>{let{theme:t}=e;return t.breakpoints.down("laptop")}} {
    width: 100%;
  }
`,mc=(0,w.Ay)($.$n)`
  margin-top: 48px;
`,cc=()=>{const{t:e}=(0,v.Bd)();return s.createElement(mc,{rounded:!0,size:"large",to:"/search"},e("career_website_landing.last_job_offers_section.see_all_2022"))},dc=()=>{const e=Ur("keyInformations"),t=Ur("parallax"),{isBelowOrEqualToBreakpoint:n}=(0,we.d)(),i=n("laptop");return s.createElement("div",{"data-testid":"cvc-page-landing"},s.createElement(Y,null),s.createElement(ic,null,s.createElement(ds,null),s.createElement(rc,null,s.createElement(os,null),!i&&s.createElement(Vp,null)),s.createElement(ac,null,s.createElement(pc,null,s.createElement(gm,null),i&&s.createElement(lc,{limit:4}),e&&t&&s.createElement(Ws,null),s.createElement(Rm,null),Ur("employerCertifications")&&s.createElement(qm,null),Ur("briefAndPictures")&&s.createElement(Ps,null),(!e||!t)&&s.createElement(Ws,null),Ur("team")&&s.createElement(Up,null),Ur("recruitmentSteps")&&s.createElement(Jm,null),Ur("gallery")&&s.createElement(nc,null),s.createElement(sc,null,s.createElement(cc,null)))),s.createElement(Ha,null)))},uc=()=>{const e=Ur("keyInformations"),t=Ur("parallax");return s.createElement(ti,null,s.createElement(Y,null),s.createElement(ic,null,s.createElement(ds,null),s.createElement(os,null),s.createElement(gm,null),s.createElement(oc,{limit:4}),e&&t&&s.createElement(Ws,null),s.createElement(Mm,null),Ur("employerCertifications")&&s.createElement(qm,null),Ur("briefAndPictures")&&s.createElement(Ps,null),(!e||!t)&&s.createElement(Ws,null),Ur("team")&&s.createElement(Up,null),Ur("recruitmentSteps")&&s.createElement(Jm,null),Ur("gallery")&&s.createElement(nc,null),s.createElement(sc,null,s.createElement(cc,null))," ",s.createElement(Ha,null)))},gc=()=>{const{isBelowOrEqualToBreakpoint:e}=(0,we.d)(),t=e("tablet");return s.createElement(ae,{view:t?uc:dc})},hc={[d.tC.CLASSIC_2022]:i,[d.tC.HORIZONTAL_BAR_2022]:r,[d.tC.LATERAL_BAR_2022]:a,[d.tC.BENTO_2024]:l,[d.tC.PIPE_2025]:o},xc=e=>{let{productType:t}=e;const{config:n}=(0,m._r)();if(!n.template)throw new Error("Missing config.template field in the client config.");const i=hc[n.template];if(!i)throw new Error(`The template value in config.template "${n.template}" is not supported.`);return s.createElement(m.tv,{trackHistory:!0},e=>s.createElement(p.Ix,{history:e},s.createElement(s.StrictMode,null,s.createElement("span",{"data-testid":"app-availability-indicator"}),s.createElement(c.p,null,s.createElement(b,{pages:i,productType:t})))))}}}]);